# 03 — DATABASE MODEL GUIDE

## Tabel Minimal

```text
ai_settings
ai_providers
ai_provider_models
ai_model_aliases
ai_tenant_provider_settings
ai_feature_toggles
ai_guardrail_policies
ai_guardrail_events
ai_chat_workspaces
ai_conversations
ai_messages
ai_message_sources
ai_context_requests
ai_knowledge_bases
ai_knowledge_documents
ai_document_chunks
ai_vector_indexes
ai_module_connectors
ai_module_connector_fields
ai_prompt_templates
ai_skills
ai_skill_runs
ai_workflow_templates
ai_usage_logs
ai_cost_logs
ai_rate_limits
ai_admin_controls
ai_audit_logs
```

## Entity Highlights

`ai_providers`: provider_key, provider_name, base_url, api_key_encrypted, auth_type, is_enabled, default_model, timeout_seconds, max_retries.

`ai_conversations`: company_id, workspace_id, conversation_title, mode, module_key, source_record_id, visibility, owner_id, status.

`ai_messages`: conversation_id, role, content, model, provider_key, prompt_tokens, completion_tokens, total_tokens, cost_estimate, latency_ms, guardrail_status.

`ai_message_sources`: message_id, source_type, module_key, record_id, document_id, chunk_id, source_title, confidence_score.

`ai_usage_logs`: user_id, provider_key, model, feature_key, prompt_tokens, completion_tokens, total_tokens, cost, latency_ms, status.
