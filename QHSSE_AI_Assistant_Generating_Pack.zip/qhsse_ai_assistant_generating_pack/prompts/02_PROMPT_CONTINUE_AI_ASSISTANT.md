# 02 Prompt Continue Ai Assistant

Continue AI Assistant Sequence. Kerjakan sequence berikutnya sesuai sequence/00_AI_ASSISTANT_SEQUENCE.md. Jika sequence selesai, jangan lanjut sequence berikutnya. Berikan keterangan selesai.
