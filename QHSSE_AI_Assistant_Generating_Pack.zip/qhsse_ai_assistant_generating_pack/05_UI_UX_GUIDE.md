# 05 — UI/UX GUIDE AI ASSISTANT

## Sidebar

```text
AI Assistant
├── Chat Workspace
├── Document Q&A
├── Module Data Q&A
├── Incident RCA Assistant
├── Risk / HIRADC / JSA Assistant
├── Permit Review Assistant
├── Audit & CAPA Assistant
├── Compliance Assistant
├── Report Summary Assistant
├── Knowledge Base
├── Prompt Templates
├── Skills & Workflows
├── Usage & Cost
├── Guardrail Events
└── AI Settings
```

## Komponen Wajib

```text
AIChatBox
AIMessageBubble
AISourceCitation
AIContextSelector
AIModuleSelector
AIRecordPicker
AIGuardrailAlert
AIUsageMeter
AIProviderStatus
AIModelSelector
PromptTemplatePicker
SkillRunPanel
```
