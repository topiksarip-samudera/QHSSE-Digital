# 08 — CROSS-MODULE INTEGRATION GUIDE

AI Assistant harus terhubung ke:

```text
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
```

## Integrasi Ringkas

```text
Document Control → SOP, policy, procedure, controlled document sebagai RAG
Reports & Analytics → executive summary, KPI insight, trend explanation
Incident Management → RCA, investigation, lesson learned, CAPA suggestion
Risk Management → hazard/control recommendation, HIRADC/JSA draft
Permit to Work → permit risk review, missing control warning
Audit & Inspection → finding summary, audit checklist suggestion
Action Tracking → CAPA recommendation and follow-up
Legal & Compliance → obligation explanation, compliance gap
Training & Competency → training gap analysis
Environment → exceedance and spill summary
Quality → NCR/complaint/COPQ analysis
Security → security incident insight
Contractor → contractor risk/performance insight
Emergency → readiness and drill evaluation
Asset & Equipment → overdue certificate/inspection/calibration insight
```
