# 13 AI Usage Log, Token Cost, Rate Limit & Admin Control

## Tujuan

Generate sequence ini secara end-to-end: database, backend API, frontend UI, permission, audit log, test minimal, dan acceptance criteria.

## Fokus

```text
usage log, token/cost tracking, model/provider cost, rate limit, quota, budget, admin control
```

## Database Relevan

```text
ai_settings
ai_providers
ai_provider_models
ai_model_aliases
ai_tenant_provider_settings
ai_guardrail_policies
ai_guardrail_events
ai_chat_workspaces
ai_conversations
ai_messages
ai_message_sources
ai_context_requests
ai_knowledge_bases
ai_knowledge_documents
ai_document_chunks
ai_module_connectors
ai_prompt_templates
ai_skills
ai_skill_runs
ai_usage_logs
ai_cost_logs
ai_rate_limits
ai_audit_logs
```

## API Pattern

```text
GET /api/v1/ai/providers
POST /api/v1/ai/providers
GET /api/v1/ai/conversations
POST /api/v1/ai/conversations/:id/messages
POST /api/v1/ai/rag/search
POST /api/v1/ai/context/retrieve
POST /api/v1/ai/skills/<skill>
GET /api/v1/ai/usage
GET /api/v1/ai/guardrail-events
```

## Testing Minimal

```text
Happy path
Validation error
Permission denied
Tenant isolation
Scope filtering
Prompt injection attempt
Source citation required
Usage log created
Audit log created
```

## Acceptance Criteria

- Tenant-safe.
- Permission backend berjalan.
- AI tidak membaca data tanpa permission.
- Source/citation tersedia untuk jawaban berbasis data internal.
- Guardrail event tercatat jika triggered.
- Usage log tercatat.
- Audit log tercatat.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI AI ASSISTANT SEQUENCE 13: AI Usage Log, Token Cost, Rate Limit & Admin Control
```
