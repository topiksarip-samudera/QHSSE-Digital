# 00 — PROMPT AWAL AI ASSISTANT UNTUK AI AGENT

Core Platform sudah stabil. Semua QHSSE Operational Modules dan Reports & Analytics sudah selesai atau siap integrasi.

Sumber data:

```text
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
```

Sekarang generate **AI Assistant / QHSSE Copilot** berdasarkan folder `qhsse_ai_assistant_generating_pack`.

Aturan wajib:
1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_ai_provider_configuration.md`.
3. AI Assistant tidak boleh menjadi chat biasa saja.
4. Harus ada provider configuration dan secure API key handling.
5. Harus ada chat workspace, RAG, module data connector, permission-aware context, dan source citation.
6. Harus ada guardrail: prompt injection, data leakage, unauthorized access, hallucination control.
7. Harus ada assistant khusus: Incident RCA, Risk/HIRADC/JSA, PTW Review, Audit/CAPA, Legal/Document, Reports/Analytics.
8. Harus ada prompt template, skill, workflow library, usage log, token cost, rate limit, admin control.
9. Semua AI response berbasis data internal wajib punya source reference.
10. Semua AI conversation, context retrieval, export, provider setting, dan guardrail event wajib audit logged.
11. Semua API wajib permission-guarded dan tenant-safe.
12. Setelah selesai tulis: `SELESAI AI ASSISTANT SEQUENCE 01: Foundation & AI Provider Configuration`.
13. Jangan lanjut sequence berikutnya sebelum user meminta continue.
