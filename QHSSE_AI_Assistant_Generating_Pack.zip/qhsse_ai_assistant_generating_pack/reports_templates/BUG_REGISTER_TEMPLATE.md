# Bug Register — AI Assistant

| Bug ID | Date | Sequence | Severity | Title | Steps | Expected | Actual | Status |
|---|---|---|---|---|---|---|---|---|
| AI-BUG-001 |  |  | P0/P1/P2/P3 |  |  |  |  | Open |
