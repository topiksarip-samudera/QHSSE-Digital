# 02 — AI ASSISTANT GENERATING RULES

## Aturan Utama

1. Jangan membuat AI Assistant sebagai chat UI saja.
2. AI harus memakai provider abstraction.
3. Provider API key wajib encrypted at rest.
4. AI context wajib permission-aware.
5. AI tidak boleh mengambil data lintas tenant.
6. AI tidak boleh bypass role/scope/module permission.
7. RAG wajib menyimpan document source/chunk reference.
8. Module data connector wajib membatasi field dan query.
9. Jangan expose raw SQL ke AI.
10. Jangan izinkan AI mengeksekusi action berbahaya tanpa human approval.
11. Semua suggestion harus diberi label `AI generated`.
12. Semua AI response berbasis data internal harus punya source reference.
13. Semua conversation, context retrieval, token usage, provider call, dan export wajib audit log.

## Permission Standard

```text
ai.view
ai.chat
ai.chat_with_documents
ai.chat_with_module_data
ai.use_incident_assistant
ai.use_risk_assistant
ai.use_permit_assistant
ai.use_audit_assistant
ai.use_capa_assistant
ai.use_compliance_assistant
ai.use_report_assistant
ai.create_prompt_template
ai.manage_prompt_template
ai.manage_skills
ai.manage_provider
ai.manage_guardrail
ai.view_usage
ai.manage_usage_limit
ai.export_conversation
ai.delete_conversation
```

## Guardrail Wajib

```text
Prompt injection detection
Unauthorized data request detection
Cross-tenant data prevention
Sensitive field masking
Source-required answer mode
No-source refusal mode
Tool/action approval mode
Rate limit
Token budget
Output safety filter
Internal prompt protection
```
