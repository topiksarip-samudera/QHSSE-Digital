# 03 Rag Context Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| AI-001 | Upload KB document | PASS |
| AI-002 | Chunk document | PASS |
| AI-003 | Index document | PASS |
| AI-004 | Search RAG | PASS |
| AI-005 | Answer with citation | PASS |
| AI-006 | No source refusal | PASS |
| AI-007 | Module context retrieval | PASS |
| AI-008 | Source permission | PASS |
