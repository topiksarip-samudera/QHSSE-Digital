# 04 Ai Skills Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| AI-001 | Incident RCA | PASS |
| AI-002 | Risk HIRADC | PASS |
| AI-003 | JSA draft | PASS |
| AI-004 | Permit review | PASS |
| AI-005 | Audit finding | PASS |
| AI-006 | CAPA recommendation | PASS |
| AI-007 | Compliance gap | PASS |
| AI-008 | Report summary | PASS |
