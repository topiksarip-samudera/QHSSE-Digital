# 05 Usage Admin Release Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| AI-001 | Usage log | PASS |
| AI-002 | Token cost | PASS |
| AI-003 | Rate limit | PASS |
| AI-004 | Budget limit | PASS |
| AI-005 | Skill toggle | PASS |
| AI-006 | Provider disabled | PASS |
| AI-007 | Admin audit | PASS |
| AI-008 | Release gate | PASS |
