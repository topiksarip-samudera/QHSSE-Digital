# 02 Permission Guardrail Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| AI-001 | Allowed module access | PASS |
| AI-002 | Unauthorized module blocked | PASS |
| AI-003 | Cross tenant blocked | PASS |
| AI-004 | Site scope enforced | PASS |
| AI-005 | Prompt injection detected | PASS |
| AI-006 | Sensitive field masked | PASS |
| AI-007 | Internal prompt protected | PASS |
| AI-008 | Guardrail audit | PASS |
