# 01 Ai Provider Chat Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| AI-001 | Create AI provider | PASS |
| AI-002 | Encrypt API key | PASS |
| AI-003 | Test provider connection | PASS |
| AI-004 | Sync model list | PASS |
| AI-005 | Create conversation | PASS |
| AI-006 | Send message | PASS |
| AI-007 | Save usage | PASS |
| AI-008 | Export conversation | PASS |
