# START HERE — QHSSE AI Assistant Generating Pack

Paket ini dibuat untuk generate modul **AI Assistant / QHSSE Copilot** pada WebApp QHSSE.

## Rekomendasi Split

AI Assistant sebaiknya di-split menjadi **14 sequence**.

```text
01 Foundation & AI Provider Configuration
02 AI Chat Workspace Core
03 AI Permission, Scope & Guardrail
04 Knowledge Base & Document RAG
05 Module Data Context Connector
06 Incident RCA & Investigation Assistant
07 Risk, HIRADC & JSA Assistant
08 Permit to Work Review Assistant
09 Audit, Inspection & CAPA Assistant
10 Legal, Compliance & Document Assistant
11 Reports, Analytics & Executive Summary Assistant
12 Prompt Template, Skill & Workflow Library
13 AI Usage Log, Token Cost, Rate Limit & Admin Control
14 QA, Security Test, Permission & Stabilization
```

## Kenapa 14 Sequence?

AI Assistant lebih sensitif dibanding modul biasa karena menyentuh provider key, RAG, permission-aware context, module connector, prompt injection defense, usage cost, rate limit, dan security QA.

## Sumber Data AI

```text
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
```

## Tujuan Modul

Membangun QHSSE Copilot yang dapat menjawab berbasis data, membantu RCA, HIRADC/JSA, review PTW, audit/CAPA, compliance, executive summary, dan document Q&A dengan permission, scope, guardrail, citation, token usage, dan audit log.

## Cara Pakai

1. Extract ZIP.
2. Baca `00_PROMPT_AWAL_AI_ASSISTANT.md`.
3. Baca `01_AI_ASSISTANT_MASTER_BLUEPRINT.md`.
4. Mulai dari `sequence/01_foundation_ai_provider_configuration.md`.
5. Kerjakan satu sequence saja.
6. Setelah selesai tulis status sequence.
7. Jangan lanjut sebelum diminta continue.

## Status Akhir

```text
AI ASSISTANT STABILIZED: GO
```
