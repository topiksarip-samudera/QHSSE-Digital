# 04 — API CONTRACT GUIDE

Gunakan prefix `/api/v1`.

## Provider & Settings

```text
GET    /ai/providers
POST   /ai/providers
GET    /ai/providers/:id
PATCH  /ai/providers/:id
DELETE /ai/providers/:id
POST   /ai/providers/:id/test
POST   /ai/providers/:id/rotate-key
GET    /ai/models
POST   /ai/models/sync
GET    /ai/settings
PATCH  /ai/settings
```

## Chat Workspace

```text
GET    /ai/workspaces
POST   /ai/workspaces
GET    /ai/conversations
POST   /ai/conversations
GET    /ai/conversations/:id/messages
POST   /ai/conversations/:id/messages
POST   /ai/conversations/:id/export
```

## RAG & Context

```text
GET    /ai/knowledge-bases
POST   /ai/knowledge-bases
POST   /ai/knowledge-bases/:id/documents
POST   /ai/documents/:id/index
POST   /ai/rag/search
GET    /ai/module-connectors
POST   /ai/context/preview
POST   /ai/context/retrieve
```

## Skills

```text
POST /ai/skills/incident-rca
POST /ai/skills/risk-assessment
POST /ai/skills/jsa-draft
POST /ai/skills/permit-review
POST /ai/skills/audit-finding
POST /ai/skills/capa-recommendation
POST /ai/skills/compliance-gap
POST /ai/skills/report-summary
POST /ai/skills/executive-insight
```

## Admin

```text
GET /ai/usage
GET /ai/usage/cost
GET /ai/rate-limits
POST /ai/rate-limits
GET /ai/guardrail-events
GET /ai/audit-logs
```
