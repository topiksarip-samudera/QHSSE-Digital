# 06 — PERMISSION & SECURITY GUIDE

## Security Rules

- AI tidak boleh membaca data di luar tenant user.
- AI tidak boleh membaca module yang user tidak punya permission.
- AI tidak boleh bypass site/project/department scope.
- AI tidak boleh melihat field sensitif tanpa permission.
- AI provider key harus encrypted.
- AI system prompt/internal prompt tidak boleh tampil ke user.
- AI response berbasis data internal wajib source reference.
- Prompt injection harus dideteksi dan dicatat.
- AI tool/action execution harus human approval.
- Export conversation harus permission-guarded.
- Admin setting change harus audit logged.

## Sensitive Fields

```text
personal_identity_number
medical_detail
salary
private_contact
security_sensitive_detail
investigation_confidential_note
legal_confidential_note
api_key
provider_secret
internal_prompt
```
