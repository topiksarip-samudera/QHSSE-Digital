# 00 — PROMPT AWAL PRODUCTION HARDENING & GO-LIVE UNTUK AI AGENT

Core Platform, seluruh QHSSE Operational Modules, Reports & Analytics, AI Assistant, Mobile/PWA Field Optimization, dan SaaS Commercialization sudah selesai atau siap integrasi.

Platform yang harus disiapkan untuk production:

```text
Core Platform
Stabilization & QA
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
Mobile/PWA Field Optimization
SaaS Commercialization
```

Sekarang generate tahap **Production Hardening & Go-Live Preparation** berdasarkan folder `qhsse_production_hardening_go_live_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_production_architecture_environment_strategy.md`.
3. Tahap ini tidak boleh hanya membuat checklist umum.
4. Harus menghasilkan konfigurasi, struktur file, script, runbook, checklist, dan test plan yang bisa dipakai production.
5. Harus mencakup Docker Compose production hardening.
6. Harus mencakup Kubernetes/scalable deployment preparation.
7. Harus mencakup CI/CD release automation.
8. Harus mencakup backup/restore database.
9. Harus mencakup backup/restore file storage.
10. Harus mencakup monitoring, logging, metrics, alerting.
11. Harus mencakup error tracking dan incident response.
12. Harus mencakup security hardening, secrets, access control, tenant isolation review.
13. Harus mencakup performance optimization dan load testing.
14. Harus mencakup disaster recovery dan business continuity.
15. Harus mencakup UAT, go-live gate, documentation, demo tenant, pricing page, dan sales material.
16. Semua production change wajib audit-friendly dan terdokumentasi.
17. Setelah sequence selesai, tulis:
   `SELESAI PRODUCTION GO-LIVE SEQUENCE XX: <nama sequence>`
18. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
