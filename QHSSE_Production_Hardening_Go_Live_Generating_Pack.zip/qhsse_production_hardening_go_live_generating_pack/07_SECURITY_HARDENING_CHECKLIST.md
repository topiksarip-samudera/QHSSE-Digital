# 07 — SECURITY HARDENING CHECKLIST

## Application

```text
Debug disabled
CORS restricted
CSP enabled
Security headers enabled
Rate limit enabled
CSRF strategy reviewed
JWT/session expiry configured
Password policy configured
MFA admin recommended
Admin endpoint protected
File upload validation enabled
```

## Tenant & Permission

```text
Tenant isolation test passed
RBAC test passed
Scope access test passed
Module entitlement test passed
Report export permission passed
AI context permission passed
Mobile offline permission passed
Billing access permission passed
```

## Infrastructure

```text
TLS enabled
Firewall configured
Database not public
Redis not public
MinIO/S3 not public except signed URL
Secrets not committed
Backup encrypted
Dependency scan passed
Container image scan passed
```
