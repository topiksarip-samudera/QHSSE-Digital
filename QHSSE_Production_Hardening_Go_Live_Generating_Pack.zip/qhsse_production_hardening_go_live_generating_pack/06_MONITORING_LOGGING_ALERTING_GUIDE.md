# 06 — MONITORING, LOGGING & ALERTING GUIDE

## Metrics

```text
API uptime
API latency p95/p99
Frontend uptime
Database connection
Slow query
Redis memory
Queue waiting/failed
Worker status
Storage usage
File upload failure
AI token usage
AI cost
Payment webhook failure
Mobile sync failure
Error rate
CPU/RAM/disk
```

## Alerts

```text
P0: app down, database down, payment webhook broken, backup failed
P1: high error rate, queue stuck, disk > 85%, latency high
P2: AI cost high, mobile sync failure, storage near limit
```

## Logs

```text
Application log
Access log
Error log
Audit log
Security log
Billing/payment log
AI usage log
Mobile sync log
```
