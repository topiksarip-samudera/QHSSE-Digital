# 05 — BACKUP & RESTORE RUNBOOK

## Database Backup

```bash
pg_dump "$DATABASE_URL" --format=custom --file=backup_$(date +%Y%m%d_%H%M%S).dump
```

## Database Restore

```bash
pg_restore --clean --if-exists --no-owner --dbname="$DATABASE_URL" backup.dump
```

## File Storage Backup

```bash
mc mirror minio/qhsse ./backup/minio/qhsse
```

## Restore Test Requirement

```text
Backup file exists
Backup checksum verified
Restore to staging success
App boots after restore
Tenant data verified
Attachment verified
Audit log verified
```

## Frequency

```text
Database: daily minimum
File storage: daily minimum
Critical backup: before production migration
Retention: 7 daily, 4 weekly, 12 monthly
```
