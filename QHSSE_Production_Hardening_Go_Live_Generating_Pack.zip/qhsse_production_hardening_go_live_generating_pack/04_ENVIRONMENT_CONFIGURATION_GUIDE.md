# 04 — ENVIRONMENT CONFIGURATION GUIDE

## File Environment

```text
.env.example
.env.staging.example
.env.production.example
.env.demo.example
```

## Required Variables

```text
NODE_ENV
APP_URL
API_URL
DATABASE_URL
REDIS_URL
S3_ENDPOINT
S3_BUCKET
S3_ACCESS_KEY
S3_SECRET_KEY
JWT_SECRET
ENCRYPTION_KEY
SMTP_HOST
SMTP_USER
SMTP_PASS
PAYMENT_WEBHOOK_SECRET
AI_PROVIDER_BASE_URL
AI_PROVIDER_API_KEY
LOG_LEVEL
SENTRY_DSN
PROMETHEUS_ENABLED
```

## Rules

- Jangan commit `.env` asli.
- Semua secret production harus digenerate kuat.
- Semua key harus bisa dirotasi.
- Gunakan secret manager jika tersedia.
- Pisahkan staging dan production.
