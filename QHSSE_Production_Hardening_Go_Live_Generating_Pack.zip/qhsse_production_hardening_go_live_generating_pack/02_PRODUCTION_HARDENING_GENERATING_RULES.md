# 02 — PRODUCTION HARDENING GENERATING RULES

## Aturan Utama

1. Jangan membuat checklist kosong tanpa implementasi.
2. Setiap sequence harus menghasilkan file nyata: config, script, runbook, checklist, atau test matrix.
3. Jangan menyimpan secret asli di repo.
4. Gunakan `.env.example`, bukan `.env` production.
5. Semua container wajib healthcheck.
6. Semua service penting wajib restart policy.
7. Migration production harus punya backup gate.
8. Backup harus punya restore test.
9. Monitoring harus mencakup app, API, DB, Redis, queue, storage, worker, billing, AI usage, mobile sync.
10. Alerting harus punya severity.
11. Security harus mencakup tenant isolation, RBAC, CORS, CSP, rate limit, secret, dependency scan.
12. Load testing harus punya target dan baseline.
13. Go-live harus punya rollback plan.
14. Dokumentasi harus bisa digunakan admin, user, dan developer.

## Production Acceptance

```text
No hardcoded secret
No debug mode
No public admin endpoint
TLS enforced
Backup automated
Restore tested
Monitoring active
Alerting active
Healthcheck active
Rollback tested
Tenant isolation passed
Permission passed
Billing webhook idempotent
AI quota enforced
Mobile sync stable
```

## Audit & Evidence

Simpan evidence untuk:
```text
Deployment test
Backup test
Restore test
Security test
Load test
UAT signoff
Go-live approval
Rollback drill
DR drill
```
