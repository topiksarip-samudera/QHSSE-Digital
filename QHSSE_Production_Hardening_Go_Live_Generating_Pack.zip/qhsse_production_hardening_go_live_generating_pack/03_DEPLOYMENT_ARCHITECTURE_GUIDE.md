# 03 — DEPLOYMENT ARCHITECTURE GUIDE

## Recommended Production Components

```text
Reverse Proxy / Load Balancer
Frontend Web
Backend API
Worker Queue
Scheduler / Cron Worker
PostgreSQL
Redis
MinIO / S3
Object Storage Backup
Monitoring
Logging
Error Tracking
SMTP / Notification
AI Provider Gateway
Payment Webhook Endpoint
```

## Minimum Production Strategy

```text
Single VM Production:
- Docker Compose hardened
- Nginx/Caddy reverse proxy
- TLS
- automated backup
- monitoring agent
- external object backup

Scalable Production:
- Kubernetes
- managed PostgreSQL
- managed Redis
- S3-compatible storage
- ingress controller
- HPA
- centralized logging
```

## Network Zones

```text
Public:
- reverse proxy
- frontend
- webhook endpoint

Private:
- backend API
- workers
- database
- redis
- storage

Restricted:
- admin console
- backup storage
- secrets
```
