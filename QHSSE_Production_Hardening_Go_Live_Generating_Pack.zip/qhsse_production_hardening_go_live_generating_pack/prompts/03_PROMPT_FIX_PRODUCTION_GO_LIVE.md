# 03 Prompt Fix Production Go Live

Review dan perbaiki blocking issue P0/P1 pada Production Hardening: deployment, backup, restore, monitoring, security, load test, UAT, documentation, launch preparation.
