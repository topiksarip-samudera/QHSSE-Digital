# 01 Prompt Start Production Go Live

Mulai generate Production Hardening & Go-Live Preparation dari sequence/01_production_architecture_environment_strategy.md. Kerjakan sequence pertama saja. Setelah selesai tulis: SELESAI PRODUCTION GO-LIVE SEQUENCE 01: Production Architecture & Environment Strategy.
