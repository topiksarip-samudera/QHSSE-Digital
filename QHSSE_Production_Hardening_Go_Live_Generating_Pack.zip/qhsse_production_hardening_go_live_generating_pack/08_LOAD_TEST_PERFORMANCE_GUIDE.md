# 08 — LOAD TEST & PERFORMANCE GUIDE

## Target Baseline

```text
API p95 latency < 500ms for common requests
Dashboard p95 load < 3s
Report export async for large data
Queue processing not stuck
DB CPU stable
No memory leak in 30-minute load test
```

## Test Scenarios

```text
Login
Dashboard load
Incident create
Inspection checklist submit
Permit approval
Report analytics load
Export report
AI request
Mobile sync push/pull
File upload
Payment webhook
```

## Tools

```text
k6
Artillery
Locust
JMeter
Playwright performance smoke
```

## Output

```text
Load Test Report
Bottleneck List
Optimization Action
Retest Result
Go/No-Go Decision
```
