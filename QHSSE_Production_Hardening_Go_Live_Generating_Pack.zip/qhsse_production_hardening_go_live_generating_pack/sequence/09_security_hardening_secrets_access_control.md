# 09 Security Hardening, Secrets & Access Control

## Tujuan

Mengeraskan security: secrets, CSP, CORS, rate limit, RBAC review, tenant isolation test, headers, dependency scan, dan access control.

## Fokus

```text
secrets, CORS, CSP, rate limit, RBAC, tenant isolation, dependency scan
```

## Output Wajib

```text
Configuration file
Script / command guide
Runbook
Checklist
Test matrix
Acceptance criteria
Evidence requirement
```

## Area yang Harus Dicek

```text
Frontend
Backend API
Worker
Scheduler
PostgreSQL
Redis
MinIO/S3
Queue
Notification
Payment webhook
AI usage
Mobile sync
Reports export
Tenant isolation
RBAC/permission
Audit log
```

## Testing Minimal

```text
Happy path
Failure path
Rollback path jika relevan
Permission/security check jika relevan
Performance check jika relevan
Evidence captured
```

## Acceptance Criteria

- Output sequence tersedia.
- Bisa dijalankan di staging.
- Production risk terdokumentasi.
- Blocking issue dicatat.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI PRODUCTION GO-LIVE SEQUENCE 09: Security Hardening, Secrets & Access Control
```
