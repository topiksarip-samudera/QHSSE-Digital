# 04 CI/CD Pipeline & Release Automation

## Tujuan

Membangun CI/CD: lint, test, build, image scan, migration gate, deploy staging, deploy production, rollback, dan release tagging.

## Fokus

```text
CI/CD, lint, test, build, image scan, migration gate, deploy, rollback
```

## Output Wajib

```text
Configuration file
Script / command guide
Runbook
Checklist
Test matrix
Acceptance criteria
Evidence requirement
```

## Area yang Harus Dicek

```text
Frontend
Backend API
Worker
Scheduler
PostgreSQL
Redis
MinIO/S3
Queue
Notification
Payment webhook
AI usage
Mobile sync
Reports export
Tenant isolation
RBAC/permission
Audit log
```

## Testing Minimal

```text
Happy path
Failure path
Rollback path jika relevan
Permission/security check jika relevan
Performance check jika relevan
Evidence captured
```

## Acceptance Criteria

- Output sequence tersedia.
- Bisa dijalankan di staging.
- Production risk terdokumentasi.
- Blocking issue dicatat.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI PRODUCTION GO-LIVE SEQUENCE 04: CI/CD Pipeline & Release Automation
```
