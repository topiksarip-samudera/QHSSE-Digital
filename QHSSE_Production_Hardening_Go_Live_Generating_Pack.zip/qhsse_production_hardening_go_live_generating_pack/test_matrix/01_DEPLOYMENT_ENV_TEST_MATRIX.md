# 01 Deployment Env Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PROD-001 | Production architecture approved | PASS |
| PROD-002 | Env files separated | PASS |
| PROD-003 | No secret committed | PASS |
| PROD-004 | Domain/TLS ready | PASS |
| PROD-005 | Healthcheck configured | PASS |
| PROD-006 | Reverse proxy works | PASS |
| PROD-007 | Staging deploy works | PASS |
| PROD-008 | Production deploy dry-run | PASS |
