# 02 Backup Restore Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PROD-001 | DB backup success | PASS |
| PROD-002 | DB restore to staging | PASS |
| PROD-003 | File storage backup | PASS |
| PROD-004 | File restore test | PASS |
| PROD-005 | Checksum verified | PASS |
| PROD-006 | Retention configured | PASS |
| PROD-007 | Pre-migration backup | PASS |
| PROD-008 | Restore evidence captured | PASS |
