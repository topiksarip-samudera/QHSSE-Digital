# 09 — RELEASE & ROLLBACK RUNBOOK

## Release Steps

```text
1. Freeze release branch
2. Run lint/test/build
3. Backup database
4. Backup storage metadata
5. Run migration dry-run on staging
6. Deploy staging
7. Smoke test staging
8. Approve production deployment
9. Deploy production
10. Run smoke test production
11. Monitor metrics and logs
12. Announce release complete
```

## Rollback Triggers

```text
P0 bug
Login failure
Tenant isolation failure
Payment failure
Data corruption
Migration failure
Critical performance degradation
```

## Rollback Steps

```text
1. Stop new deployment rollout
2. Revert app image
3. Restore previous config if needed
4. Apply DB rollback or restore if required
5. Validate app
6. Communicate incident
7. Create post-release review
```
