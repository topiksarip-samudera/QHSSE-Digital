# 08 — CROSS-MODULE VALIDATION GUIDE

## Platform Scope

```text
Core Platform
Stabilization & QA
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
Mobile/PWA Field Optimization
SaaS Commercialization
Production Hardening & Go-Live Preparation
```

## Validation Mapping

```text
Incident → real report, investigation, RCA, CAPA
Risk → HIRADC/JSA generation, review, approval
Audit → checklist, finding, action, close-out
PTW → request, review, approval, QR verification
Document → revision, approval, acknowledgement
Training → matrix, attendance, certificate expiry
Legal → obligation, evidence, compliance score
Environment → monitoring, exceedance, waste
Quality → NCR, complaint, defect, CAPA
Security → visitor, gate pass, incident
Contractor → document, worker, equipment, performance
Emergency → drill, contact, attendance
Asset → certificate, inspection, calibration
Reports → KPI, dashboard, export
AI → safe answer, source citation, permission
Mobile/PWA → offline, camera, QR, GPS, sync
SaaS → tenant, plan, billing, quota
Production → backup, restore, monitoring, alerting
```
