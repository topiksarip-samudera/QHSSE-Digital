# 00 — PROMPT AWAL BETA TESTING & PILOT CUSTOMER PROGRAM UNTUK AI AGENT

Core Platform, seluruh QHSSE Operational Modules, Reports & Analytics, AI Assistant, Mobile/PWA Field Optimization, SaaS Commercialization, dan Production Hardening & Go-Live Preparation sudah selesai atau siap integrasi.

Platform yang harus diuji dalam beta/pilot:

```text
Core Platform
Stabilization & QA
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
Mobile/PWA Field Optimization
SaaS Commercialization
Production Hardening & Go-Live Preparation
```

Sekarang generate tahap **Beta Testing & Pilot Customer Program** berdasarkan folder `qhsse_beta_testing_pilot_customer_program_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_beta_program_strategy_scope.md`.
3. Tahap ini tidak boleh hanya membuat checklist umum.
4. Harus menghasilkan beta plan, pilot plan, UAT scenario, field test scenario, feedback form, bug triage flow, customer onboarding flow, support flow, dan final pilot report.
5. Harus mencakup role-based UAT.
6. Harus mencakup Mobile/PWA field test.
7. Harus mencakup operational module workflow validation.
8. Harus mencakup Reports & Analytics executive review.
9. Harus mencakup AI Assistant safety, accuracy, and permission validation.
10. Harus mencakup SaaS billing, subscription, tenant admin, and support validation.
11. Harus mencakup bug triage, feedback loop, improvement sprint, and fix verification.
12. Harus mencakup customer success readiness.
13. Harus menghasilkan final go/no-go launch recommendation.
14. Semua hasil uji harus terdokumentasi dengan evidence.
15. Setelah sequence selesai, tulis:
   `SELESAI BETA PILOT SEQUENCE XX: <nama sequence>`
16. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
