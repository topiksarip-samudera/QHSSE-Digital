# 04 — UAT SCENARIO GUIDE

## UAT Format

```text
Scenario ID
Role
Module
Objective
Precondition
Steps
Expected Result
Actual Result
Status
Evidence
Tester
Date
Notes
```

## Core UAT Group

```text
Login & permission
Tenant settings
Incident report workflow
Risk/HIRADC/JSA workflow
Audit/inspection workflow
Permit to Work workflow
Document control workflow
Training/competency workflow
Compliance workflow
Environment monitoring workflow
Quality NCR workflow
Security incident workflow
Contractor workflow
Emergency drill workflow
Asset inspection workflow
Reports & analytics review
AI Assistant usage
Mobile/PWA field workflow
SaaS billing workflow
```
