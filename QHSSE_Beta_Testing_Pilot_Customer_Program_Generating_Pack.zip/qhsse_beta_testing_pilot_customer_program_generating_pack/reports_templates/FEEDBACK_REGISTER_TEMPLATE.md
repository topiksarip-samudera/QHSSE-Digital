# Feedback Register — Pilot Customer

| Feedback ID | Date | Customer | User Role | Category | Feedback | Impact | Priority | Decision | Owner | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| FB-001 |  |  |  | Bug/UX/Workflow/Feature/Training/Support |  |  | High/Med/Low | Fix/Roadmap/Reject |  | Open |
