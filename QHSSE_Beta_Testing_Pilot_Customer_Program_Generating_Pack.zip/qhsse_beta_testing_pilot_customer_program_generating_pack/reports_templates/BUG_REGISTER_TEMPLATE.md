# Bug Register — Beta Testing & Pilot Customer Program

| Bug ID | Date | Customer | Module | Role | Severity | Title | Steps | Expected | Actual | Owner | Due Date | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| BETA-BUG-001 |  |  |  |  | P0/P1/P2/P3/P4 |  |  |  |  |  |  | Open |
