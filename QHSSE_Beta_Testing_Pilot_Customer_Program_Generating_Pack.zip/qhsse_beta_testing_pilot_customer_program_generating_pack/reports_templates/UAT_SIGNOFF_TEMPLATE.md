# UAT Signoff Template

| Area | Tester | Role | Status | Evidence | Notes | Signoff |
|---|---|---|---|---|---|---|
| Login & Permission |  |  | PASS/FAIL |  |  |  |
| Core Workflow |  |  | PASS/FAIL |  |  |  |
| Mobile/PWA |  |  | PASS/FAIL |  |  |  |
| Reports |  |  | PASS/FAIL |  |  |  |
| AI Assistant |  |  | PASS/FAIL |  |  |  |
| Billing/SaaS |  |  | PASS/FAIL |  |  |  |
