# 03 — PILOT CUSTOMER SELECTION GUIDE

## Ideal Pilot Customer

```text
Has real QHSSE workflow
Has multiple roles
Has at least one site/project
Has incident/risk/audit/permit needs
Willing to give feedback
Has management sponsor
Has field user for Mobile/PWA testing
Can join weekly review
```

## Pilot Size Recommendation

```text
Small pilot:
- 1 tenant
- 1 site
- 10–25 users
- 2–4 weeks

Medium pilot:
- 1–3 tenants
- 2–5 sites
- 25–100 users
- 4–8 weeks
```

## Do Not Start Pilot If

```text
Production environment unstable
Backup not tested
Tenant isolation not tested
Mobile sync unstable
Billing webhook unstable
No support process
No training material
No bug triage process
```
