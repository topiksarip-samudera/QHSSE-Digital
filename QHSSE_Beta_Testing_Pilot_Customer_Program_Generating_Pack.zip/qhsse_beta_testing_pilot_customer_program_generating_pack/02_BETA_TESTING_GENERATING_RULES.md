# 02 — BETA TESTING GENERATING RULES

## Aturan Utama

1. Jangan membuat beta hanya sebagai daftar checklist.
2. Semua UAT harus berbasis role dan workflow.
3. Semua test case harus punya expected result.
4. Semua bug harus punya severity.
5. Semua feedback harus dikategorikan.
6. Semua fix harus diverifikasi ulang.
7. Semua P0/P1 harus punya owner dan due date.
8. Semua pilot customer issue harus masuk feedback loop.
9. AI, billing, mobile, tenant isolation, dan permission harus masuk test wajib.
10. Final go/no-go harus berbasis evidence, bukan asumsi.

## Severity

```text
P0 = blocker, data loss, security leak, app unusable
P1 = major workflow broken, no acceptable workaround
P2 = medium issue, workaround available
P3 = minor issue, UI/UX/copy improvement
P4 = enhancement request
```

## Feedback Category

```text
Bug
UX Confusion
Workflow Gap
Missing Feature
Performance Issue
Mobile Issue
Report Issue
AI Issue
Billing Issue
Training Need
Support Need
Enhancement
```

## Go/No-Go Rule

```text
GO:
- P0 = 0
- P1 = 0 or accepted workaround
- all critical workflows pass
- tenant isolation pass
- permission pass
- AI safety pass
- billing pass
- mobile field test pass
- support readiness pass

NO-GO:
- any open P0
- unresolved security issue
- unresolved tenant isolation issue
- payment/billing blocker
- critical workflow blocker
```
