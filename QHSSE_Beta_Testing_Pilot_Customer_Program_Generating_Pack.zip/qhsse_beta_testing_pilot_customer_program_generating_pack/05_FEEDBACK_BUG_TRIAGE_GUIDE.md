# 05 — FEEDBACK & BUG TRIAGE GUIDE

## Bug Triage Flow

```text
1. Capture issue
2. Validate reproduction
3. Assign severity
4. Assign owner
5. Set due date
6. Fix
7. QA verify
8. User verify if needed
9. Close
10. Add to release note
```

## Feedback Flow

```text
1. Collect feedback
2. Categorize
3. Map to workflow/module
4. Decide: bug / improvement / future roadmap
5. Prioritize
6. Add to improvement sprint
7. Communicate decision to pilot customer
```

## Weekly Pilot Review

```text
Open P0/P1
New feedback
Workflow blockers
Training issues
Adoption metrics
Support tickets
Next sprint actions
Decision risks
```
