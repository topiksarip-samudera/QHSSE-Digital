# 06 — CUSTOMER SUCCESS READINESS GUIDE

## Readiness Items

```text
Onboarding checklist
Admin training guide
User quick start guide
Role-based training deck
Support ticket flow
SLA definition
Escalation matrix
FAQ
Known issue list
Release note format
Customer health score
Adoption dashboard
```

## Customer Health Indicators

```text
Active user rate
Completed onboarding
Critical workflow completion
Open support ticket
Open P0/P1
Training attendance
Mobile usage
Report usage
AI usage
Management review completed
```
