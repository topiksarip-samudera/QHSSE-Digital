# 05 Field Testing for Mobile/PWA

## Tujuan

Menguji Mobile/PWA di lapangan: offline, camera, QR, GPS, signature, sync, conflict, device, dan kondisi koneksi buruk.

## Fokus

```text
mobile offline, camera, QR, GPS, signature, sync, conflict, device test
```

## Output Wajib

```text
Plan / scenario / checklist
Test matrix
Evidence requirement
Owner and due date
Acceptance criteria
Risk and issue list
Status report
```

## Area yang Harus Dicek

```text
User role
Permission
Tenant isolation
Workflow completion
Mobile/PWA if relevant
Reports if relevant
AI if relevant
Billing if relevant
Support readiness if relevant
```

## Testing Minimal

```text
Happy path
Negative test
Permission denied
Tenant isolation
Evidence captured
Feedback captured
Bug triage if failed
```

## Acceptance Criteria

- Output sequence tersedia.
- Scenario bisa dipakai oleh pilot customer.
- Evidence requirement jelas.
- Blocking issue dicatat.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI BETA PILOT SEQUENCE 05: Field Testing for Mobile/PWA
```
