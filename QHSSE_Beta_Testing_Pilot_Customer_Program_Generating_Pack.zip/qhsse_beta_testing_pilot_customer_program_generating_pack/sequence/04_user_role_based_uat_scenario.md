# 04 User Role-Based UAT Scenario

## Tujuan

Membuat skenario UAT berbasis role: admin, HSE, supervisor, inspector, approver, contractor, security, management.

## Fokus

```text
role-based UAT scenario, acceptance criteria, evidence, signoff
```

## Output Wajib

```text
Plan / scenario / checklist
Test matrix
Evidence requirement
Owner and due date
Acceptance criteria
Risk and issue list
Status report
```

## Area yang Harus Dicek

```text
User role
Permission
Tenant isolation
Workflow completion
Mobile/PWA if relevant
Reports if relevant
AI if relevant
Billing if relevant
Support readiness if relevant
```

## Testing Minimal

```text
Happy path
Negative test
Permission denied
Tenant isolation
Evidence captured
Feedback captured
Bug triage if failed
```

## Acceptance Criteria

- Output sequence tersedia.
- Scenario bisa dipakai oleh pilot customer.
- Evidence requirement jelas.
- Blocking issue dicatat.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI BETA PILOT SEQUENCE 04: User Role-Based UAT Scenario
```
