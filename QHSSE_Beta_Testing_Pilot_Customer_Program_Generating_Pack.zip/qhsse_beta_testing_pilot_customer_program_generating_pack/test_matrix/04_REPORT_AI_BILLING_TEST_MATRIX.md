# 04 Report Ai Billing Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| BETA-001 | Executive dashboard reviewed | PASS |
| BETA-002 | Report export | PASS |
| BETA-003 | AI citation | PASS |
| BETA-004 | AI prompt injection blocked | PASS |
| BETA-005 | AI permission enforced | PASS |
| BETA-006 | Invoice generated | PASS |
| BETA-007 | Payment webhook | PASS |
| BETA-008 | Quota enforced | PASS |
