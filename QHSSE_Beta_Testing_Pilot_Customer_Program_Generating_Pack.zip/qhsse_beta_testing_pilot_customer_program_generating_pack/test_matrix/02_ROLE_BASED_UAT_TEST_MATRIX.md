# 02 Role Based Uat Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| BETA-001 | Tenant admin UAT | PASS |
| BETA-002 | HSE officer UAT | PASS |
| BETA-003 | Supervisor UAT | PASS |
| BETA-004 | Inspector UAT | PASS |
| BETA-005 | Permit approver UAT | PASS |
| BETA-006 | Auditor UAT | PASS |
| BETA-007 | Contractor coordinator UAT | PASS |
| BETA-008 | Executive viewer UAT | PASS |
