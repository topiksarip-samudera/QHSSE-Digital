# 03 Field Mobile Workflow Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| BETA-001 | Offline draft | PASS |
| BETA-002 | Camera evidence | PASS |
| BETA-003 | QR scan | PASS |
| BETA-004 | GPS capture | PASS |
| BETA-005 | Signature | PASS |
| BETA-006 | Sync success | PASS |
| BETA-007 | Conflict resolution | PASS |
| BETA-008 | Field workflow completion | PASS |
