# 05 — CAMPAIGN EXECUTION GUIDE

## Launch Campaign Channels

```text
Email
LinkedIn
Website banner
Webinar
WhatsApp broadcast optional
Partner/community post optional
Direct outbound optional
```

## Email Campaign Execution

```text
Email 1: Launch announcement
Email 2: QHSSE problem and solution
Email 3: Module overview
Email 4: AI + Mobile/PWA highlight
Email 5: Demo invitation
Email 6: Trial CTA
Email 7: Follow-up / objection handling
```

## Social Campaign Execution

```text
Post 1: Launch announcement
Post 2: Pain point / spreadsheet problem
Post 3: Module map
Post 4: Mobile field workflow
Post 5: AI assistant for QHSSE
Post 6: Reports & dashboard
Post 7: Demo CTA
```

## Tracking

```text
UTM campaign
UTM source
UTM medium
CTA click
Form submit
Demo booking
Trial signup
Qualified lead
```
