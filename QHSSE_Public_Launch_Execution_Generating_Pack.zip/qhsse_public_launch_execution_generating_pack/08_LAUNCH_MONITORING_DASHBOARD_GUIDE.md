# 08 — LAUNCH MONITORING DASHBOARD GUIDE

## Dashboard Metrics

```text
Website sessions
Landing page conversion
Pricing page conversion
CTA clicks
Demo requests
Trial signups
Qualified leads
Email open rate
Email click rate
Social post engagement
Webinar registration
Webinar attendance
Trial activation
Support tickets
Open P0/P1 issue
API uptime
Frontend uptime
Error rate
Payment success
Signup failure
AI usage
Mobile/PWA activation
```

## Alert Rules

```text
Website down
Signup error spike
Demo booking failure
Payment failure
API error > threshold
Support P0 created
Trial provisioning failed
Email campaign link broken
```

## Monitoring Cadence

```text
Launch day: every 30–60 minutes
First week: daily
First month: weekly
```
