# 10 — SALES FOLLOW-UP & TRIAL CONVERSION GUIDE

## Lead Follow-Up Script

```text
Thank you for your interest in our QHSSE platform.
We can help you digitalize incident, risk, audit, permit, document, training, compliance, environment, quality, security, contractor, emergency, asset, reports, AI assistant, and mobile field workflows in one integrated system.
Would you like to schedule a demo focused on your current QHSSE process?
```

## Trial Conversion Sprint

```text
Day 0: Welcome + setup guide
Day 1: Admin onboarding
Day 3: First workflow recommendation
Day 5: Demo/support check
Day 7: Usage review
Day 10: ROI/value summary
Day 14: Conversion discussion
Day 21: Proposal
Day 30: Close / nurture
```

## CRM Follow-Up Tasks

```text
Call lead
Send deck
Book demo
Send proposal
Start trial
Review trial usage
Handle objection
Commercial negotiation
Close won/lost
```
