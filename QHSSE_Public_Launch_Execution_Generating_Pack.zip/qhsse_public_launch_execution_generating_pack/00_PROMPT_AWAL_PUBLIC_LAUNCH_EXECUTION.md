# 00 — PROMPT AWAL PUBLIC LAUNCH EXECUTION UNTUK AI AGENT

Core Platform, seluruh QHSSE Operational Modules, Reports & Analytics, AI Assistant, Mobile/PWA Field Optimization, SaaS Commercialization, Production Hardening & Go-Live Preparation, Beta Testing & Pilot Customer Program, dan Commercial Launch Preparation sudah selesai atau siap integrasi.

Platform yang akan dieksekusi untuk public launch:

```text
Core Platform
Stabilization & QA
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
Mobile/PWA Field Optimization
SaaS Commercialization
Production Hardening & Go-Live Preparation
Beta Testing & Pilot Customer Program
Commercial Launch Preparation
```

Sekarang generate tahap **Public Launch Execution** berdasarkan folder `qhsse_public_launch_execution_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_launch_command_center_execution_plan.md`.
3. Tahap ini tidak boleh hanya membuat checklist umum.
4. Harus menghasilkan launch command center, execution board, owner matrix, campaign calendar, publish checklist, activation checklist, monitoring dashboard spec, triage board, support playbook, sales follow-up script, dan launch review report.
5. Harus mencakup website/landing/pricing/signup activation.
6. Harus mencakup trial, demo booking, lead capture, dan CRM routing.
7. Harus mencakup launch announcement, email campaign, dan social campaign.
8. Harus mencakup webinar/live demo execution.
9. Harus mencakup support desk dan customer success activation.
10. Harus mencakup launch monitoring: traffic, signup, trial, uptime, conversion, errors, tickets, dan payment.
11. Harus mencakup issue triage, hotfix, communication, rollback decision, dan risk control.
12. Harus mencakup sales follow-up dan trial conversion sprint.
13. Harus mencakup launch review dan post-launch improvement backlog.
14. Semua output harus bisa dipakai oleh AI agent untuk membuat halaman, dokumen, board, template, dashboard, dan workflow.
15. Setelah sequence selesai, tulis:
   `SELESAI PUBLIC LAUNCH SEQUENCE XX: <nama sequence>`
16. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
