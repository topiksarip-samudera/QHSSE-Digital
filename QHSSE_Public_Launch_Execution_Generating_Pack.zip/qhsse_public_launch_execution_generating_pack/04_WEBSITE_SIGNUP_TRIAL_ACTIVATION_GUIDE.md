# 04 — WEBSITE, SIGNUP & TRIAL ACTIVATION GUIDE

## Website Activation Checklist

```text
Landing page published
Pricing page published
Plan comparison visible
FAQ visible
Request demo CTA active
Start trial CTA active
Contact form active
Analytics active
Conversion tracking active
SEO metadata ready
Open Graph image ready
Terms/Privacy linked
Status page linked if available
```

## Trial Signup Flow

```text
Visit landing page
Click Start Trial
Fill signup form
Email verification
Tenant provisioned
Admin account created
Welcome email sent
Onboarding checklist shown
First login tracked
```

## Demo Booking Flow

```text
Request demo
Choose date/time
Submit company detail
Auto-confirmation email
CRM lead created
Sales notified
Reminder sent
Post-demo follow-up created
```
