# 06 — WEBINAR & LIVE DEMO RUNBOOK

## Webinar Agenda

```text
Opening
QHSSE market problem
Product overview
Core module demo
Mobile/PWA demo
AI Assistant demo
Reports & Analytics demo
SaaS package/pricing overview
Q&A
CTA: demo / trial / consultation
```

## Live Demo Flow

```text
Login as admin
Show executive dashboard
Create incident
Run RCA/CAPA
Create risk/HIRADC
Create permit
Execute inspection
Show document control
Show training matrix
Open reports
Ask AI Assistant
Show mobile/PWA QR/evidence flow
End with pricing/demo CTA
```

## Follow-Up

```text
Send recording
Send deck
Send trial link
Send demo booking link
Create CRM task
Assign sales owner
Follow up within 24 hours
```
