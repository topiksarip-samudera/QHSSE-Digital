# 02 Trial Demo Lead Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PLE-001 | Trial form submitted | PASS |
| PLE-002 | Tenant provisioned | PASS |
| PLE-003 | Welcome email sent | PASS |
| PLE-004 | Demo booking works | PASS |
| PLE-005 | Auto-confirmation sent | PASS |
| PLE-006 | CRM lead created | PASS |
| PLE-007 | Sales notified | PASS |
| PLE-008 | Follow-up task created | PASS |
