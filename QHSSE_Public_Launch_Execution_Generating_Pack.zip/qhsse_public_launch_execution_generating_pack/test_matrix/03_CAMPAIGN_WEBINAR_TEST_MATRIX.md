# 03 Campaign Webinar Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PLE-001 | Launch email sent | PASS |
| PLE-002 | Email link tracked | PASS |
| PLE-003 | Social post published | PASS |
| PLE-004 | UTM working | PASS |
| PLE-005 | Webinar registration works | PASS |
| PLE-006 | Live demo script ready | PASS |
| PLE-007 | Recording sent | PASS |
| PLE-008 | Attendee follow-up created | PASS |
