# 04 Support Monitoring Issue Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PLE-001 | Support desk active | PASS |
| PLE-002 | FAQ published | PASS |
| PLE-003 | SLA visible | PASS |
| PLE-004 | Monitoring dashboard active | PASS |
| PLE-005 | Uptime alert works | PASS |
| PLE-006 | P0 triage works | PASS |
| PLE-007 | Hotfix flow works | PASS |
| PLE-008 | Communication template ready | PASS |
