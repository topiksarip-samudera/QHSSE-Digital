# 02 — PUBLIC LAUNCH EXECUTION RULES

## Aturan Utama

1. Jangan melakukan campaign sebelum website, pricing, trial, demo booking, CRM, support, dan monitoring aktif.
2. Semua task launch harus punya owner.
3. Semua CTA harus punya tracking.
4. Semua lead form harus terkoneksi ke CRM atau lead register.
5. Semua demo booking harus punya auto-confirmation.
6. Semua trial signup harus punya onboarding email.
7. Semua issue launch harus masuk triage board.
8. P0/P1 issue harus punya hotfix owner dan ETA.
9. Public communication harus konsisten.
10. Launch review harus memakai data, bukan opini.
11. Post-launch backlog harus diprioritaskan berdasarkan impact.

## Severity Launch Issue

```text
P0 = website down, signup broken, payment broken, security leak, production unavailable
P1 = demo booking broken, lead capture broken, major campaign CTA broken, trial activation broken
P2 = wrong copy, minor conversion issue, tracking issue with workaround
P3 = cosmetic issue, typo, minor layout
P4 = improvement request
```

## Launch Go/No-Go Rule

```text
GO:
- Website ready
- Pricing ready
- Signup/trial ready
- Demo booking ready
- CRM ready
- Support ready
- Monitoring ready
- No open P0/P1

NO-GO:
- Website unavailable
- Signup broken
- Demo booking broken
- Lead capture broken
- Payment/subscription blocker
- Critical security issue
```
