# 09 — ISSUE TRIAGE, HOTFIX & COMMUNICATION GUIDE

## Triage Flow

```text
Issue reported
Severity assigned
Owner assigned
Impact checked
Workaround defined
Fix/hotfix decision
QA verify
Deploy
Communicate
Close
Add to launch review
```

## Hotfix Criteria

```text
P0 always hotfix
P1 hotfix if no workaround
P2 scheduled if workaround exists
P3/P4 backlog
```

## Communication Template

```text
Issue:
Impact:
Affected users:
Current status:
Workaround:
Next update:
Owner:
ETA:
```

## Rollback Decision

```text
Rollback if:
- P0 production outage
- data corruption
- security issue
- critical signup/payment failure
- release creates widespread workflow failure
```
