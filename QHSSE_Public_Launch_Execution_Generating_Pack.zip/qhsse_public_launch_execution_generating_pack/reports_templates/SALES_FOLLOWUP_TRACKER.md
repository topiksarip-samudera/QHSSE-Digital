# Sales Follow-Up Tracker

| Lead | Company | Stage | Last Contact | Next Action | Owner | Due Date | Status |
|---|---|---|---|---|---|---|---|
|  |  | Demo Requested/Trial/Proposal/Negotiation |  |  |  |  | Open |
