# Launch Review Report

## Summary

```text
Launch Date:
Launch Status:
Overall Result:
Top Wins:
Top Issues:
Decision:
```

## KPI Result

| KPI | Target | Actual | Notes |
|---|---|---|---|
| Website sessions |  |  |  |
| Demo requests |  |  |  |
| Trial signups |  |  |  |
| Qualified leads |  |  |  |
| Conversion rate |  |  |  |

## Lessons Learned

```text
What worked:
What did not work:
What to improve:
```

## Post-Launch Backlog

| Priority | Item | Owner | Due Date | Status |
|---|---|---|---|---|
| P1/P2/P3/P4 |  |  |  | Open |
