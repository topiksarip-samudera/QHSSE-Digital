# Launch Monitoring Dashboard Template

| Metric | Target | Current | Status | Notes |
|---|---|---|---|---|
| Website sessions |  |  |  |  |
| Demo requests |  |  |  |  |
| Trial signups |  |  |  |  |
| Qualified leads |  |  |  |  |
| Uptime | 99.9% |  |  |  |
| Open P0/P1 | 0 |  |  |  |
| Support tickets |  |  |  |  |
