# 03 Trial, Demo Booking & Lead Capture Activation

## Tujuan

Mengaktifkan trial flow, demo booking, lead form, CRM routing, auto-reply, qualification, dan follow-up trigger.

## Fokus

```text
trial activation, demo booking, lead form, CRM routing, auto-reply, sales notification
```

## Output Wajib

```text
Execution checklist
Board/template
Owner matrix jika relevan
Tracking requirement
Acceptance criteria
Risk and issue list
Status report
```

## Area yang Harus Dicek

```text
Website
Signup/trial
Demo booking
CRM
Campaign
Support
Customer success
Monitoring
Sales follow-up
Issue triage
Launch review
```

## Testing Minimal

```text
Happy path
Broken link check
CTA tracking check
Form submission check
Notification check
Owner assigned
Evidence captured
```

## Acceptance Criteria

- Output sequence bisa langsung dipakai untuk eksekusi launch.
- Owner dan status jelas.
- Blocking issue dicatat.
- CTA dan tracking jelas jika relevan.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI PUBLIC LAUNCH SEQUENCE 03: Trial, Demo Booking & Lead Capture Activation
```
