# 09 — CRM & SALES PIPELINE GUIDE

## Pipeline Stages

```text
Lead Captured
Qualified
Demo Scheduled
Demo Completed
Proposal Sent
Negotiation
Trial Started
Trial Active
Converted
Lost
Nurture
```

## Lead Qualification Fields

```text
Company name
Industry
Number of users
Number of sites
Current QHSSE process
Pain point
Required modules
Timeline
Budget range
Decision maker
Contact person
```

## Trial Conversion Triggers

```text
Admin completed setup
Users invited
First workflow completed
Report viewed
AI used
Mobile submission completed
Support request resolved
Management review done
```
