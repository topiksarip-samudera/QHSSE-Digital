# 05 Terms of Service, Privacy Policy, SLA & Legal Pack

## Tujuan

Menyiapkan legal/commercial pack: Terms of Service, Privacy Policy, SLA, support policy, DPA outline, security statement, dan acceptable use.

## Fokus

```text
terms, privacy, SLA, support policy, security statement, payment terms, trial terms
```

## Output Wajib

```text
Commercial asset
Copy/template/checklist
Owner and usage guide
Acceptance criteria
Review checklist
Implementation note
```

## Area yang Harus Dicek

```text
Market clarity
Buyer persona
CTA
Trial/demo conversion
Sales usefulness
Customer onboarding
Support readiness
Legal/commercial readiness
Launch risk
Post-launch measurement
```

## Acceptance Criteria

- Asset bisa langsung dipakai atau digenerate menjadi halaman/dokumen.
- Pesan produk jelas.
- CTA jelas.
- Launch risk dicatat.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI COMMERCIAL LAUNCH SEQUENCE 05: Terms of Service, Privacy Policy, SLA & Legal Pack
```
