# 03 Sales Deck, Proposal Template & Demo Script

## Tujuan

Membuat sales deck, proposal template, demo script, use-case pitch, objection handling, dan proof point.

## Fokus

```text
sales deck, proposal, demo script, objection handling, industry pitch, proof point
```

## Output Wajib

```text
Commercial asset
Copy/template/checklist
Owner and usage guide
Acceptance criteria
Review checklist
Implementation note
```

## Area yang Harus Dicek

```text
Market clarity
Buyer persona
CTA
Trial/demo conversion
Sales usefulness
Customer onboarding
Support readiness
Legal/commercial readiness
Launch risk
Post-launch measurement
```

## Acceptance Criteria

- Asset bisa langsung dipakai atau digenerate menjadi halaman/dokumen.
- Pesan produk jelas.
- CTA jelas.
- Launch risk dicatat.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI COMMERCIAL LAUNCH SEQUENCE 03: Sales Deck, Proposal Template & Demo Script
```
