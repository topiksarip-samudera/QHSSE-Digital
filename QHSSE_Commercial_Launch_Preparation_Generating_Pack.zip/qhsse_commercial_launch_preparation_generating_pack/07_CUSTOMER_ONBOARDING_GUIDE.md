# 07 — CUSTOMER ONBOARDING GUIDE

## Onboarding Flow

```text
1. Welcome email
2. Kickoff meeting
3. Tenant setup
4. Admin user setup
5. Role and permission mapping
6. Module selection
7. Master data setup
8. Data import if needed
9. Training session
10. Pilot workflow
11. First report review
12. Go-live confirmation
```

## Onboarding Checklist

```text
Tenant created
Admin invited
Company profile completed
Sites/projects created
Departments created
Roles configured
Users invited
Modules enabled
Master data imported
Training completed
Support channel confirmed
Success milestone agreed
```

## Success Milestones

```text
First incident created
First inspection completed
First permit approved
First document published
First training session recorded
First report exported
First AI assistant usage
First mobile field submission
```
