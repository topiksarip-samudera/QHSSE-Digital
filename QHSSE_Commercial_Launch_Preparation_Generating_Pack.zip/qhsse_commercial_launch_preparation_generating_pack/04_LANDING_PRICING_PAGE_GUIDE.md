# 04 — LANDING & PRICING PAGE GUIDE

## Landing Page Sections

```text
Hero
Problem
Solution
Core Modules
AI Assistant
Mobile/PWA Field Operation
Reports & Analytics
SaaS & Multi-Tenant
Use Cases
Industries
Security & Compliance
Demo CTA
FAQ
Final CTA
```

## Hero Example

```text
Headline:
Digital QHSSE Platform for Safer, Smarter, and More Compliant Operations

Subheadline:
Manage incidents, risks, audits, permits, training, compliance, environment, quality, security, contractors, emergency response, assets, analytics, AI assistant, and mobile field workflows in one integrated SaaS platform.

CTA:
Request Demo
Start Trial
View Pricing
```

## Pricing Plans

```text
Starter
Professional
Enterprise
```

## Plan Comparison Columns

```text
Core Platform
Incident Management
Risk Management
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
Mobile/PWA
Storage
User Seats
Support SLA
White Label
Custom Domain
API Access
```
