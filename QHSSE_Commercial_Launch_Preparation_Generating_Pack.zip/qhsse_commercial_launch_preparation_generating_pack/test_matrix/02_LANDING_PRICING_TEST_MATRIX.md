# 02 Landing Pricing Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| CLP-001 | Landing hero ready | PASS |
| CLP-002 | Module section ready | PASS |
| CLP-003 | CTA ready | PASS |
| CLP-004 | FAQ ready | PASS |
| CLP-005 | Pricing plans ready | PASS |
| CLP-006 | Plan comparison ready | PASS |
| CLP-007 | Trial CTA ready | PASS |
| CLP-008 | Conversion path ready | PASS |
