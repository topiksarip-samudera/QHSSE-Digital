# 02 — COMMERCIAL LAUNCH GENERATING RULES

## Aturan Utama

1. Jangan membuat launch preparation sebagai ide umum saja.
2. Setiap sequence harus menghasilkan asset nyata yang bisa dipakai.
3. Landing page harus punya headline, subheadline, feature section, module section, CTA, FAQ, dan trust section.
4. Pricing page harus punya plan, package, comparison, FAQ, dan CTA.
5. Sales deck harus punya problem, solution, value, module, demo flow, pricing, proof, next step.
6. Proposal template harus bisa dikirim ke calon customer.
7. Demo script harus role-based dan industry-based.
8. Public documentation harus punya getting started dan FAQ.
9. Legal pack harus minimal mencakup ToS, Privacy, SLA, Support Policy, Security Statement.
10. Onboarding package harus berisi checklist, timeline, role mapping, training, data setup.
11. Campaign harus punya email sequence, social content, and CTA.
12. Customer success harus punya health score, support SLA, adoption tracking.
13. CRM pipeline harus punya stage dan lead qualification.
14. Launch readiness harus punya go/no-go criteria.
15. Post-launch harus punya 30/60/90 day improvement plan.

## Positioning Rule

Gunakan pesan utama:

```text
QHSSE SaaS all-in-one untuk digitalisasi safety, compliance, audit, permit, training, environment, quality, security, contractor, emergency, asset, analytics, AI, dan mobile field operation.
```

## Asset Quality Rule

Setiap asset harus:
```text
Clear
Actionable
Reusable
Structured
Ready for AI generation
Ready for implementation
```
