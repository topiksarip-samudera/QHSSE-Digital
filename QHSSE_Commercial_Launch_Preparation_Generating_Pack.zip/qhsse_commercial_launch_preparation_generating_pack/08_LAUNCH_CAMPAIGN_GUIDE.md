# 08 — LAUNCH CAMPAIGN GUIDE

## Campaign Assets

```text
Launch announcement
Email sequence
LinkedIn posts
WhatsApp broadcast optional
Webinar invitation
Demo booking page
Lead magnet
Case study / use case story
FAQ
Trial CTA
```

## Email Sequence

```text
Email 1: Launch Announcement
Email 2: Problem & Solution
Email 3: Module Overview
Email 4: Mobile/PWA + AI Assistant
Email 5: Demo Invitation
Email 6: Pricing / Trial CTA
Email 7: Last Call / Follow-up
```

## Social Content Themes

```text
Stop managing QHSSE with scattered spreadsheets
From field report to executive dashboard
Permit, incident, audit, and compliance in one system
AI-assisted QHSSE workflow
Mobile-first safety reporting
```
