# CRM Pipeline Template

| Lead | Company | Industry | Stage | Need | Users | Sites | Next Action | Owner | Status |
|---|---|---|---|---|---|---|---|---|---|
|  |  |  | Lead Captured |  |  |  |  |  | Open |
