# 05 — SALES, PROPOSAL & DEMO GUIDE

## Sales Deck Structure

```text
1. Title
2. The QHSSE Problem
3. Current Manual Pain
4. Product Overview
5. Key Modules
6. Field Operation with Mobile/PWA
7. AI Assistant
8. Reports & Analytics
9. SaaS / Multi-Tenant Capability
10. Use Case Demo
11. Implementation Plan
12. Pricing Overview
13. Security & Reliability
14. Next Step
```

## Proposal Template Structure

```text
Cover
Executive Summary
Customer Pain Point
Proposed Solution
Module Scope
Implementation Timeline
Training & Onboarding
Support & SLA
Commercial Terms
Assumptions
Next Step
```

## Demo Script Flow

```text
Login as Admin
Show dashboard
Create incident
Run RCA/CAPA
Open risk/HIRADC
Create PTW
Run inspection
Show document control
Show training matrix
Show reports
Ask AI Assistant
Open mobile/PWA flow
Show SaaS admin/billing if needed
Close with business value
```
