# 00 — PROMPT AWAL COMMERCIAL LAUNCH PREPARATION UNTUK AI AGENT

Core Platform, seluruh QHSSE Operational Modules, Reports & Analytics, AI Assistant, Mobile/PWA Field Optimization, SaaS Commercialization, Production Hardening & Go-Live Preparation, dan Beta Testing & Pilot Customer Program sudah selesai atau siap integrasi.

Platform yang akan disiapkan untuk commercial launch:

```text
Core Platform
Stabilization & QA
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
Mobile/PWA Field Optimization
SaaS Commercialization
Production Hardening & Go-Live Preparation
Beta Testing & Pilot Customer Program
```

Sekarang generate tahap **Commercial Launch Preparation** berdasarkan folder `qhsse_commercial_launch_preparation_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_product_positioning_brand_value_proposition.md`.
3. Tahap ini tidak boleh hanya membuat daftar ide marketing.
4. Harus menghasilkan launch asset nyata: positioning, landing page copy, pricing page, sales deck outline, proposal template, demo script, documentation, legal pack outline, onboarding package, campaign sequence, CRM pipeline, support operations, launch checklist, dan post-launch monitoring plan.
5. Harus mencakup target market QHSSE/HSE/Compliance/Operational Safety.
6. Harus mencakup packaging produk berdasarkan modul dan subscription.
7. Harus mencakup sales and customer success readiness.
8. Harus mencakup legal/commercial readiness.
9. Harus mencakup demo tenant dan use-case story.
10. Harus mencakup trial conversion dan lead capture.
11. Harus mencakup launch readiness review dan risk control.
12. Harus mencakup post-launch monitoring dan improvement roadmap.
13. Semua output harus bisa dipakai oleh AI agent untuk membuat halaman, dokumen, template, dan workflow.
14. Setelah sequence selesai, tulis:
   `SELESAI COMMERCIAL LAUNCH SEQUENCE XX: <nama sequence>`
15. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
