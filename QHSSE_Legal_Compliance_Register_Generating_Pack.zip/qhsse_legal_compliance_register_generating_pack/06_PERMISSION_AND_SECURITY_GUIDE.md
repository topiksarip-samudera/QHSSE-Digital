# PERMISSION & SECURITY GUIDE

## Scope

```text
Global
Company
Site
Project
Department
Owner Department
Responsible Person
Assessor
Reviewer
Approver
Evidence Owner
Gap PIC
```

## Security Rules

- Semua query wajib filter `company_id`.
- User site scope hanya boleh melihat obligation/evidence/gap yang applicable ke sitenya.
- Evidence restricted mengikuti permission document/file.
- Assessment approval butuh role khusus.
- Gap close butuh verification permission.
- Export evidence/register harus audit logged.
- Regulatory update deletion dibatasi; prefer archive.
- AI boleh membantu draft obligation/gap summary, final compliance decision tetap human-reviewed.
