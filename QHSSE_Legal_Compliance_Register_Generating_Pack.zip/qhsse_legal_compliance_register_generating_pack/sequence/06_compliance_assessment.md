# LEGAL COMPLIANCE SEQUENCE 06 — Compliance Assessment

## Tujuan

Assessment periodik, assessment items, evidence review, compliance status, score, reviewer, approver.

## Scope

Sequence ini harus menghasilkan database, backend API, frontend UI, permission, audit log, test minimal, dan acceptance criteria.

## Database yang Mungkin Dibuat/Diubah

```text
legal_compliance_settings
regulation_types
regulation_categories
regulations
regulation_versions
legal_requirements
compliance_obligations
obligation_applicability
compliance_evidence
compliance_assessments
compliance_assessment_items
compliance_gaps
compliance_gap_actions
compliance_reviews
regulatory_update_logs
compliance_calendar_events
compliance_links
compliance_scores
```

Gunakan hanya tabel yang relevan untuk sequence ini. Jangan duplikasi tabel core yang sudah ada.

## Frontend Minimal

```text
List page
Create/update form
Detail page
Status badge
Filter/search
Matrix/table view jika relevan
Evidence panel jika relevan
Action panel jika relevan
Workflow tab jika relevan
Attachment tab jika relevan
Comment tab jika relevan
Audit trail tab jika relevan
```

## Permission

Terapkan permission dan scope sesuai `06_PERMISSION_AND_SECURITY_GUIDE.md`.

## Audit Log

Catat create/update/delete/archive/activate/assess/verify/evidence/gap/action/review/export sesuai sequence.

## Testing Minimal

```text
Happy path
Validation error
Permission denied
Tenant isolation
Audit log created
Status transition
Evidence security jika relevan
```

## Acceptance Criteria

- [ ] Fitur sequence berjalan end-to-end.
- [ ] Tenant-safe.
- [ ] Permission backend berjalan.
- [ ] UI tidak menampilkan tombol tanpa permission.
- [ ] Audit log tercatat.
- [ ] Compliance decision penting tetap human-reviewed.
- [ ] Test minimal lulus.
- [ ] Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI LEGAL COMPLIANCE SEQUENCE 06: Compliance Assessment
```
