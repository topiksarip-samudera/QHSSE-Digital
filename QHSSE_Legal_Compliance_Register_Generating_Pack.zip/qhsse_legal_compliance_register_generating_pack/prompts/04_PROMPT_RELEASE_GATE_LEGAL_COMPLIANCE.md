# Prompt Release Gate Legal & Compliance Register

Jalankan release gate Legal & Compliance Register.

Cek:
- P0 = 0
- P1 = 0
- Tenant isolation PASS
- Permission backend PASS
- Regulation register PASS
- Requirement mapping PASS
- Obligation mapping PASS
- Applicability matrix PASS
- Evidence register PASS
- Compliance assessment PASS
- Gap to action integration PASS
- Review schedule PASS
- Compliance calendar PASS
- Audit log PASS
- Dashboard calculation PASS
- Report export PASS
- Cross-module integration PASS
- Lint/test/build PASS

Jika lulus tulis `LEGAL COMPLIANCE STABILIZED: GO`.
Jika gagal tulis `LEGAL COMPLIANCE STABILIZED: NO-GO` dan sertakan blocking issue.
