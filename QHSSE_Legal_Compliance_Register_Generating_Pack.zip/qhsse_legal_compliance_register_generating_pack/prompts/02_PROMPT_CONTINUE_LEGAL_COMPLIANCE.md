# Prompt Continue Legal & Compliance Sequence

Continue Legal & Compliance Sequence.

Kerjakan sequence berikutnya sesuai `sequence/00_LEGAL_COMPLIANCE_SEQUENCE.md`.

Aturan:
- Jangan lompat sequence.
- Jangan lanjut sequence berikutnya setelah selesai.
- Pastikan database, backend, frontend, permission, audit log, dan test selesai.
- Jika sequence selesai, tulis `SELESAI LEGAL COMPLIANCE SEQUENCE XX: <nama sequence>`.
