# Prompt Fix Legal & Compliance Register

Review modul Legal & Compliance Register yang terakhir dibuat.

Periksa tenant isolation, permission backend, regulation register, requirement mapping, obligation mapping, applicability matrix, evidence security, assessment workflow, gap to action integration, calendar notification, dashboard calculation, report export, cross-module links, audit log, build/lint/test.

Perbaiki semua bug P0/P1. Setelah selesai tulis:

```text
LEGAL COMPLIANCE FIXED
```
