# Prompt Start Legal & Compliance Register

Core Platform sudah stabil. Incident Management, Risk Management, Audit & Inspection, Permit to Work, Document Control, dan Training & Competency sudah selesai atau siap integrasi.

Sekarang generate Legal & Compliance Register berdasarkan `qhsse_legal_compliance_register_generating_pack`.

Mulai dari `sequence/01_foundation_master_data.md`.

Kerjakan sequence pertama saja.

Setelah selesai tulis:

```text
SELESAI LEGAL COMPLIANCE SEQUENCE 01: Foundation & Master Data
```

Jangan lanjut sequence berikutnya sebelum saya minta continue.
