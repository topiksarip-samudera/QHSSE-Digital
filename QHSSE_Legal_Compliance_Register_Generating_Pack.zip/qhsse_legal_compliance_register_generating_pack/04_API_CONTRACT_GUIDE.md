# API CONTRACT GUIDE

Prefix: `/api/v1`

## Regulation

```text
GET    /regulations
POST   /regulations
GET    /regulations/:id
PATCH  /regulations/:id
DELETE /regulations/:id
POST   /regulations/:id/activate
POST   /regulations/:id/supersede
POST   /regulations/:id/archive
GET    /regulations/:id/versions
POST   /regulations/:id/versions
```

## Requirement & Obligation

```text
GET    /legal-requirements
POST   /legal-requirements
GET    /legal-requirements/:id
PATCH  /legal-requirements/:id
GET    /regulations/:id/requirements
POST   /regulations/:id/requirements
GET    /compliance-obligations
POST   /compliance-obligations
GET    /compliance-obligations/:id
PATCH  /compliance-obligations/:id
```

## Applicability & Evidence

```text
GET  /compliance-obligations/:id/applicability
POST /compliance-obligations/:id/applicability
PATCH /obligation-applicability/:id
POST /obligation-applicability/:id/approve
GET  /compliance-evidence
POST /compliance-evidence
GET  /compliance-evidence/:id
PATCH /compliance-evidence/:id
POST /compliance-evidence/:id/verify
POST /compliance-evidence/:id/reject
```

## Assessment & Gap

```text
GET  /compliance-assessments
POST /compliance-assessments
GET  /compliance-assessments/:id
PATCH /compliance-assessments/:id
POST /compliance-assessments/:id/submit
POST /compliance-assessments/:id/approve
POST /compliance-assessments/:id/generate-gaps
GET  /compliance-gaps
POST /compliance-gaps
GET  /compliance-gaps/:id
PATCH /compliance-gaps/:id
POST /compliance-gaps/:id/assign-action
POST /compliance-gaps/:id/verify
POST /compliance-gaps/:id/close
```

## Calendar, Dashboard, Report

```text
GET /legal-compliance/calendar
GET /legal-compliance/dashboard
GET /legal-compliance/kpi
GET /legal-compliance/compliance-score
GET /legal-compliance/audit-readiness
GET /legal-compliance/review-due
GET /legal-compliance/evidence-missing
GET /legal-compliance/export
```
