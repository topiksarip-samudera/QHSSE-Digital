# DATABASE MODEL GUIDE

## Tabel Minimal

```text
legal_compliance_settings
regulation_types
regulation_categories
regulations
regulation_versions
legal_requirements
compliance_obligations
obligation_applicability
compliance_evidence
compliance_assessments
compliance_assessment_items
compliance_gaps
compliance_gap_actions
compliance_reviews
regulatory_update_logs
compliance_calendar_events
compliance_links
compliance_scores
```

## Common Fields

```text
id
company_id
site_id optional
department_id optional
location_id optional
created_by
updated_by
created_at
updated_at
deleted_at optional
status
```

## Main Fields

### regulations

```text
regulation_number
title
regulation_type_id
regulation_category_id
issuing_authority
jurisdiction
effective_date
source_url
summary
owner_id
current_version_id
status
```

### legal_requirements

```text
regulation_id
requirement_number
clause_reference
requirement_title
requirement_text
requirement_summary
requirement_category
risk_level
mandatory_evidence
review_frequency_months
status
```

### compliance_obligations

```text
requirement_id
obligation_number
obligation_title
obligation_description
obligation_type
responsible_department_id
responsible_person_id
evidence_required
assessment_frequency_months
next_assessment_date
status
```

### obligation_applicability

```text
obligation_id
site_id
department_id
activity_id optional
asset_type_id optional
permit_type_id optional
applicability_status
justification
reviewed_by
approved_by
approved_at
```

### compliance_evidence

```text
obligation_id
evidence_number
evidence_type
source_module
source_record_id
document_id
file_id
description
evidence_date
valid_until
verification_status
verified_by
verified_at
```

### compliance_gaps

```text
gap_number
obligation_id
assessment_id
gap_title
gap_description
severity
root_cause
action_required
action_id
due_date
pic_id
verification_status
status
```
