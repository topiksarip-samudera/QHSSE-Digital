# UI / UX GUIDE

## Sidebar

```text
Legal & Compliance
├── Overview
├── Regulation Register
├── Legal Requirements
├── Compliance Obligations
├── Applicability Matrix
├── Evidence Register
├── Compliance Assessment
├── Compliance Gaps
├── Regulatory Updates
├── Compliance Calendar
├── Reports
└── Settings
```

## Detail Tabs

```text
Overview
Requirements
Obligations
Applicability
Evidence
Assessments
Gaps
Actions
Linked Records
Attachments
Comments
Audit Trail
```

## Components

```text
ComplianceStatusBadge
ApplicabilityBadge
ObligationMatrix
EvidenceCard
AssessmentScoreCard
ComplianceGapCard
ComplianceCalendar
RegulatoryUpdateTimeline
AuditReadinessPanel
ComplianceHeatmap
EvidenceVerificationPanel
```
