# PROMPT AWAL LEGAL & COMPLIANCE REGISTER

Core Platform sudah stabil. Incident Management, Risk Management, Audit & Inspection, Permit to Work, Document Control, dan Training & Competency sudah selesai atau siap integrasi.

Sekarang generate **Legal & Compliance Register** berdasarkan folder `qhsse_legal_compliance_register_generating_pack`.

Aturan wajib:
1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_master_data.md`.
3. Gunakan Core Platform: tenant, site, department, role permission, module ON/OFF, master data, workflow, action tracking, attachment/evidence, audit log, notification, numbering, calendar, dashboard, API/webhook.
4. Modul ini tidak boleh hanya daftar regulasi.
5. Harus ada regulation register, requirement mapping, obligation mapping, applicability matrix, evidence register, compliance assessment, gap analysis, action plan, review schedule, regulatory update log, compliance calendar, dashboard, dan QA.
6. Semua data wajib tenant-safe dengan `company_id`.
7. Semua API wajib permission-guarded.
8. Semua compliance decision penting harus human-reviewed.
9. Setelah selesai tulis `SELESAI LEGAL COMPLIANCE SEQUENCE 01: Foundation & Master Data`.
10. Jangan lanjut sequence berikutnya sebelum saya minta continue.
