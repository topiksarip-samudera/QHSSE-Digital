# Legal Compliance Core Test Matrix

| ID | Area | Scenario | Expected |
|---|---|---|---|
| LC-001 | Regulation | Create regulation | Success |
| LC-002 | Regulation | Add version | Version saved |
| LC-003 | Requirement | Create requirement from regulation | Success |
| LC-004 | Obligation | Create obligation from requirement | Success |
| LC-005 | Applicability | Set site applicable | Matrix updated |
| LC-006 | Evidence | Add document evidence | Evidence linked |
| LC-007 | Assessment | Create assessment | Success |
| LC-008 | Gap | Generate gap from non-compliance | Gap created |
