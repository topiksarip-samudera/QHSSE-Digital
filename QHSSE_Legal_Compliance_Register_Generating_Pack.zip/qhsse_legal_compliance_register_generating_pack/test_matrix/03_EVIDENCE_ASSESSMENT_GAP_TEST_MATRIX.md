# Evidence, Assessment & Gap Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| EAG-001 | Obligation requires evidence but none exists | Evidence missing |
| EAG-002 | Evidence expired | Evidence invalid/warning |
| EAG-003 | Evidence verified | Status verified |
| EAG-004 | Assessment non-compliant | Gap can be generated |
| EAG-005 | Gap assigned action | Action Tracking linked |
| EAG-006 | Action completed | Gap pending verification |
| EAG-007 | Gap verified | Gap closed |
| EAG-008 | Assessment approved | Overall score stored |
