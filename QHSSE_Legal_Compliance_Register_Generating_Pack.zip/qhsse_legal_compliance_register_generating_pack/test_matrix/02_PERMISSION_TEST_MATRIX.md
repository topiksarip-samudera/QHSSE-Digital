# Permission Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PERM-001 | User without legal_compliance.view opens register | 403 / hidden UI |
| PERM-002 | User without regulation.create creates regulation | 403 |
| PERM-003 | User without obligation.assess assesses obligation | 403 |
| PERM-004 | User without evidence.verify verifies evidence | 403 |
| PERM-005 | User without gap.close closes gap | 403 |
| PERM-006 | Site A user accesses Site B obligation | 403/404 |
| PERM-007 | User without export exports evidence | 403 |
| PERM-008 | Export evidence | Audit log created |
