# Calendar & Notification Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| CAL-001 | Obligation review due | Calendar event appears |
| CAL-002 | Evidence due soon | Notification sent |
| CAL-003 | Assessment overdue | Escalation triggered |
| CAL-004 | Gap overdue | PIC and manager notified |
| CAL-005 | Regulatory update logged | Review task created |
| CAL-006 | User without scope | Does not receive unrelated notification |
