# Dashboard & Report Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| DR-001 | Compliance score | Accurate |
| DR-002 | Evidence missing count | Accurate |
| DR-003 | Open gap count | Accurate |
| DR-004 | Overdue gap count | Accurate |
| DR-005 | Review due count | Accurate |
| DR-006 | Compliance by site | Accurate and scoped |
| DR-007 | Export legal register | Scoped data only |
| DR-008 | Audit readiness report | Generated |
