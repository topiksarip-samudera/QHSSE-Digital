# CROSS-MODULE INTEGRATION GUIDE

## Document Control

```text
Legal evidence can link to document/revision.
Regulation file can be stored as controlled document.
Obligation can trigger SOP/policy revision.
```

## Training & Competency

```text
Obligation can create mandatory training.
Training certificate can be evidence.
Training compliance can affect obligation status.
```

## Audit & Inspection

```text
Obligation can become audit checklist item.
Audit finding can create compliance gap.
Compliance assessment can reuse audit evidence.
```

## Permit to Work

```text
Legal requirement can define mandatory permit type.
Permit record can become compliance evidence.
Missing permit for regulated activity can create gap.
```

## Risk, Incident, Environment, Asset

```text
Non-compliance can create compliance risk.
Incident report can be legal evidence.
Environment monitoring/manifest can be evidence.
Asset certificate/calibration can be evidence.
```
