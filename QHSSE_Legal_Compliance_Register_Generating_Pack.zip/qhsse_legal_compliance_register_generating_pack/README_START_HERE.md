# START HERE — QHSSE Legal & Compliance Register Generating Pack

Paket ini untuk generate modul **Legal & Compliance Register** setelah Training & Competency.

## Rekomendasi Split

Sebaiknya di-split menjadi **12 sequence**:

```text
01 Foundation & Master Data
02 Regulation & Standard Register
03 Legal Requirement / Obligation Mapping
04 Applicability Matrix by Site / Department / Activity
05 Evidence Register & Document Link
06 Compliance Assessment
07 Gap Analysis & Corrective Action
08 Review Schedule & Regulatory Update Log
09 Integration with Audit, Document, Training, Permit & Risk
10 Dashboard, Compliance Score & Reporting
11 Notification, Escalation & Compliance Calendar
12 QA, Test, Permission & Stabilization
```

## Cara Pakai

1. Extract ZIP ke project.
2. Baca `00_PROMPT_AWAL_LEGAL_COMPLIANCE.md`.
3. Mulai dari `sequence/01_foundation_master_data.md`.
4. Kerjakan satu sequence saja.
5. Setelah selesai tulis `SELESAI LEGAL COMPLIANCE SEQUENCE XX`.
6. Jangan lanjut sequence berikutnya sebelum diminta.

Status akhir:

```text
LEGAL COMPLIANCE STABILIZED: GO
```
