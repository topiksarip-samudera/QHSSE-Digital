# LEGAL & COMPLIANCE GENERATING RULES

## Aturan Utama

1. Jangan membuat modul sebagai tabel regulasi biasa.
2. Regulation harus punya version dan status.
3. Requirement/obligation harus bisa dimapping.
4. Applicability matrix wajib ada.
5. Evidence register wajib bisa link ke modul lain.
6. Assessment wajib menghasilkan status/score/evidence/gap.
7. Gap wajib bisa membuat action.
8. Calendar dan notification wajib untuk review due, assessment due, evidence due, dan gap overdue.
9. Semua critical changes wajib audit log.
10. Semua data wajib tenant-safe.
11. Semua API wajib permission guard.

## Permission Standard

```text
legal_compliance.view
legal_compliance.view_all
legal_compliance.create
legal_compliance.update
legal_compliance.delete
legal_compliance.review
legal_compliance.approve
legal_compliance.assess
legal_compliance.export
legal_compliance.manage_settings
regulation.view
regulation.create
regulation.update
regulation.archive
obligation.view
obligation.create
obligation.update
obligation.assess
compliance_evidence.view
compliance_evidence.create
compliance_evidence.verify
compliance_gap.view
compliance_gap.create
compliance_gap.assign_action
compliance_gap.verify
compliance_gap.close
```

## Audit Log Wajib

```text
regulation.created
regulation.updated
regulation.activated
regulation.superseded
requirement.created
obligation.created
applicability.changed
evidence.added
evidence.verified
assessment.created
assessment.approved
gap.created
gap.action_assigned
gap.closed
review.completed
regulatory_update.created
report.exported
settings.changed
```
