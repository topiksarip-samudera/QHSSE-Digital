# Prompt Release Gate Emergency Response

Jalankan release gate Emergency Response.

Cek:
- P0 = 0
- P1 = 0
- Tenant isolation PASS
- Permission backend PASS
- Emergency plan workflow PASS
- Emergency contact/team PASS
- Muster point/evacuation route PASS
- Equipment readiness PASS
- Drill schedule/execution PASS
- Drill finding to action PASS
- Crisis notification PASS
- Acknowledgement tracking PASS
- Dashboard calculation PASS
- Report export PASS
- Audit log PASS
- Cross-module integration PASS
- Lint/test/build PASS

Jika lulus tulis:

```text
EMERGENCY RESPONSE STABILIZED: GO
```

Jika gagal tulis:

```text
EMERGENCY RESPONSE STABILIZED: NO-GO
```

Sertakan blocking issue.
