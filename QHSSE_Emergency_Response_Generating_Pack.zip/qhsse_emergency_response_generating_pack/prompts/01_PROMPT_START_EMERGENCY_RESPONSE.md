# Prompt Start Emergency Response

Core Platform sudah stabil. Contractor Management, Incident Management, Training & Competency, Asset & Equipment, Document Control, Audit & Inspection, Permit to Work, Security Management, dan Environment Management sudah selesai atau siap integrasi.

Sekarang generate Emergency Response berdasarkan `qhsse_emergency_response_generating_pack`.

Mulai dari:

```text
sequence/01_foundation_master_data.md
```

Kerjakan sequence pertama saja.

Setelah selesai tulis:

```text
SELESAI EMERGENCY SEQUENCE 01: Foundation & Master Data
```

Jangan lanjut sequence berikutnya sebelum saya minta continue.
