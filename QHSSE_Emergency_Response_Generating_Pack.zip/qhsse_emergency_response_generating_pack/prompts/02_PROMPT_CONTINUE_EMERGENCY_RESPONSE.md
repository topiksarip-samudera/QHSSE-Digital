# Prompt Continue Emergency Response Sequence

Continue Emergency Response Sequence.

Kerjakan sequence berikutnya sesuai:

```text
sequence/00_EMERGENCY_SEQUENCE.md
```

Aturan:
- Jangan lompat sequence.
- Jangan lanjut sequence berikutnya setelah selesai.
- Pastikan database, backend, frontend, permission, audit log, dan test selesai.
- Jika sequence selesai, tulis:
  `SELESAI EMERGENCY SEQUENCE XX: <nama sequence>`
