# Prompt Fix Emergency Response

Review modul Emergency Response yang terakhir dibuat.

Periksa:
- Tenant isolation
- Permission backend
- Emergency plan workflow
- Emergency contact/team
- Muster point and evacuation route
- Equipment readiness
- Drill schedule/execution
- Drill finding to action
- Crisis notification
- Acknowledgement tracking
- Dashboard calculation
- Report export
- Cross-module links
- Audit log
- Build/lint/test

Perbaiki semua bug P0/P1. Setelah selesai tulis:

```text
EMERGENCY RESPONSE FIXED
```
