# 06 — PERMISSION & SECURITY GUIDE

## Permission Groups

```text
emergency.view
emergency.view_all
emergency.create
emergency.update
emergency.delete
emergency.submit
emergency.review
emergency.approve
emergency.activate
emergency.close
emergency.export
emergency.manage_settings

emergency_plan.view
emergency_plan.create
emergency_plan.update
emergency_plan.approve
emergency_plan.publish

emergency_team.view
emergency_team.manage

emergency_equipment.view
emergency_equipment.create
emergency_equipment.update
emergency_equipment.inspect

emergency_drill.view
emergency_drill.create
emergency_drill.execute
emergency_drill.evaluate
emergency_drill.approve_report

crisis_notification.view
crisis_notification.create
crisis_notification.broadcast
crisis_notification.acknowledge
```

## Scope

```text
Global
Company
Site
Project
Department
Emergency Team Member
Drill Participant
Observer
Evaluator
Approver
Security
HSE
Management
```

## Security Rules

- Semua query wajib filter company_id.
- Emergency contact detail dapat dibatasi sesuai role/scope.
- Crisis notification broadcast hanya untuk role berwenang.
- Drill attendance dapat diinput oleh assigned organizer.
- Equipment inspection hanya oleh role berwenang.
- Export report wajib audit log.
- Crisis event data sensitif harus permission-aware.
