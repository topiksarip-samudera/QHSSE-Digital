# 05 — UI/UX GUIDE EMERGENCY RESPONSE

## Sidebar

```text
Emergency Response
├── Overview
├── Emergency Plans
├── Emergency Scenarios
├── Emergency Contacts
├── Emergency Team
├── Muster Points
├── Evacuation Routes
├── Emergency Equipment
├── Fire Equipment
├── Drill Schedule
├── Drill Execution
├── Crisis Notification
├── Reports
└── Settings
```

## Detail Tabs

Emergency Plan:

```text
Overview
Scenarios
Team & Roles
Contacts
Muster Points
Evacuation Routes
Equipment
Linked Documents
Workflow
Review History
Audit Trail
```

Drill Execution:

```text
Overview
Scenario
Participants
Attendance
Evidence
Evaluation
Findings
Actions
Report
Audit Trail
```

Emergency Equipment:

```text
Overview
Inspection History
Readiness
Location
Attachments
Actions
Audit Trail
```

## Komponen Wajib

```text
EmergencyPlanStatusBadge
EmergencyTypeBadge
ReadinessScoreCard
EmergencyContactList
EmergencyTeamMatrix
MusterPointMap
EvacuationRoutePanel
EquipmentReadinessBadge
DrillScheduleCalendar
DrillAttendanceTable
DrillEvaluationPanel
CrisisNotificationPanel
AcknowledgementTracker
```

## UX Penting

- Emergency contact harus cepat diakses.
- Crisis notification harus sederhana dan cepat.
- Drill attendance harus mobile-friendly.
- Equipment not ready harus terlihat jelas.
- Readiness score harus bisa drill down ke penyebabnya.
- Report drill harus mudah diexport.
