# 04 — API CONTRACT GUIDE

Gunakan prefix:

```text
/api/v1
```

## Emergency Plan

```text
GET    /emergency-plans
POST   /emergency-plans
GET    /emergency-plans/:id
PATCH  /emergency-plans/:id
DELETE /emergency-plans/:id
POST   /emergency-plans/:id/submit
POST   /emergency-plans/:id/review
POST   /emergency-plans/:id/approve
POST   /emergency-plans/:id/activate
POST   /emergency-plans/:id/archive
```

## Contacts, Team, Role

```text
GET  /emergency-contacts
POST /emergency-contacts
PATCH /emergency-contacts/:id
GET  /emergency-teams
POST /emergency-teams
GET  /emergency-teams/:id/members
POST /emergency-teams/:id/members
PATCH /emergency-team-members/:id
GET  /emergency-roles
POST /emergency-roles
```

## Muster Point & Evacuation

```text
GET  /muster-points
POST /muster-points
PATCH /muster-points/:id
GET  /evacuation-routes
POST /evacuation-routes
PATCH /evacuation-routes/:id
GET  /emergency-site-maps
POST /emergency-site-maps
```

## Equipment

```text
GET  /emergency-equipment
POST /emergency-equipment
GET  /emergency-equipment/:id
PATCH /emergency-equipment/:id
POST /emergency-equipment/:id/inspect
POST /emergency-equipment/:id/mark-out-of-service
POST /emergency-equipment/:id/restore
```

## Drill

```text
GET  /drill-plans
POST /drill-plans
GET  /drill-schedules
POST /drill-schedules
GET  /drill-executions
POST /drill-executions
GET  /drill-executions/:id
PATCH /drill-executions/:id
POST /drill-executions/:id/attendance
POST /drill-executions/:id/evaluate
POST /drill-executions/:id/create-finding
POST /drill-executions/:id/approve-report
```

## Crisis Notification

```text
GET  /crisis-notifications
POST /crisis-notifications
GET  /crisis-notifications/:id
POST /crisis-notifications/:id/broadcast
POST /crisis-notifications/:id/acknowledge
GET  /crisis-notifications/:id/recipients
```

## Dashboard & Reports

```text
GET /emergency-response/dashboard
GET /emergency-response/kpi
GET /emergency-response/readiness-score
GET /emergency-response/drill-completion
GET /emergency-response/equipment-readiness
GET /emergency-response/export
GET /emergency-response/reports/:type
```

## Settings

```text
GET   /emergency-response/settings
PATCH /emergency-response/settings
GET   /emergency-response/master-data
```
