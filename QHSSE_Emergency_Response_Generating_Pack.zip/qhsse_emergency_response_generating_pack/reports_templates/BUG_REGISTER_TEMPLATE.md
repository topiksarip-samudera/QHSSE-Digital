# Bug Register — Emergency Response

| Bug ID | Date | Sequence | Severity | Title | Steps | Expected | Actual | Status | Fixed In |
|---|---|---|---|---|---|---|---|---|---|
| ER-BUG-001 |  |  | P0/P1/P2/P3 |  |  |  |  | Open/In Progress/Fixed/Closed |  |
