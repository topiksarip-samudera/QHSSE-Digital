# 02 — EMERGENCY RESPONSE GENERATING RULES

## Aturan Utama

1. Jangan membuat Emergency Response sebagai daftar kontak saja.
2. Emergency plan harus punya scenario, site applicability, review, dan approval.
3. Emergency team harus punya role/responsibility/contact/backup.
4. Muster point dan evacuation route harus bisa dikelola per site/location.
5. Emergency equipment harus punya readiness/inspection/expiry status.
6. Drill harus punya plan, schedule, execution, attendance, evaluation, finding, action, dan report.
7. Crisis notification harus bisa broadcast, escalate, dan track acknowledgement.
8. Emergency readiness score harus dihitung dari plan, team, equipment, drill, training, dan actions.
9. Semua critical change wajib audit log.
10. Semua data wajib tenant-safe.
11. Semua API wajib permission-guarded.

## Permission Standard

```text
emergency.view
emergency.view_all
emergency.create
emergency.update
emergency.delete
emergency.submit
emergency.review
emergency.approve
emergency.activate
emergency.close
emergency.export
emergency.manage_settings

emergency_plan.view
emergency_plan.create
emergency_plan.update
emergency_plan.approve
emergency_plan.publish

emergency_team.view
emergency_team.manage

emergency_equipment.view
emergency_equipment.create
emergency_equipment.update
emergency_equipment.inspect

emergency_drill.view
emergency_drill.create
emergency_drill.execute
emergency_drill.evaluate
emergency_drill.approve_report

crisis_notification.create
crisis_notification.broadcast
crisis_notification.acknowledge
```

## Audit Log Wajib

```text
emergency_plan.created
emergency_plan.updated
emergency_plan.approved
emergency_plan.activated
emergency_team.updated
muster_point.created
evacuation_route.updated
equipment.created
equipment.inspected
equipment.status_changed
drill.created
drill.scheduled
drill.executed
drill.evaluated
drill.finding_created
drill.report_approved
crisis_notification.sent
crisis_notification.acknowledged
report.exported
settings.changed
```

## Webhook Events

```text
emergency.plan_approved
emergency.plan_review_due
emergency.equipment_not_ready
emergency.equipment_inspection_due
emergency.drill_scheduled
emergency.drill_completed
emergency.finding_created
emergency.action_overdue
emergency.crisis_notification_sent
emergency.readiness_low
```
