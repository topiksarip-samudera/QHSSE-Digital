# 00 — PROMPT AWAL EMERGENCY RESPONSE UNTUK AI AGENT

Core Platform sudah stabil. Contractor Management, Incident Management, Training & Competency, Asset & Equipment, Document Control, Audit & Inspection, Permit to Work, Security Management, Environment Management, dan Action Tracking sudah selesai atau siap integrasi.

Sekarang mulai generate QHSSE Operational Module: **Emergency Response**.

Baca seluruh file dalam folder `qhsse_emergency_response_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_master_data.md`.
3. Gunakan core yang sudah ada:
   - Company / tenant
   - Site / project / department / location
   - Role & permission
   - Module ON/OFF
   - Master data
   - Workflow
   - Action tracking
   - Attachment/evidence
   - Audit log
   - Notification
   - Calendar/schedule
   - Numbering
   - Dashboard
   - API/webhook
4. Emergency Response tidak boleh hanya menjadi daftar kontak.
5. Harus ada emergency plan dan scenario.
6. Harus ada emergency team, role, contact, escalation.
7. Harus ada muster point dan evacuation route.
8. Harus ada emergency/fire equipment register dan readiness.
9. Harus ada drill schedule, execution, attendance, evaluation, finding, action.
10. Harus ada crisis notification dan acknowledgement.
11. Semua data wajib tenant-safe.
12. Semua API wajib permission-guarded.
13. Semua drill report, emergency event, notification, finding, equipment readiness, dan export harus audit logged.
14. Setelah sequence selesai, tulis:
   `SELESAI EMERGENCY SEQUENCE XX: <nama sequence>`
15. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
