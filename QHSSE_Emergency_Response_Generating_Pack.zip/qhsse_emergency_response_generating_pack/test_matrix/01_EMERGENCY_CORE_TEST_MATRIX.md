# Emergency Response Core Test Matrix

| ID | Area | Scenario | Expected |
|---|---|---|---|
| ER-001 | Plan | Create emergency plan | Success |
| ER-002 | Plan | Submit/approve plan | Workflow completed |
| ER-003 | Contact | Create emergency contact | Success |
| ER-004 | Team | Assign emergency role | Success |
| ER-005 | Muster | Create muster point | Success |
| ER-006 | Route | Create evacuation route | Success |
| ER-007 | Equipment | Create emergency equipment | Success |
| ER-008 | Drill | Schedule drill | Success |
