# Emergency Permission Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PERM-001 | User without emergency.view opens module | 403 / hidden UI |
| PERM-002 | User without emergency_plan.approve approves plan | 403 |
| PERM-003 | User without emergency_equipment.inspect inspects equipment | 403 |
| PERM-004 | User without emergency_drill.execute executes drill | 403 |
| PERM-005 | User without crisis_notification.broadcast broadcasts | 403 |
| PERM-006 | Site A user accesses Site B emergency plan | 403/404 |
| PERM-007 | Export report | Audit log created |
