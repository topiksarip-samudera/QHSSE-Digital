# Dashboard & Report Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| DR-001 | Readiness score | Accurate |
| DR-002 | Equipment readiness | Accurate |
| DR-003 | Drill completion | Accurate |
| DR-004 | Open drill findings | Accurate |
| DR-005 | Overdue emergency actions | Accurate |
| DR-006 | Export drill report | Success |
| DR-007 | Export emergency contact list | Scoped data only |
| DR-008 | Company A dashboard | No Company B data |
