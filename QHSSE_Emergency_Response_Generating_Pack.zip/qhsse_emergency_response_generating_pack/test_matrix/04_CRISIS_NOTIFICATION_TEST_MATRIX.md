# Crisis Notification Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| CN-001 | Create crisis notification | Success |
| CN-002 | Broadcast to target group | Recipients created |
| CN-003 | Recipient acknowledges | Ack status updated |
| CN-004 | Recipient does not acknowledge | Pending/overdue |
| CN-005 | Escalation rule triggered | Manager notified |
| CN-006 | Unauthorized broadcast | 403 |
| CN-007 | Notification audit log | Created |
