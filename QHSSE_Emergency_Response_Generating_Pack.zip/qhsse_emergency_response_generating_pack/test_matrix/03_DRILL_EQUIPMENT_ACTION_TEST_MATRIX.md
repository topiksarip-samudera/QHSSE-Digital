# Drill, Equipment & Action Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| DEA-001 | Equipment inspection failed | Not ready status |
| DEA-002 | Equipment not ready | Action created if configured |
| DEA-003 | Drill attendance input | Attendance saved |
| DEA-004 | Drill evacuation time input | KPI calculated |
| DEA-005 | Drill finding created | Finding/action linked |
| DEA-006 | Action closed | Finding can be verified |
| DEA-007 | Drill report approved | Status closed |
| DEA-008 | Drill overdue | Notification/escalation |
