# Emergency Response Sequence

Kerjakan sequence berikut secara berurutan:

```text
01 Foundation & Master Data
02 Emergency Plan & Scenario
03 Emergency Contact, Team & Role
04 Muster Point, Evacuation Route & Site Map
05 Emergency Equipment & Fire Equipment Register
06 Drill Plan & Schedule
07 Drill Execution, Attendance & Evidence
08 Drill Evaluation, Finding & Corrective Action
09 Crisis Notification & Escalation
10 Integration with Incident, Training, Asset, Contractor & Document
11 Dashboard, KPI, Report & Export
12 QA, Test, Permission & Stabilization
```

## Prompt Continue

```text
Continue Emergency Response Sequence. Kerjakan sequence berikutnya sesuai sequence/00_EMERGENCY_SEQUENCE.md. Jika sequence selesai, jangan lanjut sequence berikutnya. Berikan keterangan selesai.
```

## Status Akhir

```text
EMERGENCY RESPONSE STABILIZED: GO
```
