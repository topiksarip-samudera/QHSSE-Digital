# 04 — Muster Point, Evacuation Route & Site Map

## Tujuan

Membangun muster point, evacuation route, emergency map, assembly area capacity, route status, dan site/location mapping.

## Scope

Sequence ini harus menghasilkan database, backend API, frontend UI, permission, audit log, test minimal, dan acceptance criteria.

## Fokus Sequence

```text
muster point, capacity, evacuation route, site map, location mapping, route status
```

## Database yang Mungkin Dibuat/Diubah

```text
emergency_settings
emergency_types
emergency_scenarios
emergency_plans
emergency_plan_scenarios
emergency_contacts
emergency_teams
emergency_team_members
emergency_roles
muster_points
evacuation_routes
emergency_site_maps
emergency_equipment
fire_equipment
emergency_equipment_inspections
drill_plans
drill_schedules
drill_executions
drill_attendance
drill_evaluations
emergency_findings
emergency_actions
crisis_notifications
crisis_notification_recipients
emergency_readiness_scores
emergency_links
```

Gunakan hanya tabel yang relevan untuk sequence ini. Jangan duplikasi tabel core yang sudah ada.

## API Pattern

```text
GET /api/v1/emergency-plans
POST /api/v1/emergency-plans
GET /api/v1/emergency-contacts
GET /api/v1/emergency-teams
GET /api/v1/emergency-equipment
GET /api/v1/drill-schedules
GET /api/v1/drill-executions
GET /api/v1/crisis-notifications
GET /api/v1/emergency-response/dashboard
```

Tambahkan endpoint khusus sesuai sequence.

## Frontend Minimal

```text
List page
Create/update form
Detail page
Status badge
Filter/search
Calendar/map/table jika relevan
Evidence panel jika relevan
Action panel jika relevan
Workflow tab jika relevan
Attachment tab jika relevan
Comment tab jika relevan
Audit trail tab jika relevan
```

## Permission

Tambahkan permission sesuai kebutuhan sequence dan pastikan backend guard aktif.

## Audit Log

Catat create/update/delete/submit/review/approve/activate/inspect/execute/evaluate/broadcast/acknowledge/export sesuai sequence.

## Testing Minimal

```text
Happy path
Validation error
Permission denied
Tenant isolation
Audit log created
Status transition
Notification jika relevan
```

## Acceptance Criteria

- Fitur sequence berjalan end-to-end.
- Tenant-safe.
- Permission backend berjalan.
- UI tidak menampilkan tombol tanpa permission.
- Audit log tercatat.
- Emergency readiness data dapat dihitung jika relevan.
- Test minimal lulus.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI EMERGENCY SEQUENCE 04: Muster Point, Evacuation Route & Site Map
```
