# 03 — DATABASE MODEL GUIDE

## Tabel Minimal

```text
emergency_settings
emergency_types
emergency_scenarios
emergency_plans
emergency_plan_scenarios
emergency_contacts
emergency_teams
emergency_team_members
emergency_roles
muster_points
evacuation_routes
emergency_site_maps
emergency_equipment
fire_equipment
emergency_equipment_inspections
drill_plans
drill_schedules
drill_executions
drill_attendance
drill_evaluations
emergency_findings
emergency_actions
crisis_notifications
crisis_notification_recipients
emergency_readiness_scores
emergency_links
```

## Field Umum Wajib

Semua tabel tenant-specific wajib punya:

```text
id
company_id
site_id optional
department_id optional
location_id optional
created_by
updated_by
created_at
updated_at
deleted_at optional
status
```

## emergency_plans

```text
id
company_id
site_id
plan_number
title
description
emergency_type_id
scope
owner_department_id
plan_owner_id
effective_date
review_frequency_months
next_review_date
document_id optional
document_revision_id optional
workflow_instance_id optional
status
created_by
updated_by
created_at
updated_at
deleted_at
```

## emergency_contacts

```text
id
company_id
site_id
contact_type
name
role
organization
phone_primary
phone_secondary optional
email optional
priority_order
is_external
is_active
created_at
updated_at
```

## emergency_team_members

```text
id
company_id
team_id
user_id optional
contractor_worker_id optional
name_snapshot
role_id
primary_contact
backup_contact
shift optional
competency_status
training_status
is_active
created_at
updated_at
```

## muster_points

```text
id
company_id
site_id
location_id optional
muster_point_code
name
description
capacity
gps_lat optional
gps_lng optional
map_reference optional
status
created_at
updated_at
```

## evacuation_routes

```text
id
company_id
site_id
route_code
name
from_location_id
to_muster_point_id
route_description
estimated_time_minutes
map_file_id optional
status
created_at
updated_at
```

## emergency_equipment

```text
id
company_id
site_id
location_id
equipment_number
equipment_type
equipment_name
serial_number optional
capacity optional
inspection_frequency
last_inspection_date optional
next_inspection_date optional
expiry_date optional
readiness_status
status
created_by
updated_by
created_at
updated_at
```

## drill_executions

```text
id
company_id
drill_schedule_id
drill_number
scenario_id
site_id
conducted_date
start_time
end_time
evacuation_time_minutes optional
participants_count
observer_id optional
evaluator_id optional
summary
status
created_by
updated_by
created_at
updated_at
```

## crisis_notifications

```text
id
company_id
notification_number
emergency_type_id
site_id
location_id optional
message
severity
broadcast_channel
sent_by
sent_at
status
created_at
updated_at
```

## Index Wajib

```text
company_id
site_id
status
plan_number
equipment_number
drill_number
notification_number
next_review_date
next_inspection_date
conducted_date
created_at
```
