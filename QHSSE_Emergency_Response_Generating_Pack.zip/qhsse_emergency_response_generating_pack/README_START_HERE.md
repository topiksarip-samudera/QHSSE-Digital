# START HERE — QHSSE Emergency Response Generating Pack

Tanggal: 2026-06-22

Paket ini dibuat untuk menghasilkan modul **Emergency Response** pada WebApp QHSSE secara sequence, aman, dan terintegrasi.

## Posisi Modul dalam Roadmap

```text
Core Platform
→ Stabilization & QA
→ Incident Management
→ Risk Management / HIRADC / JSA
→ Audit & Inspection
→ Permit to Work
→ Document Control
→ Training & Competency
→ Legal & Compliance Register
→ Environment Management
→ Quality Management
→ Security Management
→ Contractor Management
→ Emergency Response
→ Asset & Equipment
```

## Rekomendasi Split

Modul **Emergency Response** sebaiknya di-split menjadi **12 sequence**.

```text
01 Foundation & Master Data
02 Emergency Plan & Scenario
03 Emergency Contact, Team & Role
04 Muster Point, Evacuation Route & Site Map
05 Emergency Equipment & Fire Equipment Register
06 Drill Plan & Schedule
07 Drill Execution, Attendance & Evidence
08 Drill Evaluation, Finding & Corrective Action
09 Crisis Notification & Escalation
10 Integration with Incident, Training, Asset, Contractor & Document
11 Dashboard, KPI, Report & Export
12 QA, Test, Permission & Stabilization
```

## Kenapa 12 Sequence?

Emergency Response bukan hanya daftar kontak darurat. Modul ini harus mengontrol:

```text
Emergency plan
Emergency scenario
Emergency contact
Emergency team / ICS role
Muster point
Evacuation route
Emergency equipment
Fire equipment
Drill schedule
Drill execution
Drill evaluation
Emergency finding
Corrective action
Crisis notification
Emergency readiness score
```

Jika digenerate sekaligus, hasilnya biasanya hanya menjadi daftar plan dan kontak. Dengan 12 sequence, modul akan menjadi emergency readiness control system yang terhubung ke Incident, Training, Asset, Contractor, Document, Audit, PTW, Security, Environment, dan Action Tracking.

## Cara Pakai

1. Extract ZIP ke project.
2. Baca `00_PROMPT_AWAL_EMERGENCY_RESPONSE.md`.
3. Baca `01_EMERGENCY_RESPONSE_MASTER_BLUEPRINT.md`.
4. Baca `02_EMERGENCY_RESPONSE_GENERATING_RULES.md`.
5. Mulai dari `sequence/01_foundation_master_data.md`.
6. Selesaikan satu sequence.
7. Setelah selesai, AI Agent harus menulis `SELESAI EMERGENCY SEQUENCE XX`.
8. Jangan lanjut sequence berikutnya sebelum diminta.

## Status Akhir

Setelah sequence 12 selesai:

```text
EMERGENCY RESPONSE STABILIZED: GO
```
