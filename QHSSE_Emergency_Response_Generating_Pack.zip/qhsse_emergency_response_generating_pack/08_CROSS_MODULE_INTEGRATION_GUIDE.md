# 08 — CROSS-MODULE INTEGRATION GUIDE

## Incident Management

```text
- Emergency event can create incident.
- Severe incident can trigger crisis notification.
- Incident investigation can link emergency response timeline.
```

## Training & Competency

```text
- Emergency team competency validation.
- First aid, fire fighting, rescue, spill response training.
- Drill attendance can become training evidence.
```

## Asset & Equipment

```text
- Emergency equipment can link to asset register.
- Fire extinguisher, hydrant, alarm, AED inspection.
- Equipment not ready affects readiness score.
```

## Contractor Management

```text
- Contractor emergency contact.
- Contractor worker participation in drill.
- Contractor emergency readiness requirement.
```

## Document Control

```text
- Emergency procedure and evacuation plan.
- Drill report and emergency plan document.
- Obsolete emergency procedure triggers plan review.
```

## Audit & Inspection

```text
- Emergency equipment inspection.
- Drill finding creates action.
- Audit can verify emergency readiness.
```

## Permit to Work

```text
- Confined space rescue plan.
- Hot work fire watch readiness.
- High-risk work emergency readiness.
```

## Security Management

```text
- Emergency gate access.
- Evacuation control.
- Crisis security response.
```

## Environment Management

```text
- Spill response and chemical emergency.
- Environmental emergency can create incident/action.
```
