# 03 — DATABASE MODEL GUIDE

## Tabel Minimal

```text
security_settings
security_incident_types
security_incident_categories
security_severity_levels
security_incidents
security_incident_people
security_incident_assets
security_investigations
security_investigation_interviews
security_investigation_findings
security_actions
visitors
visitor_pre_registrations
visitor_approvals
visitor_checkins
visitor_badges
gate_passes
vehicle_access_records
vehicle_checkins
access_cards
access_card_assignments
security_patrol_routes
security_patrol_checkpoints
security_patrol_schedules
security_patrol_runs
security_checkpoint_logs
lost_item_reports
theft_reports
unauthorized_access_reports
security_evidence
security_reports
security_links
```

## Field Umum Wajib

Semua tabel tenant-specific wajib punya:

```text
id
company_id
site_id optional
department_id optional
location_id optional
created_by
updated_by
created_at
updated_at
deleted_at optional
status
```

## security_incidents

```text
id
company_id
incident_number
incident_type_id
category_id
severity_id
title
description
incident_datetime
reported_datetime
reported_by
site_id
location_id optional
department_id optional
involved_person_type optional
contractor_id optional
visitor_id optional
vehicle_id optional
immediate_action
potential_impact
actual_loss
investigation_required
investigation_id optional
action_required
status
workflow_instance_id optional
created_by
updated_by
closed_by optional
closed_at optional
created_at
updated_at
deleted_at
```

## visitors

```text
id
company_id
visitor_number
full_name
identity_type
identity_number optional
company_name optional
phone optional
email optional
host_user_id
purpose
site_id
visit_date
expected_checkin_time
expected_checkout_time
actual_checkin_time optional
actual_checkout_time optional
badge_number optional
vehicle_number optional
approval_status
visit_status
blacklist_flag
created_by
updated_by
created_at
updated_at
```

## gate_passes

```text
id
company_id
gate_pass_number
pass_type
requestor_id
visitor_id optional
contractor_id optional
vehicle_number optional
driver_name optional
material_description optional
valid_from
valid_until
approved_by optional
used_at optional
status
created_by
updated_by
created_at
updated_at
```

## vehicle_access_records

```text
id
company_id
vehicle_access_number
vehicle_number
vehicle_type
driver_name
company_name
visitor_id optional
contractor_id optional
gate_pass_id optional
site_id
purpose
checkin_time optional
checkout_time optional
security_user_id optional
status
created_at
updated_at
```

## security_patrol_routes

```text
id
company_id
route_code
route_name
site_id
description
is_active
created_by
created_at
updated_at
```

## security_patrol_checkpoints

```text
id
company_id
route_id
checkpoint_code
checkpoint_name
location_id optional
qr_code optional
sequence_order
is_mandatory
created_at
updated_at
```

## security_patrol_runs

```text
id
company_id
patrol_number
route_id
scheduled_start
scheduled_end
actual_start optional
actual_end optional
patrol_user_id
status
summary
created_at
updated_at
```

## security_checkpoint_logs

```text
id
company_id
patrol_run_id
checkpoint_id
checked_at
checked_by
result
remarks
finding_id optional
photo_file_id optional
created_at
updated_at
```

## Index Wajib

```text
company_id
site_id
incident_number
visitor_number
gate_pass_number
vehicle_access_number
patrol_number
status
severity_id
incident_datetime
visit_date
scheduled_start
created_at
```
