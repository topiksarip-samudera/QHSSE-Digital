# 00 — PROMPT AWAL SECURITY MANAGEMENT UNTUK AI AGENT

Core Platform sudah stabil. Incident Management, Risk Management, Audit & Inspection, Permit to Work, Document Control, Training & Competency, Legal & Compliance, Environment, dan Quality Management sudah selesai atau siap integrasi.

Sekarang mulai generate QHSSE Operational Module: **Security Management**.

Baca seluruh file dalam folder `qhsse_security_management_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_master_data.md`.
3. Gunakan core yang sudah ada:
   - Company / tenant
   - Site / project / department / location
   - Role & permission
   - Module ON/OFF
   - Master data
   - Workflow
   - Action tracking
   - Attachment/evidence
   - Audit log
   - Notification
   - Numbering
   - QR code engine jika tersedia
   - Dashboard
   - API/webhook
4. Security Management tidak boleh hanya menjadi visitor log.
5. Harus ada security incident lifecycle.
6. Harus ada visitor, gate pass, vehicle access, badge/access card.
7. Harus ada patrol dan checkpoint.
8. Harus ada lost item, theft, unauthorized access, dan investigation.
9. Harus ada evidence dan security action.
10. Semua data wajib tenant-safe.
11. Semua API wajib permission-guarded.
12. Semua check-in/check-out, access approval, incident update, investigation, evidence, close-out, dan export harus audit logged.
13. Setelah sequence selesai, tulis:
   `SELESAI SECURITY SEQUENCE XX: <nama sequence>`
14. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
