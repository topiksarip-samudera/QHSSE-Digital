# 06 — Security Patrol & Checkpoint

## Tujuan

Membangun patrol route, checkpoint, schedule, patrol run, QR/manual checkpoint log, finding, dan patrol review.

## Scope

Sequence ini harus menghasilkan database, backend API, frontend UI, permission, audit log, test minimal, dan acceptance criteria.


## Fitur Wajib

```text
Patrol route
Checkpoint
Patrol schedule
Start patrol
QR/manual checkpoint confirmation
Missed checkpoint
Finding from checkpoint
Submit/review patrol
```


## Database yang Mungkin Dibuat/Diubah

```text
security_settings
security_incidents
security_incident_people
security_investigations
security_actions
visitors
visitor_approvals
visitor_checkins
visitor_badges
gate_passes
vehicle_access_records
access_cards
access_card_assignments
security_patrol_routes
security_patrol_checkpoints
security_patrol_schedules
security_patrol_runs
security_checkpoint_logs
lost_item_reports
theft_reports
unauthorized_access_reports
security_evidence
security_reports
security_links
```

Gunakan hanya tabel yang relevan untuk sequence ini. Jangan duplikasi tabel core yang sudah ada.

## API Pattern

```text
GET /api/v1/security-incidents
POST /api/v1/security-incidents
GET /api/v1/visitors
POST /api/v1/visitors
GET /api/v1/gate-passes
POST /api/v1/gate-passes
GET /api/v1/vehicle-access
POST /api/v1/vehicle-access
GET /api/v1/security-patrol-runs
POST /api/v1/security-patrol-runs
```

Tambahkan endpoint khusus sesuai sequence.

## Frontend Minimal

```text
List page
Create/update form
Detail page
Status badge
Filter/search
QR panel jika relevan
Evidence panel jika relevan
Action panel jika relevan
Workflow tab jika relevan
Attachment tab jika relevan
Comment tab jika relevan
Audit trail tab jika relevan
```

## Permission

Tambahkan permission sesuai kebutuhan sequence dan pastikan backend guard aktif.

## Audit Log

Catat create/update/delete/check-in/check-out/approve/revoke/investigate/evidence/action/verify/close/export sesuai sequence.

## Testing Minimal

```text
Happy path
Validation error
Permission denied
Tenant isolation
Audit log created
Status transition
Evidence security jika relevan
```

## Acceptance Criteria

- Fitur sequence berjalan end-to-end.
- Tenant-safe.
- Permission backend berjalan.
- UI tidak menampilkan tombol tanpa permission.
- Audit log tercatat.
- Critical security event bisa trigger notification jika relevan.
- Test minimal lulus.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI SECURITY SEQUENCE 06: Security Patrol & Checkpoint
```
