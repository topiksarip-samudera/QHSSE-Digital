# 08 — CROSS-MODULE INTEGRATION GUIDE

## Incident Management

```text
- Security incident can create/link to QHSSE incident.
- High severity security incident can trigger incident notification.
- Investigation evidence can be shared with incident investigation if allowed.
```

## Contractor Management

```text
- Contractor visitor and vehicle validation.
- Contractor access violation affects contractor performance.
- Contractor blacklist/watchlist can affect visitor approval.
```

## Audit & Inspection

```text
- Security patrol finding can create audit/inspection finding.
- Audit can verify security control effectiveness.
- Security inspection checklist can be reused.
```

## Document Control

```text
- Security policy, visitor rules, access procedure linked.
- Investigation can trigger document revision.
```

## Training & Competency

```text
- Security induction and visitor briefing.
- Security officer competency/training evidence.
```

## Permit to Work

```text
- Vehicle entry gate pass can link to permit.
- Restricted area access can require permit.
- Active permit can be viewed by security gate if scoped.
```

## Action Tracking

```text
- Security finding/incident creates corrective action.
- Action overdue triggers escalation.
```

## Notification

```text
- Unauthorized access alert.
- Visitor overstay alert.
- Patrol missed checkpoint alert.
- Critical incident escalation.
```
