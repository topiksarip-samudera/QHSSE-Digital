# 05 — UI/UX GUIDE SECURITY MANAGEMENT

## Sidebar

```text
Security Management
├── Overview
├── Security Incidents
├── Visitors
├── Gate Pass
├── Vehicle Access
├── ID Badge / Access Card
├── Patrol Routes
├── Patrol Schedule
├── Patrol Runs
├── Lost Item / Theft
├── Unauthorized Access
├── Investigations
├── Reports
└── Settings
```

## Halaman Utama

```text
Security Overview Dashboard
Security Incident Register
Create Security Incident
Visitor Register
Visitor Pre-Registration
Visitor Check-In/Check-Out
Gate Pass Register
Vehicle Access Register
Badge / Access Card Register
Patrol Route Builder
Patrol Schedule
Patrol Execution
Checkpoint Log
Lost Item Register
Theft Report
Unauthorized Access Register
Investigation Detail
Security Report Export
Settings
```

## Security Incident Detail Tabs

```text
Overview
Classification
People / Visitor / Contractor
Vehicle / Asset
Investigation
Evidence
Actions
Workflow
Linked Records
Comments
Audit Trail
```

## Visitor Detail Tabs

```text
Overview
Host Approval
Check-In / Check-Out
Badge
Vehicle
Visit History
Attachments
Audit Trail
```

## Patrol Detail Tabs

```text
Overview
Route
Checkpoints
Checkpoint Logs
Findings
Evidence
Review
Audit Trail
```

## Komponen Wajib

```text
SecurityIncidentStatusBadge
VisitorStatusBadge
GatePassStatusBadge
VehicleInsideBadge
AccessCardStatusBadge
PatrolStatusBadge
CheckpointCard
VisitorCheckInPanel
VehicleAccessPanel
SecurityEvidencePanel
SecurityActionPanel
SecurityDashboardCards
```

## UX Penting

- Visitor check-in/check-out harus cepat.
- Security guard UI harus mobile/tablet friendly.
- QR untuk visitor badge dan checkpoint patrol harus mudah dipakai.
- Critical incident harus jelas dan cepat di-escalate.
- Data security investigation harus dibatasi permission.
- Active visitors dan vehicles inside harus tampil real-time atau near-real-time.
