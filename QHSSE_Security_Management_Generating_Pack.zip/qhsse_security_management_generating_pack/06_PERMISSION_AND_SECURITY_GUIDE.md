# 06 — PERMISSION & SECURITY GUIDE

## Permission Groups

### Security General

```text
security.view
security.view_all
security.create
security.update
security.delete
security.export
security.manage_settings
```

### Security Incident

```text
security_incident.view
security_incident.create
security_incident.update
security_incident.classify
security_incident.investigate
security_incident.assign_action
security_incident.verify
security_incident.close
security_incident.export
```

### Visitor

```text
visitor.view
visitor.create
visitor.update
visitor.approve
visitor.reject
visitor.check_in
visitor.check_out
visitor.blacklist
visitor.export
```

### Gate Pass & Vehicle

```text
gate_pass.view
gate_pass.create
gate_pass.approve
gate_pass.revoke
vehicle_access.view
vehicle_access.create
vehicle_access.approve
vehicle_access.check_in
vehicle_access.check_out
```

### Badge / Patrol

```text
badge_access.view
badge_access.manage
patrol.view
patrol.create
patrol.execute
patrol.review
patrol.close
```

## Scope

```text
Global
Company
Site
Project
Department
Location
Own
Assigned
Host
Security Guard
Security Supervisor
Investigator
Contractor
Visitor Limited
```

## Security Rules

- Semua query wajib filter company_id.
- Site scope hanya bisa melihat data site-nya.
- Visitor limited access hanya untuk pre-registration/status sendiri jika portal visitor tersedia.
- Security guard dapat check-in/out tetapi tidak boleh melihat investigation restricted tanpa permission.
- Investigator hanya melihat case yang assigned jika scope assigned.
- Blacklist visitor butuh permission khusus.
- Access card revoke butuh permission khusus.
- Critical incident report/export harus permission-restricted.
- Evidence download harus permission-guarded.
- Export harus audit logged.
