# 02 — SECURITY MANAGEMENT GENERATING RULES

## Aturan Utama

1. Jangan membuat Security Management hanya sebagai visitor log.
2. Security incident harus punya lifecycle.
3. Visitor, gate pass, vehicle access, badge/access card, patrol, investigation harus terpisah tetapi bisa linked.
4. Visitor check-in/check-out harus audit logged.
5. Vehicle access harus bisa linked ke visitor/contractor/vendor.
6. Patrol checkpoint harus bisa manual dan QR-ready.
7. Lost item, theft, unauthorized access harus bisa masuk investigation.
8. Critical security incident harus trigger notification.
9. Security action harus terhubung dengan Action Tracking.
10. Evidence harus menggunakan attachment core.
11. Semua data wajib tenant-safe.
12. Semua API wajib permission-guarded.
13. Data sensitif security harus memiliki access control.
14. Export report harus audit logged.

## Status Security Incident

```text
draft
reported
under_review
classified
investigation_required
investigation_in_progress
action_assigned
pending_verification
management_review
closed
cancelled
archived
```

## Status Visitor

```text
pre_registered
pending_approval
approved
rejected
checked_in
checked_out
overstay
cancelled
blacklisted
```

## Status Patrol

```text
scheduled
started
in_progress
missed_checkpoint
submitted
reviewed
closed
cancelled
```

## Permission Standard

```text
security.view
security.view_all
security.create
security.update
security.delete
security.submit
security.review
security.approve
security.close
security.export
security.manage_settings

security_incident.view
security_incident.create
security_incident.update
security_incident.classify
security_incident.investigate
security_incident.close

visitor.view
visitor.create
visitor.approve
visitor.check_in
visitor.check_out
visitor.blacklist

gate_pass.view
gate_pass.create
gate_pass.approve
gate_pass.revoke

vehicle_access.view
vehicle_access.create
vehicle_access.approve
vehicle_access.check_in
vehicle_access.check_out

patrol.view
patrol.create
patrol.execute
patrol.review

badge_access.manage
security_investigation.manage
```

## Audit Log Wajib

```text
security_incident.created
security_incident.updated
security_incident.classified
security_incident.investigation_started
security_incident.closed
visitor.created
visitor.approved
visitor.checked_in
visitor.checked_out
visitor.blacklisted
gate_pass.created
gate_pass.approved
gate_pass.revoked
vehicle_access.created
vehicle_access.checked_in
vehicle_access.checked_out
badge.issued
badge.revoked
patrol.started
checkpoint.scanned
patrol.submitted
finding.created
action.assigned
report.exported
settings.changed
```

## Webhook Events

```text
security.incident_created
security.critical_incident
visitor.checked_in
visitor.overstay
gate_pass.approved
vehicle.checked_in
badge.revoked
patrol.missed_checkpoint
security.finding_created
security.action_overdue
```
