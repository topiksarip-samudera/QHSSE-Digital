# START HERE — QHSSE Security Management Generating Pack

Tanggal: 2026-06-22

Paket ini dibuat untuk menghasilkan modul **Security Management** pada WebApp QHSSE secara sequence, aman, lengkap, dan terintegrasi.

## Posisi Modul dalam Roadmap

```text
Core Platform
→ Stabilization & QA
→ Incident Management
→ Risk Management / HIRADC / JSA
→ Audit & Inspection
→ Permit to Work
→ Document Control
→ Training & Competency
→ Legal & Compliance Register
→ Environment Management
→ Quality Management
→ Security Management
→ Contractor Management
→ Emergency Response
→ Asset & Equipment
```

## Rekomendasi Split

Modul **Security Management** sebaiknya di-split menjadi **12 sequence**.

```text
01 Foundation & Master Data
02 Security Incident Core
03 Visitor Management
04 Gate Pass & Vehicle Access
05 ID Badge, Access Card & Access Control
06 Security Patrol & Checkpoint
07 Lost Item, Theft & Unauthorized Access
08 Security Investigation & Evidence
09 Security Action, Verification & Close-Out
10 Integration with Contractor, Incident, Audit, Document & Notification
11 Dashboard, KPI, Report & Export
12 QA, Test, Permission & Stabilization
```

## Kenapa 12 Sequence?

Security Management bukan hanya pencatatan tamu atau insiden. Modul ini harus mengelola:

```text
Security Incident
Visitor Management
Gate Pass
Vehicle Access
ID Badge
Access Card
Patrol
Checkpoint
Lost Item
Theft
Unauthorized Access
Investigation
Evidence
Security Action
Security Dashboard
```

Jika digenerate sekaligus, biasanya security hanya menjadi CRUD sederhana. Dengan 12 sequence, modul bisa menjadi sistem security operational control yang terhubung dengan contractor, incident, audit, document, training, notification, dan action tracking.

## Cara Pakai

1. Extract ZIP ke project.
2. Baca `00_PROMPT_AWAL_SECURITY_MANAGEMENT.md`.
3. Baca `01_SECURITY_MANAGEMENT_MASTER_BLUEPRINT.md`.
4. Baca `02_SECURITY_MANAGEMENT_GENERATING_RULES.md`.
5. Mulai dari `sequence/01_foundation_master_data.md`.
6. Selesaikan satu sequence.
7. Setelah selesai, AI Agent harus menulis `SELESAI SECURITY SEQUENCE XX`.
8. Jangan lanjut sequence berikutnya sebelum diminta.

## Status Akhir

Setelah sequence 12 selesai:

```text
SECURITY MANAGEMENT STABILIZED: GO
```
