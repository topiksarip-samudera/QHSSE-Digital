# Prompt Fix Security Management

Review modul Security Management yang terakhir dibuat.

Periksa:
- Tenant isolation
- Permission backend
- Security incident lifecycle
- Visitor check-in/out
- Gate pass
- Vehicle access
- Badge/access card
- Patrol/checkpoint
- Investigation/evidence
- Action integration
- Notification/escalation
- Dashboard calculation
- Report export
- Cross-module links
- Audit log
- Build/lint/test

Perbaiki semua bug P0/P1. Setelah selesai tulis:

```text
SECURITY MANAGEMENT FIXED
```
