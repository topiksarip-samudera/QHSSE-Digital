# Prompt Continue Security Management Sequence

Continue Security Management Sequence.

Kerjakan sequence berikutnya sesuai:

```text
sequence/00_SECURITY_SEQUENCE.md
```

Aturan:
- Jangan lompat sequence.
- Jangan lanjut sequence berikutnya setelah selesai.
- Pastikan database, backend, frontend, permission, audit log, dan test selesai.
- Jika sequence selesai, tulis:
  `SELESAI SECURITY SEQUENCE XX: <nama sequence>`
