# Prompt Start Security Management

Core Platform sudah stabil. Quality Management sudah selesai atau siap integrasi.

Sekarang generate Security Management berdasarkan `qhsse_security_management_generating_pack`.

Mulai dari:

```text
sequence/01_foundation_master_data.md
```

Kerjakan sequence pertama saja.

Setelah selesai tulis:

```text
SELESAI SECURITY SEQUENCE 01: Foundation & Master Data
```

Jangan lanjut sequence berikutnya sebelum saya minta continue.
