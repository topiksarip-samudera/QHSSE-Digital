# Prompt Release Gate Security Management

Jalankan release gate Security Management.

Cek:
- P0 = 0
- P1 = 0
- Tenant isolation PASS
- Permission backend PASS
- Security incident lifecycle PASS
- Visitor check-in/out PASS
- Gate pass PASS
- Vehicle access PASS
- Badge/access card PASS
- Patrol/checkpoint PASS
- Investigation/evidence PASS
- Action integration PASS
- Notification/escalation PASS
- Dashboard calculation PASS
- Report export PASS
- Cross-module integration PASS
- Audit log PASS
- Lint/test/build PASS

Jika lulus tulis:

```text
SECURITY MANAGEMENT STABILIZED: GO
```

Jika gagal tulis:

```text
SECURITY MANAGEMENT STABILIZED: NO-GO
```

Sertakan blocking issue.
