# Dashboard & Report Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| DR-001 | Active visitor count | Accurate |
| DR-002 | Vehicle inside count | Accurate |
| DR-003 | Critical incident count | Accurate |
| DR-004 | Patrol completion | Accurate |
| DR-005 | Missed checkpoint count | Accurate |
| DR-006 | Open action count | Accurate |
| DR-007 | Export visitor log | Scoped data only |
| DR-008 | Export security incident report | Generated and audit logged |
