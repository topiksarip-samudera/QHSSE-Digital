# Patrol, Investigation & Action Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PIA-001 | Create patrol route | Success |
| PIA-002 | Add checkpoint | Success |
| PIA-003 | Start patrol | Status in progress |
| PIA-004 | Scan checkpoint | Checkpoint log created |
| PIA-005 | Miss checkpoint | Missed checkpoint flag |
| PIA-006 | Create finding from checkpoint | Finding/action created |
| PIA-007 | Start investigation | Investigation in progress |
| PIA-008 | Add evidence | Evidence secured |
| PIA-009 | Assign action | Action Tracking linked |
| PIA-010 | Verify action | Action/finding closed |
