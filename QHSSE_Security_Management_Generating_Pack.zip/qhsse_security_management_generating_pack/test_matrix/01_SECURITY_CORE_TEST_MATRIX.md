# Security Core Test Matrix

| ID | Area | Scenario | Expected |
|---|---|---|---|
| SEC-001 | Incident | Create security incident | Success |
| SEC-002 | Incident | Classify severity | Status/severity updated |
| SEC-003 | Visitor | Pre-register visitor | Pending approval |
| SEC-004 | Visitor | Approve visitor | Approved |
| SEC-005 | Visitor | Check-in visitor | Active visitor |
| SEC-006 | Visitor | Check-out visitor | Visit closed |
| SEC-007 | Gate Pass | Approve gate pass | Active pass |
| SEC-008 | Vehicle | Vehicle check-in/out | Vehicle status updated |
