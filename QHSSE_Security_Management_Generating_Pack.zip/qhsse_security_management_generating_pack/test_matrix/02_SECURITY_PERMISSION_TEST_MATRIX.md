# Security Permission Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PERM-001 | User without security.view opens dashboard | 403 / hidden UI |
| PERM-002 | User without visitor.check_in checks in visitor | 403 |
| PERM-003 | User without gate_pass.approve approves gate pass | 403 |
| PERM-004 | User without security_incident.investigate opens restricted investigation | 403 |
| PERM-005 | Site A user accesses Site B visitor | 403/404 |
| PERM-006 | Contractor sees unrelated visitor | 403/404 |
| PERM-007 | User without export exports report | 403 |
| PERM-008 | Export report | Audit log created |
