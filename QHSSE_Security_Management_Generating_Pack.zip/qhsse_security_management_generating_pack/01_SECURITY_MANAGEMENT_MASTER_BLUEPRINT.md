# 01 — MASTER BLUEPRINT SECURITY MANAGEMENT

## Tujuan Modul

Modul **Security Management** digunakan untuk mengelola aspek keamanan perusahaan/site/project: security incident, visitor, gate pass, vehicle access, badge/access card, patrol, checkpoint, lost item, theft, unauthorized access, investigation, evidence, action, dan reporting.

Modul ini harus membantu security team mengontrol akses, memonitor aktivitas, menangani insiden, dan menyediakan evidence untuk audit serta investigation.

## Prinsip Desain

1. Security Management harus multi-tenant dan multi-site.
2. Visitor, gate pass, vehicle, badge, patrol, dan incident harus terpisah tetapi saling terhubung.
3. Security incident harus punya lifecycle dari report sampai closed.
4. Visitor check-in/check-out harus audit logged.
5. Vehicle access harus bisa linked ke contractor/vendor/visitor.
6. ID badge/access card harus punya status active/lost/revoked/expired.
7. Patrol harus berbasis route dan checkpoint.
8. Checkpoint dapat menggunakan QR atau manual confirmation.
9. Lost item, theft, unauthorized access harus bisa masuk investigation.
10. Investigation harus punya evidence, interview, chronology, conclusion, action.
11. Finding/action harus terhubung dengan Action Tracking.
12. Critical security incident harus trigger notification/escalation.
13. Data sensitif harus permission-aware.

## Submodul Utama

```text
Security Incident
Visitor Management
Gate Pass
Vehicle Access
ID Badge / Access Card
Security Patrol
Checkpoint Patrol
Lost Item
Theft / Loss Report
Unauthorized Access
Conflict / Violence Report
Security Investigation
Security Action
Security Dashboard
Security Reports
Settings & Master Data
```

## Jenis Security Incident

```text
Theft
Lost Item
Unauthorized Access
Trespassing
Violence / Conflict
Threat / Intimidation
Suspicious Activity
Security Breach
Vehicle Violation
Access Card Misuse
Visitor Violation
Contractor Violation
Property Damage
Sabotage optional
Community Disturbance
Cyber/Physical Security Event optional
```

## Visitor Status

```text
pre_registered
pending_approval
approved
rejected
checked_in
checked_out
overstay
cancelled
blacklisted
```

## Gate Pass Status

```text
draft
submitted
approved
active
used
expired
cancelled
revoked
```

## Security Incident Workflow

```text
Draft / Reported
→ Security Review
→ Classification
→ Investigation Required optional
→ Investigation In Progress
→ Action Assigned
→ Verification
→ Management Review optional
→ Closed
```

## Visitor Workflow

```text
Pre-Registration
→ Host Approval
→ Security Verification
→ Check-In
→ Badge Issued
→ Site Visit
→ Check-Out
→ Closed
```

## Patrol Workflow

```text
Patrol Scheduled
→ Patrol Started
→ Checkpoint Scanned / Confirmed
→ Finding Created optional
→ Patrol Submitted
→ Reviewed
→ Closed
```

## Output Utama

```text
Security Incident Register
Visitor Log
Gate Pass Register
Vehicle Access Log
Badge / Access Card Register
Patrol Schedule
Patrol Result
Checkpoint Log
Lost Item Register
Theft Report
Unauthorized Access Report
Security Investigation Report
Security Action List
Security KPI Dashboard
Security Report Export
```

## Integrasi Core

```text
Workflow: visitor approval, incident review, investigation close-out
Action Tracking: security action and corrective action
Attachment: evidence photo/video/document
Notification: critical incident, visitor approval, overstay, patrol overdue
Audit Log: check-in/out, access approval, investigation update
Numbering: incident, visitor, gate pass, patrol, investigation
QR: visitor badge, gate pass, checkpoint patrol
Dashboard: KPI and widgets
API/Webhook: integration
```

## Integrasi Modul Lain

```text
Incident Management:
- Security incident can become QHSSE incident.
- High severity incident can trigger Incident Management record.

Contractor Management:
- Contractor visitors/workers/vehicles validated.
- Contractor access and violation feed contractor performance.

Audit & Inspection:
- Security patrol finding can become audit/inspection finding.
- Audit can verify security controls.

Document Control:
- Security policy/procedure/visitor rules linked.

Training & Competency:
- Security induction and visitor briefing.

Permit to Work:
- Vehicle entry and restricted area access link to permits.

Action Tracking:
- Follow-up from security finding/incident.
```
