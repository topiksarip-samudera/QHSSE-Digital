# 04 — API CONTRACT GUIDE

Gunakan prefix:

```text
/api/v1
```

## Security Incident

```text
GET    /security-incidents
POST   /security-incidents
GET    /security-incidents/:id
PATCH  /security-incidents/:id
DELETE /security-incidents/:id
POST   /security-incidents/:id/submit
POST   /security-incidents/:id/classify
POST   /security-incidents/:id/start-investigation
POST   /security-incidents/:id/assign-action
POST   /security-incidents/:id/verify
POST   /security-incidents/:id/close
GET    /security-incidents/:id/report
GET    /security-incidents/:id/export
```

## Visitor Management

```text
GET    /visitors
POST   /visitors
GET    /visitors/:id
PATCH  /visitors/:id
POST   /visitors/:id/approve
POST   /visitors/:id/reject
POST   /visitors/:id/check-in
POST   /visitors/:id/check-out
POST   /visitors/:id/blacklist
GET    /visitors/:id/badge
```

## Gate Pass

```text
GET    /gate-passes
POST   /gate-passes
GET    /gate-passes/:id
PATCH  /gate-passes/:id
POST   /gate-passes/:id/approve
POST   /gate-passes/:id/revoke
POST   /gate-passes/:id/use
```

## Vehicle Access

```text
GET    /vehicle-access
POST   /vehicle-access
GET    /vehicle-access/:id
PATCH  /vehicle-access/:id
POST   /vehicle-access/:id/check-in
POST   /vehicle-access/:id/check-out
POST   /vehicle-access/:id/approve
```

## Badge / Access Card

```text
GET    /access-cards
POST   /access-cards
GET    /access-cards/:id
PATCH  /access-cards/:id
POST   /access-cards/:id/assign
POST   /access-cards/:id/revoke
POST   /access-cards/:id/report-lost
```

## Patrol

```text
GET    /security-patrol-routes
POST   /security-patrol-routes
GET    /security-patrol-routes/:id
PATCH  /security-patrol-routes/:id

GET    /security-patrol-schedules
POST   /security-patrol-schedules

GET    /security-patrol-runs
POST   /security-patrol-runs
GET    /security-patrol-runs/:id
POST   /security-patrol-runs/:id/start
POST   /security-patrol-runs/:id/checkpoint
POST   /security-patrol-runs/:id/submit
POST   /security-patrol-runs/:id/review
POST   /security-patrol-runs/:id/close
```

## Reports & Dashboard

```text
GET /security/dashboard
GET /security/kpi
GET /security/active-visitors
GET /security/vehicle-inside
GET /security/patrol-status
GET /security/export
```

## Settings

```text
GET   /security/settings
PATCH /security/settings
GET   /security/master-data
```

## Standard Query

```text
?page=1&pageSize=20&search=&siteId=&status=&dateFrom=&dateTo=&severityId=&locationId=&sort=createdAt:desc
```
