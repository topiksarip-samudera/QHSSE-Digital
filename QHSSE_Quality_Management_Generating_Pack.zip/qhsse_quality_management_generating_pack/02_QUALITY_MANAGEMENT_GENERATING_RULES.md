# 02 — QUALITY MANAGEMENT GENERATING RULES

## Aturan Utama

1. Jangan membuat modul ini sebagai NCR CRUD sederhana.
2. NCR, complaint, supplier issue, inspection, punch list, CAPA, dan calibration harus punya model jelas.
3. Disposition, RCA, CAPA, dan verification harus workflow-aware.
4. CAPA harus menggunakan Action Tracking Core jika sudah ada.
5. Evidence harus memakai attachment core.
6. Calibration due/overdue harus masuk notification/calendar.
7. Semua critical status change harus audit logged.
8. Semua API wajib tenant-filter dan permission-guarded.
9. Export harus permission-aware dan audit logged.
10. Dashboard harus dihitung dari data nyata.

## Permission Standard

```text
quality.view
quality.view_all
quality.create
quality.update
quality.delete
quality.submit
quality.review
quality.approve
quality.close
quality.export
quality.manage_settings

ncr.view
ncr.create
ncr.update
ncr.review
ncr.assign_disposition
ncr.assign_action
ncr.verify
ncr.close

quality_complaint.view
quality_complaint.create
quality_complaint.respond
quality_complaint.close

quality_inspection.view
quality_inspection.create
quality_inspection.review
quality_inspection.close

calibration.view
calibration.create
calibration.update
calibration.verify
calibration.close
```

## Audit Log Wajib

```text
ncr.created
ncr.updated
ncr.submitted
ncr.reviewed
ncr.disposition_set
ncr.rca_added
ncr.action_assigned
ncr.verified
ncr.closed
complaint.created
complaint.responded
supplier_issue.created
inspection.result_submitted
punch_item.created
calibration.created
calibration.completed
calibration.out_of_tolerance
report.exported
settings.changed
```

## Webhook Events

```text
quality.ncr_created
quality.ncr_high_severity
quality.ncr_closed
quality.capa_overdue
quality.complaint_created
quality.supplier_issue_created
quality.defect_created
quality.calibration_due
quality.calibration_overdue
quality.out_of_tolerance
```
