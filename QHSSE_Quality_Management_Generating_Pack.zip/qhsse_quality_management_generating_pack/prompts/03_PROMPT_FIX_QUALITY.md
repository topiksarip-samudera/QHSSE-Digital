# Prompt Fix Quality Management

Review modul Quality Management yang terakhir dibuat.

Periksa:
- Tenant isolation
- Permission backend
- NCR lifecycle
- Complaint flow
- Supplier issue flow
- Inspection/ITP
- Punch list/defect
- RCA/disposition
- CAPA verification
- Calibration
- Dashboard calculation
- Report export
- Audit log
- Build/lint/test

Perbaiki semua bug P0/P1. Setelah selesai tulis `QUALITY MANAGEMENT FIXED`.
