# Prompt Release Gate Quality Management

Jalankan release gate Quality Management.

Cek:
- P0 = 0
- P1 = 0
- Tenant isolation PASS
- Permission backend PASS
- NCR lifecycle PASS
- Complaint flow PASS
- Supplier issue flow PASS
- Inspection/ITP PASS
- RCA/disposition PASS
- CAPA verification PASS
- Calibration PASS
- Dashboard calculation PASS
- Report export PASS
- Audit log PASS
- Cross-module integration PASS
- Lint/test/build PASS

Jika lulus tulis:

```text
QUALITY MANAGEMENT STABILIZED: GO
```

Jika gagal tulis:

```text
QUALITY MANAGEMENT STABILIZED: NO-GO
```

Sertakan blocking issue.
