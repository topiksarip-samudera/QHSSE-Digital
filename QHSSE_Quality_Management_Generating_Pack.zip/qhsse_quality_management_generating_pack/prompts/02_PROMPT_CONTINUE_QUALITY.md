# Prompt Continue Quality Management Sequence

Continue Quality Management Sequence.

Kerjakan sequence berikutnya sesuai:

```text
sequence/00_QUALITY_SEQUENCE.md
```

Aturan:
- Jangan lompat sequence.
- Jangan lanjut sequence berikutnya setelah selesai.
- Pastikan database, backend, frontend, permission, audit log, dan test selesai.
- Jika sequence selesai, tulis: `SELESAI QUALITY SEQUENCE XX: <nama sequence>`.
