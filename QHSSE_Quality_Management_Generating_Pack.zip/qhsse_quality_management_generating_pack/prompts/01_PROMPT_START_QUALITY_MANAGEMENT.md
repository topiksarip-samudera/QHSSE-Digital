# Prompt Start Quality Management

Core Platform sudah stabil. Environment Management sudah selesai atau siap integrasi.

Sekarang generate Quality Management berdasarkan `qhsse_quality_management_generating_pack`.

Mulai dari:

```text
sequence/01_foundation_master_data.md
```

Kerjakan sequence pertama saja.

Setelah selesai tulis:

```text
SELESAI QUALITY SEQUENCE 01: Foundation & Master Data
```

Jangan lanjut sequence berikutnya sebelum saya minta continue.
