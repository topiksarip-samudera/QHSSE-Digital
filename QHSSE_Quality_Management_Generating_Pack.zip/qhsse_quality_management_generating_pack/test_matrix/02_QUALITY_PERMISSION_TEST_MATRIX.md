# Quality Permission Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PERM-001 | User without quality.view opens module | 403 / hidden UI |
| PERM-002 | User without ncr.create creates NCR | 403 |
| PERM-003 | User without ncr.verify verifies NCR | 403 |
| PERM-004 | Site A user accesses Site B NCR | 403/404 |
| PERM-005 | User without export exports report | 403 |
| PERM-006 | Export report | Audit log created |
