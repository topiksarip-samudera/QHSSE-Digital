# Quality Core Test Matrix

| ID | Area | Scenario | Expected |
|---|---|---|---|
| QM-001 | NCR | Create NCR | Success |
| QM-002 | NCR | Submit NCR | Workflow started |
| QM-003 | NCR | Set disposition | Disposition saved |
| QM-004 | RCA | Add 5 Why | RCA saved |
| QM-005 | CAPA | Assign CAPA | Action linked |
| QM-006 | Verification | Verify CAPA | Status verified |
| QM-007 | Complaint | Create complaint | Success |
| QM-008 | Supplier | Create supplier issue | Success |
