# NCR CAPA Calibration Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| NCC-001 | High severity NCR | RCA/CAPA required |
| NCC-002 | Disposition requires approval | Approval enforced |
| NCC-003 | CAPA overdue | Notification sent |
| NCC-004 | CAPA verification rejected | Remains open |
| NCC-005 | Calibration due | Due list and notification |
| NCC-006 | Out of tolerance | NCR can be created |
| NCC-007 | Certificate upload | Secure attachment |
