# Dashboard & Report Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| DR-001 | Open NCR count | Accurate |
| DR-002 | Overdue CAPA count | Accurate |
| DR-003 | Defect trend | Accurate |
| DR-004 | Complaint trend | Accurate |
| DR-005 | Calibration due count | Accurate |
| DR-006 | Cost of quality | Accurate |
| DR-007 | Export NCR register | Scoped data only |
| DR-008 | Company A dashboard | No Company B data |
