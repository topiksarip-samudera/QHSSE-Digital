# 03 — DATABASE MODEL GUIDE

## Tabel Minimal

```text
quality_settings
quality_categories
quality_severities
ncr_records
ncr_affected_items
ncr_dispositions
ncr_root_causes
quality_capa_links
customer_complaints
supplier_quality_issues
material_receiving_inspections
quality_inspection_plans
quality_inspection_results
quality_inspection_items
itp_records
itp_stages
itp_points
punch_lists
punch_items
defect_records
calibration_equipment
calibration_schedules
calibration_records
calibration_certificates
quality_cost_records
quality_links
```

## Field Umum Wajib

```text
id
company_id
site_id optional
project_id optional
department_id optional
location_id optional
created_by
updated_by
created_at
updated_at
deleted_at optional
status
```

## ncr_records

```text
id
company_id
ncr_number
source_module optional
source_record_id optional
ncr_source
ncr_type
category_id
severity_id
title
description
site_id
project_id optional
department_id optional
location_id optional
customer_id optional
supplier_id optional
contractor_id optional
affected_product optional
affected_process optional
affected_quantity optional
requirement_reference
immediate_correction
disposition_status
rca_required
action_required
verification_status
effectiveness_status
workflow_instance_id optional
status
created_by
updated_by
closed_by optional
closed_at optional
created_at
updated_at
```

## ncr_dispositions

```text
id
company_id
ncr_id
disposition_type
disposition_description
approved_by optional
approved_at optional
concession_required
concession_reference optional
cost_impact optional
status
created_at
updated_at
```

## customer_complaints

```text
id
company_id
complaint_number
customer_name
contact_person optional
complaint_date
product_service
project_id optional
severity_id
description
response_due_date
response_summary optional
linked_ncr_id optional
status
created_by
updated_by
created_at
updated_at
```

## supplier_quality_issues

```text
id
company_id
issue_number
supplier_id
po_number optional
material_id optional
receiving_inspection_id optional
issue_description
quantity_affected
severity_id
supplier_response_required
response_due_date
linked_ncr_id optional
status
created_at
updated_at
```

## calibration_equipment

```text
id
company_id
equipment_number
name
serial_number
manufacturer optional
model optional
location_id optional
owner_department_id optional
calibration_frequency_months
last_calibration_date optional
next_calibration_date
calibration_status
certificate_id optional
is_critical
status
created_at
updated_at
```

## calibration_records

```text
id
company_id
equipment_id
calibration_date
calibrated_by
certificate_number
result
out_of_tolerance
adjustment_required
next_due_date
file_id optional
remarks
status
created_at
updated_at
```

## Index Wajib

```text
company_id
ncr_number
complaint_number
issue_number
equipment_number
status
severity_id
site_id
project_id
supplier_id
customer_id
next_calibration_date
created_at
```
