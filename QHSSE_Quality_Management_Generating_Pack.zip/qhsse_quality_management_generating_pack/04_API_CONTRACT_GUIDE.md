# 04 — API CONTRACT GUIDE

Gunakan prefix `/api/v1`.

## NCR

```text
GET    /quality/ncr
POST   /quality/ncr
GET    /quality/ncr/:id
PATCH  /quality/ncr/:id
DELETE /quality/ncr/:id
POST   /quality/ncr/:id/submit
POST   /quality/ncr/:id/review
POST   /quality/ncr/:id/set-disposition
POST   /quality/ncr/:id/add-rca
POST   /quality/ncr/:id/assign-capa
POST   /quality/ncr/:id/verify
POST   /quality/ncr/:id/close
GET    /quality/ncr/:id/export
```

## Complaint

```text
GET  /quality/complaints
POST /quality/complaints
GET  /quality/complaints/:id
PATCH /quality/complaints/:id
POST /quality/complaints/:id/respond
POST /quality/complaints/:id/create-ncr
POST /quality/complaints/:id/close
```

## Supplier Quality & Receiving Inspection

```text
GET  /quality/supplier-issues
POST /quality/supplier-issues
GET  /quality/material-receiving-inspections
POST /quality/material-receiving-inspections
POST /quality/supplier-issues/:id/create-ncr
POST /quality/supplier-issues/:id/request-response
POST /quality/supplier-issues/:id/close
```

## Inspection / ITP

```text
GET  /quality/itp
POST /quality/itp
GET  /quality/inspections
POST /quality/inspections
GET  /quality/inspections/:id
PATCH /quality/inspections/:id
POST /quality/inspections/:id/submit-result
POST /quality/inspections/:id/create-ncr
```

## Punch List / Defect

```text
GET  /quality/punch-lists
POST /quality/punch-lists
GET  /quality/defects
POST /quality/defects
POST /quality/defects/:id/create-ncr
POST /quality/punch-items/:id/close
```

## Calibration

```text
GET  /quality/calibration-equipment
POST /quality/calibration-equipment
GET  /quality/calibration-equipment/:id
PATCH /quality/calibration-equipment/:id
GET  /quality/calibration-due
POST /quality/calibration-records
POST /quality/calibration-records/:id/verify
```

## Dashboard & Reports

```text
GET /quality/dashboard
GET /quality/kpi
GET /quality/cost-of-quality
GET /quality/reports/:type
GET /quality/export
```

## Settings

```text
GET   /quality/settings
PATCH /quality/settings
GET   /quality/master-data
```
