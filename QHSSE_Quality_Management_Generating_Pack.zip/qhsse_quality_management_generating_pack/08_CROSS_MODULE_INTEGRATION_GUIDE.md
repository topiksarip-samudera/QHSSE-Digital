# 08 — CROSS-MODULE INTEGRATION GUIDE

## Audit & Inspection

```text
- Audit finding can create NCR.
- Inspection finding can create NCR or defect.
- Repeated finding can trigger CAPA effectiveness review.
```

## Document Control

```text
- NCR can link to SOP, ITP, drawing, specification.
- NCR can trigger document revision request.
- Obsolete specification can trigger quality review.
```

## Training & Competency

```text
- NCR root cause can create training need.
- Inspector competency can be validated.
- Training evidence can support CAPA effectiveness.
```

## Contractor / Supplier

```text
- Supplier issue affects supplier performance.
- Contractor defect affects contractor score.
- Supplier response can be tracked.
```

## Asset & Equipment

```text
- Calibration equipment linked to asset.
- Out-of-tolerance can create NCR.
- Equipment defect can create quality issue.
```

## Risk & Legal Compliance

```text
- Quality risk can be linked to risk register.
- ISO 9001 requirement can be compliance evidence.
- Client requirement can become obligation.
```
