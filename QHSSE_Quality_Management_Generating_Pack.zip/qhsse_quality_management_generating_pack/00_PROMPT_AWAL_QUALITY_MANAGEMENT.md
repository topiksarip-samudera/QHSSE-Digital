# 00 — PROMPT AWAL QUALITY MANAGEMENT UNTUK AI AGENT

Core Platform sudah stabil. Incident Management, Risk Management, Audit & Inspection, Permit to Work, Document Control, Training & Competency, Legal & Compliance, dan Environment Management sudah selesai atau siap integrasi.

Sekarang mulai generate QHSSE Operational Module: **Quality Management**.

Baca seluruh file dalam folder `qhsse_quality_management_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_master_data.md`.
3. Gunakan core yang sudah ada: tenant, site/project/department/location, permission, module ON/OFF, master data, workflow, action tracking, attachment, audit log, notification, numbering, dashboard, API/webhook.
4. Quality Management tidak boleh hanya menjadi NCR CRUD.
5. Harus ada NCR, complaint, supplier issue, inspection, ITP, punch list, RCA, disposition, CAPA, calibration, KPI, dan report.
6. Semua data wajib tenant-safe.
7. Semua API wajib permission-guarded.
8. Semua quality decision, status change, disposition, CAPA verification, calibration status, dan export harus audit logged.
9. Setelah sequence selesai, tulis: `SELESAI QUALITY SEQUENCE XX: <nama sequence>`.
10. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
