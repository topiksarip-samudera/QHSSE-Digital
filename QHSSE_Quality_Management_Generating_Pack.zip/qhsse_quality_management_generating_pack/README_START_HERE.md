# START HERE — QHSSE Quality Management Generating Pack

Tanggal: 2026-06-22

Paket ini dibuat untuk menghasilkan modul **Quality Management** pada WebApp QHSSE secara sequence, lengkap, dan tidak menjadi CRUD NCR biasa.

## Posisi Modul dalam Roadmap

```text
Core Platform
→ Stabilization & QA
→ Incident Management
→ Risk Management / HIRADC / JSA
→ Audit & Inspection
→ Permit to Work
→ Document Control
→ Training & Competency
→ Legal & Compliance Register
→ Environment Management
→ Quality Management
→ Security Management
→ Contractor Management
→ Emergency Response
→ Asset & Equipment
```

## Rekomendasi Split

Quality Management sebaiknya di-split menjadi **12 sequence**:

```text
01 Foundation & Master Data
02 NCR / Nonconformance Core
03 Customer Complaint & Internal Quality Issue
04 Supplier Quality Issue & Material Receiving Inspection
05 In-Process, Final Inspection & ITP
06 Punch List & Defect Management
07 Root Cause Analysis & Disposition
08 CAPA, Verification & Effectiveness Review
09 Calibration & Measurement Equipment Control
10 Integration with Audit, Document, Training, Contractor & Asset
11 Dashboard, KPI, Cost of Quality, Report & Export
12 QA, Test, Permission & Stabilization
```

## Kenapa 12 Sequence?

Quality Management harus mengontrol:

```text
NCR
Customer complaint
Supplier quality issue
Material receiving inspection
In-process inspection
Final inspection
ITP
Punch list
Defect management
RCA
Disposition
CAPA
Calibration
Cost of quality
Quality KPI
```

Jika digenerate sekaligus, biasanya modul hanya menjadi form NCR biasa. Dengan 12 sequence, hasilnya menjadi quality control system yang lengkap.

## Cara Pakai

1. Extract ZIP ke project.
2. Baca `00_PROMPT_AWAL_QUALITY_MANAGEMENT.md`.
3. Baca `01_QUALITY_MANAGEMENT_MASTER_BLUEPRINT.md`.
4. Baca `02_QUALITY_MANAGEMENT_GENERATING_RULES.md`.
5. Mulai dari `sequence/01_foundation_master_data.md`.
6. Selesaikan satu sequence.
7. Setelah selesai, AI Agent harus menulis `SELESAI QUALITY SEQUENCE XX`.
8. Jangan lanjut sequence berikutnya sebelum diminta.

## Status Akhir

```text
QUALITY MANAGEMENT STABILIZED: GO
```
