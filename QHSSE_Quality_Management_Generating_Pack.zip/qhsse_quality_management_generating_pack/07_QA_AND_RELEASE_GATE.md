# 07 — QA AND RELEASE GATE

## QA Scope

```text
Tenant Isolation
Permission & Scope
NCR Lifecycle
Complaint Handling
Supplier Quality Issue
Inspection / ITP
Punch List
RCA
Disposition
CAPA Integration
Verification
Calibration Due/Overdue
Dashboard Calculation
Report Export
Audit Log
Notification
Cross-Module Links
Regression Test
```

## Release Gate

Quality Management hanya boleh dinyatakan selesai jika:

```text
P0 = 0
P1 = 0
Tenant isolation PASS
Permission backend PASS
NCR lifecycle PASS
Complaint flow PASS
Supplier issue flow PASS
Inspection/ITP PASS
RCA/disposition PASS
CAPA verification PASS
Calibration PASS
Dashboard calculation PASS
Report export PASS
Audit log PASS
Cross-module integration PASS
Lint/test/build PASS
```

## Status Akhir

```text
QUALITY MANAGEMENT STABILIZED: GO
```
