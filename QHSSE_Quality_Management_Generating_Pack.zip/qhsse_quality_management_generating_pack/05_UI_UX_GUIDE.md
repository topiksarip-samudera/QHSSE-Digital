# 05 — UI/UX GUIDE QUALITY MANAGEMENT

## Sidebar

```text
Quality Management
├── Overview
├── NCR Register
├── Customer Complaints
├── Supplier Quality Issues
├── Material Receiving Inspection
├── In-Process Inspection
├── Final Inspection
├── ITP
├── Punch List
├── Defect Register
├── CAPA
├── Calibration
├── Reports
└── Settings
```

## NCR Detail Tabs

```text
Overview
Affected Item
Evidence
Disposition
Root Cause Analysis
CAPA
Verification
Effectiveness Review
Linked Records
Attachments
Comments
Workflow
Audit Trail
```

## Components

```text
NcrStatusBadge
QualitySeverityBadge
DispositionBadge
RcaPanel
CapaPanel
EffectivenessReviewPanel
ComplaintResponsePanel
SupplierResponsePanel
InspectionResultTable
PunchListBoard
CalibrationDueCard
CostOfQualityCard
QualityTrendChart
```

## UX Penting

- NCR creation harus cepat dari audit/inspection/complaint/supplier/inspection result.
- Disposition harus jelas dan tidak bisa dilewati jika wajib.
- CAPA dan verification harus terlihat di detail.
- Calibration due/overdue harus jelas.
- Dashboard harus menampilkan tren dan overdue action.
