# 09 — Calibration & Measurement Equipment Control

## Tujuan

Membangun register alat ukur, calibration schedule, certificate, due/overdue, calibration result, out-of-tolerance handling, dan equipment status.

## Scope

Sequence ini harus menghasilkan database, backend API, frontend UI, permission, audit log, test minimal, dan acceptance criteria.

## Fitur Wajib
```text
Measurement equipment register
Calibration schedule
Calibration certificate
Due/overdue
Out of tolerance
Adjustment required
Equipment status
```

## Database yang Mungkin Dibuat/Diubah

```text
quality_settings
quality_categories
quality_severities
ncr_records
ncr_affected_items
ncr_dispositions
ncr_root_causes
quality_capa_links
customer_complaints
supplier_quality_issues
material_receiving_inspections
quality_inspection_plans
quality_inspection_results
itp_records
punch_lists
punch_items
defect_records
calibration_equipment
calibration_schedules
calibration_records
quality_cost_records
quality_links
```

Gunakan hanya tabel yang relevan untuk sequence ini. Jangan duplikasi tabel core yang sudah ada.

## API Pattern

```text
GET /api/v1/quality/ncr
POST /api/v1/quality/ncr
GET /api/v1/quality/ncr/:id
PATCH /api/v1/quality/ncr/:id
POST /api/v1/quality/ncr/:id/submit
POST /api/v1/quality/ncr/:id/review
POST /api/v1/quality/ncr/:id/assign-capa
POST /api/v1/quality/ncr/:id/verify
POST /api/v1/quality/ncr/:id/close
```

Tambahkan endpoint khusus sesuai sequence.

## Frontend Minimal

```text
List page
Create/update form
Detail page
Status badge
Filter/search
Evidence panel jika relevan
RCA/CAPA panel jika relevan
Workflow tab jika relevan
Attachment tab jika relevan
Audit trail tab jika relevan
```

## Permission

Tambahkan permission sesuai kebutuhan sequence dan pastikan backend guard aktif.

## Audit Log

Catat create/update/delete/submit/review/disposition/RCA/CAPA/verify/close/export sesuai sequence.

## Testing Minimal

```text
Happy path
Validation error
Permission denied
Tenant isolation
Audit log created
Status transition
```

## Acceptance Criteria

- Fitur sequence berjalan end-to-end.
- Tenant-safe.
- Permission backend berjalan.
- UI tidak menampilkan tombol tanpa permission.
- Audit log tercatat.
- Test minimal lulus.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI QUALITY SEQUENCE 09: Calibration & Measurement Equipment Control
```
