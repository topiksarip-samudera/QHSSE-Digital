# 06 — PERMISSION & SECURITY GUIDE

## Scope

```text
Global
Company
Site
Project
Department
Owner
Assigned PIC
Reviewer
Verifier
Supplier/Contractor limited access optional
```

## Security Rules

- Semua query wajib filter company_id.
- User hanya melihat NCR/complaint/inspection sesuai scope.
- Supplier/contractor hanya boleh melihat issue yang ditugaskan jika portal tersedia.
- Verification membutuhkan permission khusus.
- Disposition approval membutuhkan permission khusus.
- Calibration certificate download harus permission-guarded.
- Report export harus audit logged.
- Closed NCR tidak boleh diedit kecuali reopen permission.
- CAPA close-out harus melalui verification.
