# 01 — MASTER BLUEPRINT QUALITY MANAGEMENT

## Tujuan Modul

Modul **Quality Management** digunakan untuk mengelola nonconformance, complaint, supplier quality issue, inspection result, defect, punch list, RCA, disposition, CAPA, calibration, cost of quality, quality KPI, dan reporting.

Modul ini harus menjadi pusat pengendalian mutu operasional dan compliance ISO 9001.

## Prinsip Desain

1. Quality Management bukan hanya NCR register.
2. NCR harus bisa berasal dari audit, inspection, supplier, customer, internal process, material inspection, final inspection, atau project punch list.
3. Setiap nonconformance harus bisa memiliki severity, category, affected item, evidence, disposition, RCA, dan CAPA.
4. Disposition harus jelas: use as is, rework, repair, reject, scrap, return to vendor, concession.
5. CAPA harus bisa diverifikasi dan diuji efektivitasnya.
6. Calibration harus mengontrol alat ukur, certificate, due date, out-of-tolerance, dan status alat.
7. Quality dashboard harus menampilkan trend, overdue CAPA, defect, complaint, supplier issue, calibration due, dan cost of quality.
8. Semua critical decision harus human-reviewed dan audit logged.

## Submodul Utama

```text
NCR / Nonconformance Report
Customer Complaint
Internal Quality Issue
Supplier Quality Issue
Material Receiving Inspection
In-Process Inspection
Final Inspection
Inspection Test Plan / ITP
Punch List
Defect Management
Root Cause Analysis
Disposition
CAPA
Effectiveness Review
Calibration Management
Measurement Equipment Control
Cost of Poor Quality
Quality Dashboard
Quality Reporting
```

## NCR Source

```text
Audit Finding
Inspection Finding
Customer Complaint
Supplier Issue
Internal Process Issue
Material Receiving Inspection
In-Process Inspection
Final Inspection
Punch List
Calibration Failure
Incident / Quality Incident
External Claim
```

## Disposition

```text
Use As Is
Rework
Repair
Reject
Scrap
Return To Vendor
Concession
Regrade
Hold
```

## Status Standard

```text
draft
submitted
under_review
disposition_required
rca_required
action_assigned
in_progress
pending_verification
verified
effectiveness_review
closed
cancelled
archived
```

## Output Utama

```text
NCR Register
Complaint Register
Supplier Quality Issue Register
Inspection Result Register
ITP Register
Punch List Register
Defect Register
RCA Report
Disposition Record
CAPA Register
Calibration Register
Calibration Due List
Quality KPI Dashboard
Cost of Quality Report
NCR PDF/Excel Export
```

## Integrasi Modul Lain

```text
Audit & Inspection: finding can create NCR.
Document Control: SOP, ITP, drawing, specification link.
Training & Competency: quality training and inspector competency.
Contractor Management: supplier/contractor quality issue and score.
Asset & Equipment: calibration and measuring equipment.
Risk Management: quality risk and process control.
Action Tracking: CAPA from NCR/complaint/defect.
Legal & Compliance: ISO 9001/client requirement evidence.
Incident Management: quality incident link.
```
