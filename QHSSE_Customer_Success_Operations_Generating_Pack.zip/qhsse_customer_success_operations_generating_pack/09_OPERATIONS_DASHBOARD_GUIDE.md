# 09 — OPERATIONS DASHBOARD GUIDE

## Customer Success Dashboard

```text
Total customers
Active customers
At-risk customers
Onboarding customers
Renewal due
Churned customers
Expansion opportunities
Average health score
```

## Support Dashboard

```text
Open tickets
P0/P1 tickets
SLA compliance
Average first response time
Average resolution time
Ticket by category
Escalated tickets
Recurring issue
```

## Adoption Dashboard

```text
MAU
WAU
Module adoption
Mobile adoption
AI adoption
Reports adoption
Inactive users
Workflow completion
```

## Renewal Dashboard

```text
Renewal pipeline
Renewal due 120/90/60/30 days
Renewed revenue
At-risk renewal
Churn reason
Expansion opportunity
```
