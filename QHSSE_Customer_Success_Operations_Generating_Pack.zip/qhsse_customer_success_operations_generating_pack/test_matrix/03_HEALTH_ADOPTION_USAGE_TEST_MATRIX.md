# 03 Health Adoption Usage Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| CSO-001 | Health score calculated | PASS |
| CSO-002 | Adoption score calculated | PASS |
| CSO-003 | Usage analytics created | PASS |
| CSO-004 | Module adoption tracked | PASS |
| CSO-005 | AI usage tracked | PASS |
| CSO-006 | Mobile usage tracked | PASS |
| CSO-007 | Report usage tracked | PASS |
| CSO-008 | At-risk customer detected | PASS |
