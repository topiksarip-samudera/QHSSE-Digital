# 04 Renewal Voc Training Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| CSO-001 | Renewal timeline created | PASS |
| CSO-002 | Churn risk trigger works | PASS |
| CSO-003 | Save plan created | PASS |
| CSO-004 | Training path ready | PASS |
| CSO-005 | KB update process ready | PASS |
| CSO-006 | Feedback intake ready | PASS |
| CSO-007 | Feature request prioritized | PASS |
| CSO-008 | Roadmap communication ready | PASS |
