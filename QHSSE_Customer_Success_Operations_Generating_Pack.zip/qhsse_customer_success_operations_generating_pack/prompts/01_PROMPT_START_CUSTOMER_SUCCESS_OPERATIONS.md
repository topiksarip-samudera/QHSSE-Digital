# 01 Prompt Start Customer Success Operations

Mulai generate Customer Success & Operations dari sequence/01_customer_success_strategy_operating_model.md. Kerjakan sequence pertama saja. Setelah selesai tulis: SELESAI CUSTOMER SUCCESS OPERATIONS SEQUENCE 01: Customer Success Strategy & Operating Model.
