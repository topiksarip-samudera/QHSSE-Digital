# Support SLA Tracker

| Ticket ID | Customer | Category | Priority | Created At | First Response Due | Resolution Due | Owner | Status | SLA Status |
|---|---|---|---|---|---|---|---|---|---|
|  |  | Bug/How-to/Billing/AI/Mobile | P0/P1/P2/P3/P4 |  |  |  |  | Open | On Track/Breached |
