# Quarterly Business Review Template

## Customer Summary

```text
Customer:
Period:
CS Owner:
Account Manager:
Overall Health:
```

## Value Delivered

```text
Modules adopted:
Key workflows completed:
Reports used:
Mobile usage:
AI usage:
Support resolved:
```

## Risks & Actions

| Risk | Impact | Owner | Due Date | Status |
|---|---|---|---|---|
|  |  |  |  |  |

## Next Success Plan

```text
Next milestone:
Training needed:
Expansion opportunity:
Renewal action:
```
