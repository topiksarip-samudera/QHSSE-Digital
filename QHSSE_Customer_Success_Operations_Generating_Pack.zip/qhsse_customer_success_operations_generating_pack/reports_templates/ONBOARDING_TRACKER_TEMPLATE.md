# Customer Onboarding Tracker

| Customer | Stage | Milestone | Owner | Due Date | Status | Evidence | Notes |
|---|---|---|---|---|---|---|---|
|  | Onboarding | Tenant setup |  |  | Not Started/In Progress/Done/Blocked |  |  |
