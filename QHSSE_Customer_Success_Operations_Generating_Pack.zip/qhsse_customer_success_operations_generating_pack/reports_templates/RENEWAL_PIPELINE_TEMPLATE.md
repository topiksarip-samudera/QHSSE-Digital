# Renewal Pipeline Template

| Customer | Plan | Renewal Date | ARR/MRR | Health | Risk | Owner | Next Action | Status |
|---|---|---|---:|---|---|---|---|---|
|  |  |  |  | Healthy/At Risk | Low/Med/High |  |  | Open |
