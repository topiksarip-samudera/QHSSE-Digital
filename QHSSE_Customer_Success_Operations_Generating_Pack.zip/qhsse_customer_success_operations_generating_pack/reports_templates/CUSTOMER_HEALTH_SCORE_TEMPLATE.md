# Customer Health Score Template

| Customer | Segment | Usage Score | Adoption Score | Support Score | Training Score | Renewal Score | Engagement Score | Total Score | Risk Level | Owner | Action |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|
|  |  |  |  |  |  |  |  |  | Healthy/Watch/At Risk/Critical |  |  |
