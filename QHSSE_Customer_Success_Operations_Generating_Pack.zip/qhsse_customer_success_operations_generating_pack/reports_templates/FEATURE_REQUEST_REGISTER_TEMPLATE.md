# Feature Request Register

| Request ID | Customer | Module | Request | Impact | Frequency | Priority | Decision | Roadmap Status | Owner |
|---|---|---|---|---|---|---|---|---|---|
| FR-001 |  |  |  |  |  | High/Med/Low | Review/Accept/Reject | New |  |
