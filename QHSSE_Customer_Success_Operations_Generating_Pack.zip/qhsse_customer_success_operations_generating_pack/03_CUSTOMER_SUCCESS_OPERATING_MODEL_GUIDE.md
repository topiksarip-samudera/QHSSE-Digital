# 03 — CUSTOMER SUCCESS OPERATING MODEL GUIDE

## Team Roles

```text
Customer Success Manager
Support Agent
Technical Support
Implementation Specialist
Product Owner
Engineering Escalation Owner
Account Manager
Renewal Manager
Training Specialist
```

## Responsibility Matrix

```text
CSM → adoption, health, QBR, renewal risk
Support → ticket handling and SLA
Technical Support → technical troubleshooting
Product Owner → roadmap and feature request review
Engineering → bug fix and escalation
Account Manager → commercial follow-up and expansion
Training Specialist → enablement and role-based training
```

## Operating Cadence

```text
Daily: support triage and P0/P1 review
Weekly: health score and adoption review
Bi-weekly: feedback and roadmap review
Monthly: customer success report
Quarterly: QBR and renewal pipeline review
```

## Customer Lifecycle Status

```text
Onboarding
Active
Adopting
Expanding
At Risk
Renewal Due
Renewed
Churned
Winback
```
