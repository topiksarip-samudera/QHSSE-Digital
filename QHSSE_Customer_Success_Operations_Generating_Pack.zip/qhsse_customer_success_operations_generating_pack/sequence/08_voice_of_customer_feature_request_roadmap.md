# 08 Voice of Customer, Feature Request & Roadmap Feedback

## Tujuan

Membangun VoC, customer feedback loop, feature request intake, prioritization, roadmap review, dan customer communication.

## Fokus

```text
VoC, feedback intake, feature request, prioritization, roadmap review, communication
```

## Output Wajib

```text
Workflow / board / dashboard spec
Template
Owner matrix jika relevan
Metric definition
Acceptance criteria
Risk and issue list
Operations note
```

## Area yang Harus Dicek

```text
Customer lifecycle
Onboarding
Support
SLA
Adoption
Health score
Usage analytics
Renewal
Feedback
Training
QBR
Dashboard
Continuous improvement
```

## Testing Minimal

```text
Happy path
Negative case
Owner assigned
Status updated
Metric calculated
Evidence captured
Escalation works if relevant
```

## Acceptance Criteria

- Output sequence bisa dipakai untuk operasional customer real.
- Owner, metric, status, dan action jelas.
- Risk/churn/issue bisa dideteksi.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI CUSTOMER SUCCESS OPERATIONS SEQUENCE 08: Voice of Customer, Feature Request & Roadmap Feedback
```
