# 07 — RENEWAL & CHURN PREVENTION GUIDE

## Renewal Timeline

```text
120 days before renewal: account health review
90 days before renewal: QBR and value review
60 days before renewal: renewal proposal
30 days before renewal: commercial confirmation
14 days before renewal: final reminder
0 day: renewal / expiration handling
```

## Churn Prevention Playbook

```text
Identify risk
Confirm reason
Assign owner
Create save plan
Schedule customer call
Offer training/support
Resolve blockers
Show value report
Propose better plan if needed
Track outcome
```

## Retention Actions

```text
Additional training
Workflow optimization
Executive review
Support escalation
Plan adjustment
Feature workaround
Implementation assistance
Success milestone reset
```
