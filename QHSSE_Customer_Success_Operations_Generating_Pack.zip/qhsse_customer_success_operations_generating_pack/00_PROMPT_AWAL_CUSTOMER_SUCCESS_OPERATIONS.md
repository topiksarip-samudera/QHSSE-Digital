# 00 — PROMPT AWAL CUSTOMER SUCCESS & OPERATIONS UNTUK AI AGENT

Core Platform, seluruh QHSSE Operational Modules, Reports & Analytics, AI Assistant, Mobile/PWA Field Optimization, SaaS Commercialization, Production Hardening & Go-Live Preparation, Beta Testing & Pilot Customer Program, Commercial Launch Preparation, dan Public Launch Execution sudah selesai atau siap integrasi.

Platform yang sekarang harus dioperasikan untuk customer real:

```text
Core Platform
Stabilization & QA
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
Mobile/PWA Field Optimization
SaaS Commercialization
Production Hardening & Go-Live Preparation
Beta Testing & Pilot Customer Program
Commercial Launch Preparation
Public Launch Execution
```

Sekarang generate tahap **Customer Success & Operations** berdasarkan folder `qhsse_customer_success_operations_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_customer_success_strategy_operating_model.md`.
3. Tahap ini tidak boleh hanya membuat checklist support umum.
4. Harus menghasilkan operating model, lifecycle, onboarding monitoring, support workflow, SLA, escalation, health score, adoption tracking, usage analytics, renewal workflow, churn prevention, training operations, knowledge base process, VoC, feature request, QBR, operations dashboard, dan continuous improvement backlog.
5. Harus mencakup customer lifecycle dari onboarding sampai renewal.
6. Harus mencakup customer health score dan churn risk.
7. Harus mencakup support SLA dan escalation.
8. Harus mencakup adoption tracking per module, AI, mobile, reports, dan user activity.
9. Harus mencakup renewal management dan retention playbook.
10. Harus mencakup feature request management dan roadmap feedback.
11. Harus mencakup account management dan QBR.
12. Harus menghasilkan operations dashboard dan release gate.
13. Semua output harus bisa dipakai oleh AI agent untuk membuat halaman, dokumen, board, template, dashboard, dan workflow.
14. Setelah sequence selesai, tulis:
   `SELESAI CUSTOMER SUCCESS OPERATIONS SEQUENCE XX: <nama sequence>`
15. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
