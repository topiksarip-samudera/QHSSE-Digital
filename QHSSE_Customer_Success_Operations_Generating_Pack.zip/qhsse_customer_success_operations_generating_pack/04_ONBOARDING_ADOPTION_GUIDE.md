# 04 — ONBOARDING & ADOPTION GUIDE

## Onboarding Milestones

```text
Tenant created
Admin invited
Company profile completed
Sites/projects created
Roles configured
Users invited
Modules enabled
Master data uploaded
First workflow completed
First mobile submission
First report viewed
First AI assistant usage
Training completed
Go-live confirmed
```

## Activation Metrics

```text
Admin login
User invite accepted
First incident created
First inspection completed
First permit approved
First document published
First report exported
First mobile evidence captured
First AI question asked
```

## Adoption Levels

```text
Low Adoption: setup incomplete or few users active
Medium Adoption: several workflows used
High Adoption: core modules and reports used consistently
Advanced Adoption: AI, mobile, reports, and cross-module workflows used
```
