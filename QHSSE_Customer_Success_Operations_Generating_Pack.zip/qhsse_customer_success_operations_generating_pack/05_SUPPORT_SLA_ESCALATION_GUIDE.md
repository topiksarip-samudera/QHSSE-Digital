# 05 — SUPPORT, SLA & ESCALATION GUIDE

## Ticket Categories

```text
Bug
How-to Question
Access / Permission
Billing
Training Request
Integration
Performance
Mobile/PWA
AI Assistant
Report Issue
Feature Request
Security Concern
```

## SLA Matrix

```text
P0 Critical: response 1–2 hours, update every 2 hours
P1 High: response 4–8 business hours, update daily
P2 Medium: response 1 business day, update every 2–3 days
P3 Low: response 3 business days
P4 Request: response 5 business days
```

## Escalation Path

```text
Support Agent
Technical Support
Engineering Lead
Product Owner
Customer Success Manager
Management Escalation
```

## Support Macro Examples

```text
Acknowledgement
Need more information
Workaround provided
Issue escalated
Fix scheduled
Issue resolved
Feature request accepted for review
Feature request added to roadmap consideration
```
