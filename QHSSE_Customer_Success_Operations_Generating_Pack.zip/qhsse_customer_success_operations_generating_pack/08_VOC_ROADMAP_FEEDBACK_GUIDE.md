# 08 — VOICE OF CUSTOMER & ROADMAP FEEDBACK GUIDE

## Feedback Intake

```text
Support ticket
QBR
Survey
User interview
Sales feedback
Implementation feedback
Churn reason
Feature request form
```

## Feature Request Fields

```text
Customer
Role
Module
Problem
Requested feature
Business impact
Frequency
Workaround
Priority
Revenue impact
Strategic value
Decision
Status
```

## Prioritization

```text
Customer impact
Revenue impact
Strategic fit
Frequency
Implementation effort
Security/compliance requirement
Enterprise demand
```

## Roadmap Status

```text
New
Under Review
Accepted
Planned
In Progress
Released
Rejected
Future Consideration
```
