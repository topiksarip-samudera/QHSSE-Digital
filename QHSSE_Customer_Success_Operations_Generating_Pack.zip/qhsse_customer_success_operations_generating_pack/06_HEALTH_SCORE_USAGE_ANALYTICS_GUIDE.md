# 06 — HEALTH SCORE & USAGE ANALYTICS GUIDE

## Health Score Formula Example

```text
Health Score = 
Usage Score 30%
Adoption Score 25%
Support Score 15%
Training Score 10%
Renewal Score 10%
Engagement Score 10%
```

## Usage Metrics

```text
Monthly active users
Weekly active users
Login frequency
Module usage
Workflow completion
Mobile submission count
AI assistant usage
Report/dashboard views
Export count
Support ticket count
Overdue action count
```

## Churn Risk Signals

```text
No login for 14+ days
Admin inactive
No core workflow completed
Support P0/P1 unresolved
Payment past due
Low training completion
Low report usage
Negative feedback
No QBR attendance
Renewal date near with low usage
```
