# 02 — CUSTOMER SUCCESS & OPERATIONS GENERATING RULES

## Aturan Utama

1. Jangan membuat CS hanya sebagai support ticket.
2. Semua customer lifecycle harus punya status dan owner.
3. Onboarding harus punya milestone dan due date.
4. Activation harus diukur dari aktivitas nyata.
5. Support ticket harus punya priority dan SLA.
6. Escalation harus jelas untuk P0/P1.
7. Health score harus dihitung dari beberapa komponen.
8. Churn risk harus punya trigger dan mitigation.
9. Renewal harus dimulai jauh sebelum subscription berakhir.
10. Training harus role-based.
11. Knowledge base harus diperbarui dari ticket dan feedback.
12. Feature request harus diprioritaskan, tidak langsung dijanjikan.
13. QBR harus berbasis usage, value, issue, dan next plan.
14. Operations dashboard harus menampilkan KPI yang actionable.
15. Semua keputusan penting harus audit-friendly.

## Priority Support

```text
P0 = production down / critical business blocker / data security issue
P1 = major workflow blocker / no workaround
P2 = important issue with workaround
P3 = minor bug / usability issue
P4 = question / request / enhancement
```

## Customer Health Score Components

```text
Usage score
Adoption score
Support score
Training score
Renewal score
Engagement score
Payment/billing score
Product fit score
```

## Risk Level

```text
Healthy
Watch
At Risk
Critical
Churned
```
