# 05 — UI/UX GUIDE ENVIRONMENT MANAGEMENT

## Sidebar

```text
Environment Management
├── Overview
├── Aspect & Impact
├── Environmental Permits
├── Waste Management
├── Limbah B3 / Hazardous Waste
├── Waste Manifest
├── Monitoring Schedule
├── Monitoring Results
├── Exceedance
├── Spill / Environmental Incident
├── Energy / Fuel / Chemical
├── Reports
└── Settings
```

## Halaman Utama

```text
Environment Overview Dashboard
Aspect Impact Register
Environmental Permit Register
Waste Register
Limbah B3 Register
Manifest Register
Monitoring Point Register
Monitoring Schedule Calendar
Monitoring Result Entry
Lab Result Upload
Exceedance Register
Spill Register
Energy/Fuel/Chemical Usage
Environmental Report Export
Settings
```

## Detail Tabs

Environmental Permit:
```text
Overview
Obligations
Evidence
Renewal History
Attachments
Comments
Audit Trail
```

Monitoring Result:
```text
Overview
Parameter Result
Limit Comparison
Lab Report
Exceedance
Action
Review
Audit Trail
```

Exceedance:
```text
Overview
Source Result
Root Cause
Action
Verification
Evidence
Comments
Audit Trail
```

Waste Manifest:
```text
Overview
Waste Detail
Transporter
Disposal Vendor
Manifest File
Verification
Audit Trail
```

## Komponen Wajib

```text
EnvironmentStatusBadge
AspectSignificanceBadge
PermitExpiryBadge
WasteCategoryBadge
MonitoringResultBadge
LimitComparisonPanel
ExceedanceBadge
SpillSeverityBadge
ManifestStatusBadge
MonitoringCalendar
EnvironmentalKpiCard
EnvironmentalTrendChart
ComplianceEvidencePanel
```

## UX Penting

- Monitoring schedule harus bisa dilihat dalam calendar/list.
- Lab result upload harus mudah dan bisa menampilkan pass/exceedance.
- Exceedance harus terlihat jelas dan bisa langsung create action.
- Waste manifest harus mudah dilacak statusnya.
- Environmental permit expiry harus jelas.
- Dashboard harus bisa filter by site/period/media type.
