# 02 — ENVIRONMENT MANAGEMENT GENERATING RULES

## Aturan Utama

1. Jangan membuat modul ini hanya sebagai tabel pencatatan limbah.
2. Environmental aspect-impact harus punya register tersendiri.
3. Environmental permit harus bisa link ke Legal Compliance.
4. Monitoring parameter harus configurable.
5. Legal limit harus bisa configurable dan/atau berasal dari Legal Compliance.
6. Monitoring result harus dibandingkan dengan limit.
7. Exceedance harus bisa membuat action.
8. Spill harus bisa membuat environmental incident/action.
9. Waste manifest harus punya lifecycle.
10. Evidence harus bisa link ke Legal Compliance.
11. Semua critical change harus audit logged.
12. Semua data wajib tenant-safe.
13. Semua API wajib permission-guarded.
14. Export environmental report harus permission-aware dan audit logged.

## Permission Standard

```text
environment.view
environment.view_all
environment.create
environment.update
environment.delete
environment.submit
environment.review
environment.approve
environment.close
environment.export
environment.manage_settings

env_aspect.view
env_aspect.create
env_aspect.update
env_aspect.approve

env_permit.view
env_permit.create
env_permit.update
env_permit.renew

env_waste.view
env_waste.create
env_waste.update
env_waste.verify

env_monitoring.view
env_monitoring.create
env_monitoring.update
env_monitoring.review

env_exceedance.view
env_exceedance.create
env_exceedance.assign_action
env_exceedance.verify
env_exceedance.close
```

## Audit Log Wajib

```text
env.aspect_created
env.aspect_updated
env.permit_created
env.permit_updated
env.permit_renewed
env.waste_created
env.manifest_uploaded
env.manifest_verified
env.monitoring_scheduled
env.monitoring_result_uploaded
env.exceedance_detected
env.exceedance_action_assigned
env.exceedance_closed
env.spill_reported
env.incident_created
env.report_exported
env.settings_changed
```

## Webhook Events

```text
env.permit_expiring
env.monitoring_due
env.monitoring_overdue
env.result_uploaded
env.exceedance_detected
env.spill_reported
env.waste_manifest_due
env.manifest_uploaded
env.action_overdue
env.kpi_updated
```
