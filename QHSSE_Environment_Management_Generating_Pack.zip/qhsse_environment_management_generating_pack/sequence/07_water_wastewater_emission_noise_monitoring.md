# 07 — Water, Wastewater, Emission & Noise Monitoring

## Tujuan

Membangun monitoring result, lab result upload, limit comparison, review, status compliant/exceedance, dan evidence.

## Scope

Sequence ini harus menghasilkan database, backend API, frontend UI, permission, audit log, test minimal, dan acceptance criteria.


## Fitur Wajib

```text
Water result
Wastewater result
Emission result
Noise result
Lab report upload
Measured value
Limit snapshot
Automatic comparison
Review result
Create exceedance
```


## Database yang Mungkin Dibuat/Diubah

```text
environment_settings
environment_aspects
environment_impacts
environment_permits
environment_monitoring_points
environment_parameters
environment_limits
environment_monitoring_schedules
environment_monitoring_results
environment_exceedances
environment_spills
environment_waste_records
environment_waste_manifests
environment_energy_records
environment_fuel_records
environment_chemical_records
environment_resource_records
environment_links
environment_kpi_records
```

Gunakan hanya tabel yang relevan untuk sequence ini. Jangan duplikasi tabel core yang sudah ada.

## API Pattern

```text
GET /api/v1/environment/aspects
POST /api/v1/environment/aspects
GET /api/v1/environment/permits
POST /api/v1/environment/permits
GET /api/v1/environment/waste-records
POST /api/v1/environment/waste-records
GET /api/v1/environment/monitoring-results
POST /api/v1/environment/monitoring-results
GET /api/v1/environment/exceedances
POST /api/v1/environment/exceedances
```

Tambahkan endpoint khusus sesuai sequence.

## Frontend Minimal

```text
List page
Create/update form
Detail page
Status badge
Filter/search
Calendar/matrix/table jika relevan
Evidence panel jika relevan
Action panel jika relevan
Attachment tab jika relevan
Comment tab jika relevan
Audit trail tab jika relevan
```

## Permission

Tambahkan permission sesuai kebutuhan sequence dan pastikan backend guard aktif.

## Audit Log

Catat create/update/delete/submit/review/verify/exceedance/action/manifest/export sesuai sequence.

## Testing Minimal

```text
Happy path
Validation error
Permission denied
Tenant isolation
Audit log created
Status transition
Evidence security jika relevan
```

## Acceptance Criteria

- Fitur sequence berjalan end-to-end.
- Tenant-safe.
- Permission backend berjalan.
- UI tidak menampilkan tombol tanpa permission.
- Audit log tercatat.
- Monitoring/exceedance decision penting tetap human-reviewed.
- Test minimal lulus.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI ENVIRONMENT SEQUENCE 07: Water, Wastewater, Emission & Noise Monitoring
```
