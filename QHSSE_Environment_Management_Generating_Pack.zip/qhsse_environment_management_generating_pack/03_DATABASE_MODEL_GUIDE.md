# 03 — DATABASE MODEL GUIDE

## Tabel Minimal

```text
environment_settings
environment_aspect_categories
environment_aspects
environment_impacts
environment_aspect_controls
environment_permits
environment_permit_obligations
environment_monitoring_points
environment_parameters
environment_limits
environment_monitoring_schedules
environment_monitoring_results
environment_lab_results
environment_exceedances
environment_spills
environment_incidents
environment_waste_types
environment_waste_records
environment_waste_storage
environment_waste_transfers
environment_waste_manifests
environment_transporters
environment_disposal_vendors
environment_energy_records
environment_fuel_records
environment_chemical_records
environment_resource_records
environment_kpi_records
environment_links
```

## Field Umum Wajib

Semua tabel tenant-specific wajib punya:

```text
id
company_id
site_id optional
department_id optional
location_id optional
created_by
updated_by
created_at
updated_at
deleted_at optional
status
```

## environment_aspects

```text
id
company_id
site_id
department_id optional
activity_or_process
aspect_category_id
aspect_description
impact_description
condition_type
normal_abnormal_emergency
severity_score
frequency_score
legal_concern_score
stakeholder_concern_score
significance_score
is_significant
controls
responsible_person_id
review_frequency_months
next_review_date
status
created_by
updated_by
created_at
updated_at
```

## environment_permits

```text
id
company_id
permit_number
permit_name
permit_type
issuing_authority
site_id
scope
issue_date
valid_from
valid_until
renewal_due_date
responsible_person_id
legal_obligation_id optional
document_id optional
file_id optional
status
created_by
updated_by
created_at
updated_at
```

## environment_monitoring_points

```text
id
company_id
site_id
location_id optional
point_code
point_name
monitoring_type
media_type
parameter_group
asset_id optional
legal_obligation_id optional
is_active
created_at
updated_at
```

## environment_parameters

```text
id
company_id
parameter_code
parameter_name
unit
media_type
method_reference optional
is_active
created_at
updated_at
```

## environment_limits

```text
id
company_id
parameter_id
site_id optional
monitoring_point_id optional
legal_obligation_id optional
limit_type
min_value optional
max_value optional
unit
valid_from
valid_until optional
status
created_at
updated_at
```

## environment_monitoring_results

```text
id
company_id
result_number
schedule_id optional
monitoring_point_id
parameter_id
sample_date
result_date
measured_value
unit
limit_value_snapshot
result_status
lab_name optional
lab_report_file_id optional
reviewed_by optional
reviewed_at optional
exceedance_id optional
status
created_by
updated_by
created_at
updated_at
```

## environment_exceedances

```text
id
company_id
exceedance_number
source_type
source_id
monitoring_point_id optional
parameter_id optional
limit_value
measured_value
exceedance_level
description
immediate_action
root_cause optional
action_id optional
pic_id
due_date
verification_status
status
created_by
updated_by
closed_by optional
closed_at optional
created_at
updated_at
```

## environment_waste_records

```text
id
company_id
waste_record_number
waste_type_id
waste_category
is_hazardous
site_id
location_id optional
generated_date
quantity
unit
source_activity
storage_location
container_type optional
label_status
responsible_person_id
status
created_by
updated_by
created_at
updated_at
```

## environment_waste_manifests

```text
id
company_id
manifest_number
waste_record_id optional
transporter_id
disposal_vendor_id
pickup_date
quantity
unit
manifest_file_id optional
receipt_file_id optional
verification_status
verified_by optional
verified_at optional
status
created_by
updated_by
created_at
updated_at
```

## Index Wajib

```text
company_id
site_id
status
monitoring_type
media_type
parameter_id
monitoring_point_id
sample_date
result_date
valid_until
renewal_due_date
manifest_number
exceedance_number
created_at
```
