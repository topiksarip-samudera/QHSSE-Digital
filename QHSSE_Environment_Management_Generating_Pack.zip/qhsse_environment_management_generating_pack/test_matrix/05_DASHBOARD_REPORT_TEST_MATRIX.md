# Dashboard & Report Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| DR-001 | Waste trend | Accurate |
| DR-002 | Hazardous waste stock | Accurate |
| DR-003 | Monitoring completion | Accurate |
| DR-004 | Exceedance count | Accurate |
| DR-005 | Permit expiring count | Accurate |
| DR-006 | Spill count | Accurate |
| DR-007 | Open environment actions | Accurate |
| DR-008 | Company A dashboard | No Company B data |
