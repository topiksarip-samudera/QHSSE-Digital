# Waste & Manifest Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| WM-001 | Create hazardous waste record | Success |
| WM-002 | Missing hazardous label | Warning/block based setting |
| WM-003 | Create manifest | Success |
| WM-004 | Upload manifest file | File stored securely |
| WM-005 | Verify manifest | Status verified |
| WM-006 | Manifest overdue | Notification sent |
| WM-007 | Waste transporter inactive | Warning/block |
| WM-008 | Export waste report | Scoped data only |
