# Permission & Tenant Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PERM-001 | User without environment.view opens dashboard | 403 / hidden UI |
| PERM-002 | User without env_monitoring.create creates result | 403 |
| PERM-003 | User without env_exceedance.close closes exceedance | 403 |
| PERM-004 | Site A user opens Site B result | 403/404 |
| PERM-005 | User without export exports report | 403 |
| PERM-006 | Export report | Audit log created |
| PERM-007 | Manifest file from other company | 403/404 |
| PERM-008 | Cross-company legal evidence link | Denied |
