# Monitoring & Exceedance Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| MON-001 | Result below limit | Compliant |
| MON-002 | Result above max limit | Exceedance detected |
| MON-003 | Result below min limit if min configured | Exceedance detected |
| MON-004 | Lab file missing when required | Validation error |
| MON-005 | Exceedance detected | Action can be created |
| MON-006 | Exceedance verified | Status verified/closed |
| MON-007 | Old limit changed | Result keeps limit snapshot |
| MON-008 | Cross-company monitoring point | Denied |
