# Environment Core Test Matrix

| ID | Area | Scenario | Expected |
|---|---|---|---|
| ENV-001 | Aspect | Create aspect-impact | Success |
| ENV-002 | Aspect | Calculate significance | Correct score |
| ENV-003 | Permit | Create environmental permit | Success |
| ENV-004 | Permit | Permit expiring | Notification/calendar event |
| ENV-005 | Waste | Create waste record | Success |
| ENV-006 | Manifest | Upload manifest | Verification pending |
| ENV-007 | Monitoring | Create monitoring schedule | Due date generated |
| ENV-008 | Monitoring | Upload result | Result stored |
