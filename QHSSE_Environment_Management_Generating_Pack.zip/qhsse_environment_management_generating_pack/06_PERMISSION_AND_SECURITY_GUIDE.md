# 06 — PERMISSION & SECURITY GUIDE

## Permission Groups

### Environment General

```text
environment.view
environment.view_all
environment.create
environment.update
environment.delete
environment.submit
environment.review
environment.approve
environment.close
environment.export
environment.manage_settings
```

### Waste

```text
env_waste.view
env_waste.create
env_waste.update
env_waste.verify
env_waste.export
```

### Monitoring

```text
env_monitoring.view
env_monitoring.create
env_monitoring.update
env_monitoring.review
env_monitoring.export
```

### Exceedance / Spill

```text
env_exceedance.view
env_exceedance.create
env_exceedance.assign_action
env_exceedance.verify
env_exceedance.close

env_spill.view
env_spill.create
env_spill.update
env_spill.close
```

## Scope

```text
Global
Company
Site
Project
Department
Location
Responsible Person
Reviewer
Approver
PIC
Evidence Owner
```

## Security Rules

- Semua query wajib filter company_id.
- User site scope hanya boleh melihat environment record di site terkait.
- File lab result, permit, manifest, dan evidence harus permission-guarded.
- Exceedance close butuh verification permission.
- Manifest verification butuh permission khusus.
- Export report harus audit logged.
- Environmental compliance decision penting harus human-reviewed.
- Cross-module link harus same-company only.
