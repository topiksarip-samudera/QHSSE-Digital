# 04 — API CONTRACT GUIDE

Gunakan prefix:

```text
/api/v1
```

## Aspect & Impact

```text
GET    /environment/aspects
POST   /environment/aspects
GET    /environment/aspects/:id
PATCH  /environment/aspects/:id
DELETE /environment/aspects/:id
POST   /environment/aspects/:id/submit
POST   /environment/aspects/:id/approve
POST   /environment/aspects/:id/review
```

## Environmental Permit

```text
GET    /environment/permits
POST   /environment/permits
GET    /environment/permits/:id
PATCH  /environment/permits/:id
DELETE /environment/permits/:id
POST   /environment/permits/:id/renew
POST   /environment/permits/:id/link-obligation
GET    /environment/permits/expiring
```

## Waste & Manifest

```text
GET    /environment/waste-records
POST   /environment/waste-records
GET    /environment/waste-records/:id
PATCH  /environment/waste-records/:id
POST   /environment/waste-records/:id/verify

GET    /environment/waste-manifests
POST   /environment/waste-manifests
GET    /environment/waste-manifests/:id
PATCH  /environment/waste-manifests/:id
POST   /environment/waste-manifests/:id/upload
POST   /environment/waste-manifests/:id/verify
```

## Monitoring

```text
GET    /environment/monitoring-points
POST   /environment/monitoring-points
PATCH  /environment/monitoring-points/:id

GET    /environment/parameters
POST   /environment/parameters
PATCH  /environment/parameters/:id

GET    /environment/limits
POST   /environment/limits
PATCH  /environment/limits/:id

GET    /environment/monitoring-schedules
POST   /environment/monitoring-schedules
PATCH  /environment/monitoring-schedules/:id

GET    /environment/monitoring-results
POST   /environment/monitoring-results
GET    /environment/monitoring-results/:id
PATCH  /environment/monitoring-results/:id
POST   /environment/monitoring-results/:id/review
POST   /environment/monitoring-results/:id/create-exceedance
```

## Exceedance, Spill, Incident

```text
GET    /environment/exceedances
POST   /environment/exceedances
GET    /environment/exceedances/:id
PATCH  /environment/exceedances/:id
POST   /environment/exceedances/:id/assign-action
POST   /environment/exceedances/:id/verify
POST   /environment/exceedances/:id/close

GET    /environment/spills
POST   /environment/spills
GET    /environment/spills/:id
PATCH  /environment/spills/:id
POST   /environment/spills/:id/create-incident
```

## Energy / Fuel / Chemical / Resource

```text
GET  /environment/energy-records
POST /environment/energy-records
GET  /environment/fuel-records
POST /environment/fuel-records
GET  /environment/chemical-records
POST /environment/chemical-records
GET  /environment/resource-records
POST /environment/resource-records
```

## Dashboard & Reports

```text
GET /environment/dashboard
GET /environment/kpi
GET /environment/exceedance-trend
GET /environment/waste-report
GET /environment/monitoring-report
GET /environment/permit-expiry-report
GET /environment/export
```

## Settings

```text
GET   /environment/settings
PATCH /environment/settings
GET   /environment/master-data
```

## Standard Query

```text
?page=1&pageSize=20&search=&siteId=&monitoringType=&mediaType=&status=&dateFrom=&dateTo=&sort=createdAt:desc
```
