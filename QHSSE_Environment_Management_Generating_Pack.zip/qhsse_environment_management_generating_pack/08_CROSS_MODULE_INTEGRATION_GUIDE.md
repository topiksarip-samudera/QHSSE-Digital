# 08 — CROSS-MODULE INTEGRATION GUIDE

## Legal & Compliance Register

```text
- Environmental permit can link to legal obligation.
- Monitoring parameter can use legal limit.
- Monitoring result can become evidence.
- Exceedance can create compliance gap.
- Waste manifest can become legal evidence.
```

## Audit & Inspection

```text
- Environmental inspection finding can create environment action.
- Audit can verify environmental compliance evidence.
- Failed inspection can create exceedance/finding link.
```

## Incident Management

```text
- Spill can create environmental incident.
- Major exceedance can create incident if configured.
- Incident investigation can link to environmental records.
```

## Action Tracking

```text
- Exceedance creates corrective action.
- Spill creates action.
- Manifest issue creates action.
- Permit expiry issue creates action.
```

## Document Control

```text
- SOP waste handling, spill response, monitoring method.
- Environmental permit documents.
- Lab reports and regulatory reports.
```

## Training & Competency

```text
- Waste handling training.
- Chemical handling training.
- Spill response training.
- Environmental awareness training.
```

## Asset & Equipment

```text
- Monitoring point linked to asset/equipment.
- WWTP equipment linked to monitoring.
- Emission source linked to asset.
- Flow meter/calibration link optional.
```

## Contractor Management

```text
- Waste transporter/vendor compliance.
- Disposal vendor document status.
- Contractor environmental performance.
```
