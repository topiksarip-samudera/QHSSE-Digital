# 00 — PROMPT AWAL ENVIRONMENT MANAGEMENT UNTUK AI AGENT

Core Platform sudah stabil. Incident Management, Risk Management, Audit & Inspection, Permit to Work, Document Control, Training & Competency, dan Legal & Compliance Register sudah selesai atau siap integrasi.

Sekarang mulai generate QHSSE Operational Module: **Environment Management**.

Baca seluruh file dalam folder `qhsse_environment_management_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_master_data.md`.
3. Gunakan core yang sudah ada:
   - Company / tenant
   - Site / project / department / location
   - Role & permission
   - Module ON/OFF
   - Master data
   - Workflow
   - Action tracking
   - Attachment/evidence
   - Audit log
   - Notification
   - Numbering
   - Calendar/schedule
   - Dashboard
   - API/webhook
4. Environment Management tidak boleh hanya menjadi tabel limbah.
5. Harus ada aspect-impact register.
6. Harus ada environmental permit dan compliance link.
7. Harus ada waste management dan limbah B3/manifest.
8. Harus ada environmental monitoring schedule.
9. Harus ada water, wastewater, emission, dan noise monitoring.
10. Harus ada exceedance management.
11. Harus ada spill/environmental incident.
12. Harus ada energy, fuel, chemical, dan resource monitoring.
13. Semua data wajib tenant-safe.
14. Semua API wajib permission-guarded.
15. Semua exceedance, spill, manifest, assessment, evidence update, dan export harus audit logged.
16. Setelah sequence selesai, tulis:
   `SELESAI ENVIRONMENT SEQUENCE XX: <nama sequence>`
17. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
