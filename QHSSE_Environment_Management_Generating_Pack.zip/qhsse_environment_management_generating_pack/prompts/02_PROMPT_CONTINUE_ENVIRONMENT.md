# Prompt Continue Environment Management Sequence

Continue Environment Management Sequence.

Kerjakan sequence berikutnya sesuai:

```text
sequence/00_ENVIRONMENT_SEQUENCE.md
```

Aturan:
- Jangan lompat sequence.
- Jangan lanjut sequence berikutnya setelah selesai.
- Pastikan database, backend, frontend, permission, audit log, dan test selesai.
- Jika sequence selesai, tulis:
  `SELESAI ENVIRONMENT SEQUENCE XX: <nama sequence>`
