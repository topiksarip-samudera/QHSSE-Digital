# Prompt Fix Environment Management

Review modul Environment Management yang terakhir dibuat.

Periksa:
- Tenant isolation
- Permission backend
- Aspect-impact scoring
- Environmental permit expiry
- Waste/manifest lifecycle
- Monitoring schedule
- Limit comparison
- Exceedance detection
- Spill workflow
- Action integration
- Legal evidence link
- Attachment security
- Dashboard calculation
- Report export
- Audit log
- Build/lint/test

Perbaiki semua bug P0/P1. Setelah selesai tulis:

```text
ENVIRONMENT MANAGEMENT FIXED
```
