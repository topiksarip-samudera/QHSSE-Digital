# Prompt Start Environment Management

Core Platform sudah stabil. Incident Management, Risk Management, Audit & Inspection, Permit to Work, Document Control, Training & Competency, dan Legal & Compliance Register sudah selesai atau siap integrasi.

Sekarang generate Environment Management berdasarkan `qhsse_environment_management_generating_pack`.

Mulai dari:

```text
sequence/01_foundation_master_data.md
```

Kerjakan sequence pertama saja.

Setelah selesai tulis:

```text
SELESAI ENVIRONMENT SEQUENCE 01: Foundation & Master Data
```

Jangan lanjut sequence berikutnya sebelum saya minta continue.
