# Prompt Release Gate Environment Management

Jalankan release gate Environment Management.

Cek:
- P0 = 0
- P1 = 0
- Tenant isolation PASS
- Permission backend PASS
- Aspect impact PASS
- Permit register PASS
- Waste management PASS
- Manifest workflow PASS
- Monitoring schedule PASS
- Limit comparison PASS
- Exceedance detection PASS
- Spill workflow PASS
- Action integration PASS
- Legal evidence link PASS
- Attachment security PASS
- Audit log PASS
- Dashboard calculation PASS
- Report export PASS
- Cross-module integration PASS
- Lint/test/build PASS

Jika lulus tulis:

```text
ENVIRONMENT MANAGEMENT STABILIZED: GO
```

Jika gagal tulis:

```text
ENVIRONMENT MANAGEMENT STABILIZED: NO-GO
```

Sertakan blocking issue.
