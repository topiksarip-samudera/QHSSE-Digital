# 01 Prompt Start Mobile Pwa

Mulai generate Mobile/PWA Field Optimization dari sequence/01_foundation_pwa_core_setup.md. Kerjakan sequence pertama saja. Setelah selesai tulis: SELESAI MOBILE PWA SEQUENCE 01: Foundation & PWA Core Setup.
