# 04 — API CONTRACT GUIDE

Gunakan prefix `/api/v1`.

## PWA & Device

```text
GET    /mobile-pwa/settings
PATCH  /mobile-pwa/settings
POST   /mobile-pwa/devices/register
GET    /mobile-pwa/devices
PATCH  /mobile-pwa/devices/:id
POST   /mobile-pwa/devices/:id/block
POST   /mobile-pwa/devices/:id/trust
```

## Offline & Sync

```text
GET    /mobile-pwa/offline-profile
POST   /mobile-pwa/offline-drafts
GET    /mobile-pwa/offline-drafts
PATCH  /mobile-pwa/offline-drafts/:id
DELETE /mobile-pwa/offline-drafts/:id
POST   /mobile-pwa/sync/push
POST   /mobile-pwa/sync/pull
POST   /mobile-pwa/sync/resolve-conflict
GET    /mobile-pwa/sync/logs
GET    /mobile-pwa/sync/conflicts
```

## Evidence, QR, GPS, Signature

```text
POST /mobile-pwa/evidence
GET  /mobile-pwa/evidence/:id
POST /mobile-pwa/qr/scan
POST /mobile-pwa/location/capture
POST /mobile-pwa/signatures
GET  /mobile-pwa/signatures/:id
```

## Field Workflow

```text
POST /mobile/incident/report
POST /mobile/inspection/execute
POST /mobile/permit/:id/approve
POST /mobile/permit/:id/verify-qr
POST /mobile/actions/:id/close
POST /mobile/assets/:id/verify
POST /mobile/documents/verify-qr
POST /mobile/contractors/verify-worker
POST /mobile/emergency/drill-attendance
```

## Push Notification

```text
POST /mobile-pwa/push/subscribe
DELETE /mobile-pwa/push/unsubscribe
GET /mobile-pwa/push/logs
POST /mobile-pwa/push/test
```
