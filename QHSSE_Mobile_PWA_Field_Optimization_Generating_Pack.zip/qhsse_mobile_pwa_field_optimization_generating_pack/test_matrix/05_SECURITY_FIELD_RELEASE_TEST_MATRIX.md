# 05 Security Field Release Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| MPWA-001 | Device block | PASS |
| MPWA-002 | Session revoke | PASS |
| MPWA-003 | Offline data limit | PASS |
| MPWA-004 | Tenant isolation | PASS |
| MPWA-005 | Push notification privacy | PASS |
| MPWA-006 | Mobile performance | PASS |
| MPWA-007 | Field test PASS | PASS |
| MPWA-008 | Release gate PASS | PASS |
