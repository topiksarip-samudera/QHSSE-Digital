# 02 Offline Sync Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| MPWA-001 | Create offline draft | PASS |
| MPWA-002 | Update offline draft | PASS |
| MPWA-003 | Queue sync while offline | PASS |
| MPWA-004 | Push sync success | PASS |
| MPWA-005 | Pull sync success | PASS |
| MPWA-006 | Retry failed sync | PASS |
| MPWA-007 | Conflict detected | PASS |
| MPWA-008 | Conflict resolved | PASS |
