# 03 Field Capture Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| MPWA-001 | Capture photo | PASS |
| MPWA-002 | Compress attachment | PASS |
| MPWA-003 | Capture GPS | PASS |
| MPWA-004 | Save signature | PASS |
| MPWA-005 | Scan QR permit | PASS |
| MPWA-006 | Scan QR asset | PASS |
| MPWA-007 | Scan QR document | PASS |
| MPWA-008 | Evidence permission check | PASS |
