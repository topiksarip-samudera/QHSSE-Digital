# Bug Register — Mobile/PWA Field Optimization

| Bug ID | Date | Sequence | Severity | Title | Steps | Expected | Actual | Status |
|---|---|---|---|---|---|---|---|---|
| MPWA-BUG-001 |  |  | P0/P1/P2/P3 |  |  |  |  | Open |
