# 00 — PROMPT AWAL MOBILE/PWA FIELD OPTIMIZATION UNTUK AI AGENT

Core Platform, QHSSE Operational Modules, Reports & Analytics, dan AI Assistant sudah selesai atau siap integrasi.

Modul yang harus dioptimalkan untuk mobile/field:

```text
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
```

Sekarang generate tahap **Mobile/PWA Field Optimization** berdasarkan folder `qhsse_mobile_pwa_field_optimization_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_pwa_core_setup.md`.
3. Mobile/PWA tidak boleh hanya responsive CSS.
4. Harus ada PWA manifest, service worker, app shell, install prompt, dan offline readiness.
5. Harus ada mobile-first layout dan field UX.
6. Harus ada offline storage, cache, queue, sync, dan conflict resolution.
7. Harus ada field form engine untuk mobile/offline.
8. Harus ada camera evidence dan attachment compression.
9. Harus ada QR/barcode scanner.
10. Harus ada GPS, signature, timestamp, dan audit trail.
11. Harus ada push notification dan mobile reminder.
12. Harus ada mobile workflow untuk incident, inspection, permit, action, asset, document, emergency, contractor.
13. Harus ada mobile security dan device control.
14. Semua data wajib tenant-safe dan permission-guarded.
15. Semua sync, evidence upload, QR scan, GPS, signature, device registration, dan export wajib audit logged.
16. Setelah sequence selesai, tulis:
   `SELESAI MOBILE PWA SEQUENCE XX: <nama sequence>`
17. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
