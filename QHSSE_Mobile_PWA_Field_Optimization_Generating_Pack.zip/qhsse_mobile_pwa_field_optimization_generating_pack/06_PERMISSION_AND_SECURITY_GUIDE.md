# 06 — PERMISSION & SECURITY GUIDE

## Security Rules

- Mobile API wajib tenant-safe.
- Offline profile hanya memuat data yang user boleh akses.
- Offline cache tidak boleh menyimpan data sensitif tanpa proteksi.
- QR scan harus verify permission backend.
- Device dapat diblock admin.
- Session mobile harus bisa revoked.
- Signature dan GPS harus audit logged.
- Evidence file harus permission-guarded.
- Push notification tidak boleh membocorkan data sensitif.
- Conflict resolution harus permission-aware.

## Device Control

```text
Register device
Trust device
Block device
Revoke session
Limit offline data
Limit attachment size
Limit sync retry
Force logout
```
