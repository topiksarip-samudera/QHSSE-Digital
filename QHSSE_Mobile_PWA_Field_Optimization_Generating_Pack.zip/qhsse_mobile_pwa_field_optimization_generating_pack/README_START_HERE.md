# START HERE — QHSSE Mobile/PWA Field Optimization Generating Pack

Paket ini dibuat untuk generate tahap **Mobile/PWA Field Optimization** pada WebApp QHSSE.

## Rekomendasi Split

Mobile/PWA Field Optimization sebaiknya di-split menjadi **12 sequence**.

```text
01 Foundation & PWA Core Setup
02 Mobile Layout, Navigation & Responsive UI
03 Offline Storage, Cache & Sync Engine
04 Mobile Field Form Engine
05 Camera, Evidence, Attachment & Compression
06 QR / Barcode Scanner & Field Verification
07 GPS, Location, Signature & Timestamp
08 Push Notification & Mobile Reminder
09 Mobile Incident, Inspection, Permit & Action Workflow
10 Mobile Asset, Document, Emergency & Contractor Field Use
11 Offline Queue, Conflict Resolution, Security & Device Control
12 QA, Field Test, Permission & Stabilization
```

## Kenapa 12 Sequence?

Tahap ini bukan membuat aplikasi mobile baru dari nol, tetapi mengoptimalkan WebApp QHSSE agar kuat dipakai di lapangan:

```text
PWA installable app
Mobile responsive UI
Offline data capture
Offline sync
Camera evidence
QR / barcode scan
GPS location
Digital signature
Push notification
Field workflow
Offline conflict resolution
Mobile security
Device control
Field QA
```

Jika dibuat terlalu sedikit sequence, biasanya offline sync, conflict resolution, device security, dan field QA tidak matang.

## Modul yang Harus Terintegrasi

```text
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
```

## Cara Pakai

1. Extract ZIP.
2. Baca `00_PROMPT_AWAL_MOBILE_PWA_FIELD_OPTIMIZATION.md`.
3. Baca `01_MOBILE_PWA_MASTER_BLUEPRINT.md`.
4. Baca `02_MOBILE_PWA_GENERATING_RULES.md`.
5. Mulai dari `sequence/01_foundation_pwa_core_setup.md`.
6. Kerjakan satu sequence saja.
7. Setelah selesai tulis status sequence.
8. Jangan lanjut sebelum diminta continue.

## Status Akhir

```text
MOBILE PWA FIELD OPTIMIZATION STABILIZED: GO
```
