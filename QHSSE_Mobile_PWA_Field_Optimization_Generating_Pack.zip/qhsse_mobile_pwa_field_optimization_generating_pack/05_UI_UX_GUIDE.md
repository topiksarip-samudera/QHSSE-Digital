# 05 — UI/UX GUIDE MOBILE/PWA

## Mobile Navigation

```text
Home
Tasks
Scan
Create
Notifications
Profile
```

## Field Home

```text
My Pending Approvals
My Open Actions
Quick Incident Report
Start Inspection
Scan QR
Offline Queue Status
Emergency Contact
```

## Components

```text
MobileShell
BottomNavigation
OfflineStatusBar
SyncStatusBadge
InstallPwaPrompt
MobileTaskCard
CameraCapture
EvidencePreview
QRScanner
GPSCaptureButton
SignaturePad
MobileFormBuilder
MobileChecklist
PushNotificationToggle
ConflictResolutionDialog
```

## UX Rules

- Button harus besar dan touch-friendly.
- Form harus bisa disimpan sebagai draft.
- Offline status harus selalu terlihat.
- Sync status harus jelas.
- Kamera dan QR scanner harus cepat diakses.
- Critical action seperti approve/reject tetap butuh confirmation.
- Semua error sync harus dapat dibaca user.
