# 03 — DATABASE MODEL GUIDE

## Tabel Minimal

```text
mobile_pwa_settings
mobile_devices
mobile_device_sessions
mobile_feature_toggles
mobile_offline_profiles
mobile_offline_drafts
mobile_offline_queue
mobile_sync_logs
mobile_sync_conflicts
mobile_evidence_captures
mobile_qr_scan_logs
mobile_location_captures
mobile_signatures
mobile_push_subscriptions
mobile_push_logs
mobile_field_forms
mobile_field_form_templates
mobile_field_form_submissions
mobile_app_audit_logs
```

## mobile_devices

```text
id
company_id
user_id
device_uid
device_name
device_type
os
browser
pwa_installed
last_seen_at
is_trusted
is_blocked
status
created_at
updated_at
```

## mobile_offline_drafts

```text
id
company_id
user_id
device_id
module_key
record_type
local_record_id
server_record_id optional
payload_json
status
created_at
updated_at
last_sync_attempt_at optional
```

## mobile_offline_queue

```text
id
company_id
user_id
device_id
queue_type
module_key
operation
endpoint
method
payload_json
retry_count
max_retry
status
error_message optional
created_at
updated_at
```

## mobile_sync_conflicts

```text
id
company_id
user_id
device_id
module_key
local_record_id
server_record_id
conflict_type
local_payload_json
server_payload_json
resolution_strategy
resolved_by optional
resolved_at optional
status
created_at
```

## mobile_evidence_captures

```text
id
company_id
user_id
device_id
module_key
record_id optional
file_id
file_type
original_size
compressed_size
gps_lat optional
gps_lng optional
captured_at
metadata_json
status
created_at
```

## mobile_qr_scan_logs

```text
id
company_id
user_id
device_id
qr_type
qr_value
module_key optional
record_id optional
scan_result
gps_lat optional
gps_lng optional
scanned_at
created_at
```
