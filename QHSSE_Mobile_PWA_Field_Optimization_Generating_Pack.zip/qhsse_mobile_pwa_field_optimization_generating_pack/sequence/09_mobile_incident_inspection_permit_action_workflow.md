# 09 Mobile Incident, Inspection, Permit & Action Workflow

## Tujuan

Mengoptimalkan workflow mobile untuk incident reporting, inspection checklist, PTW approval/verification, dan action close-out.

## Fokus

```text
mobile incident, inspection, permit, action workflow, field task execution
```

## Database Relevan

```text
mobile_pwa_settings
mobile_devices
mobile_device_sessions
mobile_feature_toggles
mobile_offline_profiles
mobile_offline_drafts
mobile_offline_queue
mobile_sync_logs
mobile_sync_conflicts
mobile_evidence_captures
mobile_qr_scan_logs
mobile_location_captures
mobile_signatures
mobile_push_subscriptions
mobile_push_logs
mobile_field_forms
mobile_field_form_templates
mobile_field_form_submissions
mobile_app_audit_logs
```

## API Pattern

```text
GET /api/v1/mobile-pwa/settings
POST /api/v1/mobile-pwa/devices/register
POST /api/v1/mobile-pwa/offline-drafts
POST /api/v1/mobile-pwa/sync/push
POST /api/v1/mobile-pwa/sync/pull
POST /api/v1/mobile-pwa/evidence
POST /api/v1/mobile-pwa/qr/scan
POST /api/v1/mobile-pwa/location/capture
POST /api/v1/mobile-pwa/signatures
POST /api/v1/mobile-pwa/push/subscribe
```

## Frontend Minimal

```text
Mobile page
Mobile layout
Offline status
Sync status
Create/edit form
Camera/QR/GPS/signature component jika relevan
Task card jika relevan
Conflict dialog jika relevan
```

## Testing Minimal

```text
Happy path
Validation error
Permission denied
Tenant isolation
Offline draft
Sync success/fail
Audit log created
Mobile responsive check
```

## Acceptance Criteria

- Mobile-first dan touch-friendly.
- Tenant-safe.
- Permission backend berjalan.
- Offline/sync berjalan sesuai sequence.
- Audit log tercatat.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI MOBILE PWA SEQUENCE 09: Mobile Incident, Inspection, Permit & Action Workflow
```
