# 02 — MOBILE/PWA GENERATING RULES

## Aturan Utama

1. Jangan hanya membuat responsive layout.
2. PWA harus punya manifest dan service worker.
3. Data field penting harus bisa dibuat sebagai offline draft.
4. Offline queue harus bisa retry.
5. Conflict resolution wajib ada untuk update data yang berubah saat offline.
6. Evidence foto/video harus dikompresi.
7. Evidence harus menyimpan metadata: time, user, GPS optional, module, record.
8. QR scan harus permission-aware.
9. GPS harus meminta consent user.
10. Signature harus disimpan sebagai evidence.
11. Push notification harus bisa ON/OFF per user.
12. Device/session harus bisa dikontrol admin.
13. Semua offline sync harus audit logged.
14. Semua API mobile wajib tenant-safe dan permission-guarded.

## Permission Standard

```text
mobile.view
mobile.install
mobile.offline_use
mobile.sync
mobile.capture_evidence
mobile.scan_qr
mobile.capture_gps
mobile.sign
mobile.receive_push
mobile.manage_device
mobile.manage_settings

mobile.incident.create
mobile.inspection.execute
mobile.permit.approve
mobile.permit.verify
mobile.action.close
mobile.asset.verify
mobile.document.view
mobile.contractor.verify
mobile.emergency.view
```

## Audit Log Wajib

```text
mobile.app.installed
mobile.offline_draft_created
mobile.offline_queue_created
mobile.sync_started
mobile.sync_completed
mobile.sync_failed
mobile.conflict_detected
mobile.conflict_resolved
mobile.evidence_captured
mobile.qr_scanned
mobile.gps_captured
mobile.signature_captured
mobile.push_sent
mobile.push_acknowledged
mobile.device_registered
mobile.device_blocked
```
