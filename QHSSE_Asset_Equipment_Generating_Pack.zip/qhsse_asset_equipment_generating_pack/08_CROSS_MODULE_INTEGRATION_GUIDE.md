# 08 — CROSS-MODULE INTEGRATION GUIDE

## Permit to Work

```text
Equipment validation before permit activation.
LOTO/isolation point selection.
Lifting gear, electrical panel, gas detector validation.
Out-of-service equipment blocks permit.
```

## Emergency Response

```text
Emergency equipment readiness.
Fire equipment inspection.
AED/hydrant/alarm readiness.
Equipment not ready affects emergency readiness score.
```

## Audit & Inspection

```text
Equipment inspection checklist.
Failed inspection creates finding/action.
Audit can verify critical equipment.
```

## Incident / Risk / Contractor / Training / Document / Legal

```text
Incident can link equipment involved.
Risk can link asset hazard and critical control.
Contractor equipment certificate validation.
Operator competency validation.
Manual, SOP, inspection checklist, certificates.
Statutory certificate and legal compliance evidence.
```
