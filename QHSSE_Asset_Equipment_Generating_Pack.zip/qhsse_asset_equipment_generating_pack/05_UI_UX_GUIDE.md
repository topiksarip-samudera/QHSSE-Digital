# 05 — UI/UX GUIDE ASSET & EQUIPMENT

## Sidebar

```text
Asset & Equipment
├── Overview
├── Asset Register
├── Equipment Register
├── Critical Equipment
├── Certificates
├── Inspection Schedule
├── Inspection Results
├── Maintenance
├── Calibration
├── LOTO / Isolation Points
├── QR Asset
├── Reports
└── Settings
```

## Asset Detail Tabs

```text
Overview
Specification
Location & Ownership
Criticality & Risk
Certificates
Inspection
Maintenance
Calibration
LOTO / Isolation
Linked Records
QR Asset
Attachments
Comments
Audit Trail
```

## Komponen Wajib

```text
AssetStatusBadge
CriticalityBadge
CertificateStatusBadge
InspectionDueBadge
MaintenanceDueBadge
CalibrationDueBadge
LotoPointTable
AssetQRCode
AssetTimeline
EquipmentReadinessCard
AssetLinkPanel
DueListPanel
```
