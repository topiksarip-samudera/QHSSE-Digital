# RELEASE_GATE_TEMPLATE.md

Gunakan template ini untuk mencatat QA, bug, dan release gate Asset & Equipment.

Final status: `ASSET EQUIPMENT STABILIZED: GO / NO-GO`.
