# Prompt Start Asset & Equipment

Core Platform sudah stabil. Emergency Response, Permit to Work, Incident Management, Risk Management, Audit & Inspection, Contractor Management, Training & Competency, Document Control, Legal & Compliance, dan Action Tracking sudah selesai atau siap integrasi.

Sekarang generate Asset & Equipment berdasarkan `qhsse_asset_equipment_generating_pack`.

Mulai dari `sequence/01_foundation_master_data.md`.

Kerjakan sequence pertama saja.

Setelah selesai tulis:

```text
SELESAI ASSET EQUIPMENT SEQUENCE 01: Foundation & Master Data
```

Jangan lanjut sequence berikutnya sebelum saya minta continue.
