# Prompt Fix Asset & Equipment

Review modul Asset & Equipment. Periksa tenant isolation, permission backend, asset register, certificate expiry, inspection, maintenance, calibration, LOTO, QR, dashboard, export, audit log, build/lint/test. Perbaiki semua P0/P1.
