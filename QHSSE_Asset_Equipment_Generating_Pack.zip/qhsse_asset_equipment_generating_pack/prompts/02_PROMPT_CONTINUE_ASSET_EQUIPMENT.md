# Prompt Continue Asset & Equipment Sequence

Continue Asset & Equipment Sequence.

Kerjakan sequence berikutnya sesuai `sequence/00_ASSET_EQUIPMENT_SEQUENCE.md`.

Jika sequence selesai, jangan lanjut sequence berikutnya. Berikan keterangan selesai.
