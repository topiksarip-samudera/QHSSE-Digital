# Prompt Release Gate Asset & Equipment

Jalankan release gate. Jika P0=0, P1=0, tenant isolation PASS, permission PASS, asset register PASS, certificate/inspection/maintenance/calibration/LOTO/QR/dashboard/export/audit log PASS, tulis:

```text
ASSET EQUIPMENT STABILIZED: GO
```
