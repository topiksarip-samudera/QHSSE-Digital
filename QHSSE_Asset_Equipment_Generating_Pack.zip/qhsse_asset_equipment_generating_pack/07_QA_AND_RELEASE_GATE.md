# 07 — QA AND RELEASE GATE

## QA Scope

```text
Tenant Isolation
Permission & Scope
Asset Register
Category / Type / Location
Criticality & Risk Classification
Certificate Register & Expiry
Inspection Schedule & Result
Maintenance Schedule & History
Calibration Control
LOTO / Isolation Point
QR Verification
Cross-Module Links
Dashboard Calculation
Report Export
Audit Log
Notification
Regression Test
```

## Release Gate

```text
P0 = 0
P1 = 0
Tenant isolation PASS
Permission backend PASS
Asset register PASS
Criticality classification PASS
Certificate expiry PASS
Inspection schedule/result PASS
Maintenance history PASS
Calibration control PASS
LOTO/isolation point PASS
QR verification PASS
Cross-module integration PASS
Dashboard calculation PASS
Report export PASS
Audit log PASS
Lint/test/build PASS
```

## Status Akhir

```text
ASSET EQUIPMENT STABILIZED: GO
```
