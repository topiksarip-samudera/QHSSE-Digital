# START HERE — QHSSE Asset & Equipment Generating Pack

Paket ini dibuat untuk menghasilkan modul **Asset & Equipment** pada WebApp QHSSE secara sequence, aman, dan terintegrasi.

## Rekomendasi Split

Modul **Asset & Equipment** sebaiknya di-split menjadi **12 sequence**.

```text
01 Foundation & Master Data
02 Asset & Equipment Register Core
03 Asset Category, Type, Location & Ownership
04 Critical Equipment & Risk Classification
05 Certificate Register & Expiry Management
06 Inspection Schedule & Inspection Result
07 Maintenance Schedule & Maintenance History
08 Calibration & Measuring Equipment Control
09 LOTO / Isolation Point & Energy Source
10 Integration with Permit, Incident, Audit, Risk, Emergency & Contractor
11 Dashboard, QR Asset, Report & Export
12 QA, Test, Permission & Stabilization
```

## Kenapa 12 Sequence?

Asset & Equipment bukan hanya daftar alat. Modul ini harus mengontrol asset ownership, critical equipment, inspection due, certificate expiry, calibration due, maintenance history, LOTO point, permit equipment validation, emergency readiness, incident history, audit finding, risk linkage, dan QR asset.

## Cara Pakai

1. Extract ZIP ke project.
2. Baca `00_PROMPT_AWAL_ASSET_EQUIPMENT.md`.
3. Baca `01_ASSET_EQUIPMENT_MASTER_BLUEPRINT.md`.
4. Mulai dari `sequence/01_foundation_master_data.md`.
5. Kerjakan satu sequence saja.
6. Setelah selesai tulis `SELESAI ASSET EQUIPMENT SEQUENCE XX`.
7. Jangan lanjut sequence berikutnya sebelum diminta.

## Status Akhir

```text
ASSET EQUIPMENT STABILIZED: GO
```
