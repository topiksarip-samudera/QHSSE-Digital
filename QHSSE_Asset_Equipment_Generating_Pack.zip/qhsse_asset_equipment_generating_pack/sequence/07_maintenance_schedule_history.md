# 07 — Maintenance Schedule & Maintenance History

## Tujuan

Maintenance schedule, preventive/corrective maintenance, work history, downtime, cost, due list.

## Fokus Sequence

```text
maintenance schedule, history, downtime, cost
```

## Scope Wajib

- Database schema/migration sesuai kebutuhan sequence.
- Backend DTO, validation, service, controller/API.
- Permission guard dan tenant guard.
- Audit log untuk semua critical action.
- Notification/action integration jika relevan.
- Frontend list/create/detail/edit/tab sesuai kebutuhan.
- Loading, empty, error state.
- Test minimal: happy path, validation, permission denied, tenant isolation, audit log.

## Database yang Mungkin Dibuat/Diubah

```text
asset_settings
asset_categories
equipment_types
asset_locations
assets
equipment
asset_ownerships
asset_criticality_levels
asset_risk_classifications
asset_certificates
asset_certificate_types
asset_inspection_schedules
asset_inspection_results
asset_maintenance_schedules
asset_maintenance_records
asset_calibration_schedules
asset_calibration_records
loto_points
isolation_points
energy_sources
asset_qr_codes
asset_links
asset_status_histories
```

## Acceptance Criteria

- Fitur sequence berjalan end-to-end.
- Data tenant-safe dengan company_id.
- Permission backend tidak bisa dibypass.
- UI permission-aware.
- Audit log tercatat.
- Due date/status/QR/eligibility berjalan jika relevan.
- Lint/test/build lulus.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI ASSET EQUIPMENT SEQUENCE 07: Maintenance Schedule & Maintenance History
```
