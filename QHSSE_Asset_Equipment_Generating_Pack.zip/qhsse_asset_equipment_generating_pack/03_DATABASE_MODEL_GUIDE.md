# 03 — DATABASE MODEL GUIDE

## Tabel Minimal

```text
asset_settings
asset_categories
equipment_types
asset_locations
assets
equipment
asset_ownerships
asset_criticality_levels
asset_risk_classifications
asset_certificates
asset_certificate_types
asset_inspection_schedules
asset_inspection_results
asset_inspection_items
asset_maintenance_schedules
asset_maintenance_records
asset_calibration_schedules
asset_calibration_records
measuring_equipment_controls
loto_points
isolation_points
energy_sources
asset_qr_codes
asset_links
asset_incident_links
asset_status_histories
asset_reports
```

## Field Umum Wajib

```text
id
company_id
site_id optional
department_id optional
location_id optional
created_by
updated_by
created_at
updated_at
deleted_at optional
status
```

## assets

```text
id
company_id
asset_number
asset_name
asset_category_id
equipment_type_id optional
description
site_id
department_id
location_id
owner_department_id
custodian_id optional
manufacturer optional
model optional
serial_number optional
purchase_date optional
commissioning_date optional
criticality_level_id optional
risk_classification_id optional
is_critical
is_statutory
is_emergency_equipment
is_calibration_required
is_loto_applicable
qr_code_id optional
current_status
created_by
updated_by
created_at
updated_at
deleted_at
```

## asset_certificates

```text
asset_id
certificate_type_id
certificate_number
issued_by
issue_date
expiry_date
file_id optional
verification_status
verified_by optional
verified_at optional
status
```

## asset_inspection_results

```text
asset_id
schedule_id optional
inspection_number
inspection_date
inspected_by
result
score optional
finding_created
action_id optional
remarks
file_id optional
status
```

## loto_points

```text
asset_id
point_code
energy_source_id
isolation_method
lock_required
tag_required
verification_required
description
location_detail
status
```
