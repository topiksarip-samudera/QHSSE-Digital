# 06 — PERMISSION & SECURITY GUIDE

## Scope

```text
Global
Company
Site
Project
Department
Owner Department
Custodian
Inspector
Maintainer
Calibrator
Permit Issuer
HSE
Asset Admin
```

## Security Rules

- Semua query wajib filter company_id.
- User site scope hanya melihat asset di sitenya.
- Certificate file download harus permission-guarded.
- Status change out_of_service hanya role berwenang.
- LOTO point change harus permission khusus.
- QR verification tidak boleh membuka data sensitif tanpa auth.
- Export asset data wajib audit log.
- Maintenance/calibration verification harus backend guarded.
