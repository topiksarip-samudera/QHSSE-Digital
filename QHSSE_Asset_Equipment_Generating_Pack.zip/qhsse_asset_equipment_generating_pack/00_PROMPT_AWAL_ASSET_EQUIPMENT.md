# 00 — PROMPT AWAL ASSET & EQUIPMENT UNTUK AI AGENT

Core Platform sudah stabil. Emergency Response, Permit to Work, Incident Management, Risk Management, Audit & Inspection, Contractor Management, Training & Competency, Document Control, Legal & Compliance, dan Action Tracking sudah selesai atau siap integrasi.

Sekarang mulai generate QHSSE Operational Module: **Asset & Equipment**.

Baca seluruh file dalam folder `qhsse_asset_equipment_generating_pack`.

Aturan wajib:
1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_master_data.md`.
3. Gunakan core: tenant, site/project/department/location, role permission, module ON/OFF, master data, workflow, action tracking, attachment, audit log, notification, calendar/schedule, numbering, checklist builder, QR, dashboard, API/webhook.
4. Asset & Equipment tidak boleh hanya menjadi daftar alat.
5. Harus ada asset/equipment register, critical equipment, certificate expiry, inspection, maintenance, calibration, LOTO/isolation point, QR asset, dashboard.
6. Semua data wajib tenant-safe dan semua API wajib permission-guarded.
7. Semua certificate, inspection, maintenance, calibration, LOTO, QR verification, status change, dan export harus audit logged.
8. Setelah sequence selesai, tulis `SELESAI ASSET EQUIPMENT SEQUENCE XX: <nama sequence>`.
9. Jangan lanjut sequence berikutnya sebelum user meminta continue.
