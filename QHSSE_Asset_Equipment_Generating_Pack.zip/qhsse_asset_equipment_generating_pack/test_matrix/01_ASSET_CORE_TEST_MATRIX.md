# 01_ASSET_CORE_TEST_MATRIX.md

| ID | Scenario | Expected |
|---|---|---|
| T-001 | Asset create/edit/detail, status change, archive, tenant isolation, permission denied. | PASS |
