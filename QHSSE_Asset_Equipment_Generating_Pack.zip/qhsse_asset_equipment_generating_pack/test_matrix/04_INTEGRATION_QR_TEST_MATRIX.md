# 04_INTEGRATION_QR_TEST_MATRIX.md

| ID | Scenario | Expected |
|---|---|---|
| T-001 | PTW block out-of-service equipment, emergency readiness, incident/audit/risk link, QR scan. | PASS |
