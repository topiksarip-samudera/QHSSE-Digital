# 02_CERTIFICATE_INSPECTION_TEST_MATRIX.md

| ID | Scenario | Expected |
|---|---|---|
| T-001 | Certificate add/verify/expiry, inspection schedule/result/finding/overdue. | PASS |
