# 05_DASHBOARD_REPORT_TEST_MATRIX.md

| ID | Scenario | Expected |
|---|---|---|
| T-001 | KPI total assets, critical equipment, overdue inspection, expired certificate, calibration due, export scoped data. | PASS |
