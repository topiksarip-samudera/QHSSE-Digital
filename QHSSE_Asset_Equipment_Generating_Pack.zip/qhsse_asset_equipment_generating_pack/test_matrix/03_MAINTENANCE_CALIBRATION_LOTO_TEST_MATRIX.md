# 03_MAINTENANCE_CALIBRATION_LOTO_TEST_MATRIX.md

| ID | Scenario | Expected |
|---|---|---|
| T-001 | Maintenance schedule/close, calibration pass/fail/overdue, LOTO point create/verify/PTW use. | PASS |
