# 01 — MASTER BLUEPRINT ASSET & EQUIPMENT

## Tujuan Modul

Modul **Asset & Equipment** digunakan untuk mengelola aset dan equipment QHSSE dari register, category, location, ownership, criticality, certificate, inspection, maintenance, calibration, LOTO/isolation point, QR asset, risk link, incident history, permit validation, emergency readiness, sampai dashboard.

## Prinsip Desain

1. Asset & Equipment bukan master data alat biasa.
2. Setiap asset/equipment harus punya lifecycle dan status.
3. Critical equipment harus bisa diklasifikasikan.
4. Certificate dan expiry harus bisa dikelola.
5. Inspection schedule harus bisa recurring.
6. Inspection result harus bisa membuat finding/action.
7. Maintenance history harus terdokumentasi.
8. Calibration harus mengontrol measuring equipment.
9. LOTO/isolation point harus bisa dipakai Permit to Work.
10. QR asset harus bisa dipakai untuk field verification.
11. Equipment status harus memengaruhi permit eligibility jika relevan.
12. Emergency equipment readiness harus memengaruhi Emergency Response.

## Jenis Asset / Equipment

```text
Emergency Equipment
Fire Extinguisher / APAR
Fire Hydrant
Fire Alarm
AED
Rescue Equipment
Vehicle
Heavy Equipment
Lifting Gear
Crane
Forklift
Scaffolding
Ladder
Electrical Panel
Generator
Compressor
Pressure Vessel
Pump
Gas Detector
Monitoring Equipment
Measuring Equipment
Calibration Equipment
Machine
LOTO Point
Isolation Point
Environmental Equipment
WWTP Equipment
Security Equipment
PPE Equipment
```

## Status Asset / Equipment

```text
draft
active
in_use
available
under_inspection
inspection_due
inspection_overdue
under_maintenance
maintenance_due
maintenance_overdue
calibration_due
calibration_overdue
certificate_expiring
certificate_expired
out_of_service
disposed
archived
```

## Output Utama

```text
Asset Register
Equipment Register
Critical Equipment Register
Certificate Expiry List
Inspection Due List
Inspection Result Report
Maintenance Due List
Maintenance History
Calibration Due List
Calibration Certificate Register
LOTO Point Register
Isolation Point Register
QR Asset Label
Equipment Status Board
Asset Risk Link
Equipment Incident History
Asset Dashboard
Asset Report Export
```
