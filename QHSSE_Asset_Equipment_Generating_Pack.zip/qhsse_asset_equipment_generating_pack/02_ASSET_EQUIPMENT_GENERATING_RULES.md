# 02 — ASSET & EQUIPMENT GENERATING RULES

## Aturan Utama

1. Jangan membuat Asset & Equipment sebagai master data alat biasa.
2. Asset/equipment harus punya status lifecycle.
3. Asset category, type, location, ownership harus configurable.
4. Critical equipment harus bisa ditandai dan diberi criticality.
5. Certificate expiry harus punya warning/notification.
6. Inspection schedule harus bisa recurring.
7. Inspection result harus bisa membuat finding/action.
8. Maintenance schedule dan history harus terdokumentasi.
9. Calibration harus punya due date, result, certificate, dan status.
10. LOTO/isolation point harus bisa dipakai oleh Permit to Work.
11. QR asset harus bisa verify asset status di lapangan.
12. Semua critical changes wajib audit log.
13. Semua data wajib tenant-safe.
14. Semua API wajib permission-guarded.

## Permission Standard

```text
asset.view
asset.view_all
asset.create
asset.update
asset.delete
asset.archive
asset.export
asset.manage_settings
equipment.view
equipment.create
equipment.update
equipment.delete
equipment.inspect
equipment.maintain
equipment.calibrate
equipment.change_status
equipment.export
asset_certificate.view
asset_certificate.create
asset_certificate.update
asset_certificate.verify
asset_inspection.view
asset_inspection.create
asset_inspection.verify
asset_inspection.close
asset_maintenance.view
asset_maintenance.create
asset_maintenance.close
asset_calibration.view
asset_calibration.create
asset_calibration.verify
loto_point.view
loto_point.create
loto_point.update
loto_point.verify
asset_qr.generate
asset_qr.verify
```

## Audit Log Wajib

```text
asset.created
asset.updated
asset.status_changed
asset.archived
equipment.created
equipment.updated
equipment.status_changed
certificate.created
certificate.verified
certificate.expired
inspection.scheduled
inspection.completed
inspection.failed
maintenance.scheduled
maintenance.completed
calibration.scheduled
calibration.completed
calibration.failed
loto_point.created
loto_point.updated
qr.verified
report.exported
settings.changed
```
