# 04 — API CONTRACT GUIDE

Gunakan prefix `/api/v1`.

## Asset & Equipment Core

```text
GET    /assets
POST   /assets
GET    /assets/:id
PATCH  /assets/:id
DELETE /assets/:id
POST   /assets/:id/archive
POST   /assets/:id/change-status
GET    /assets/:id/status-history
GET    /equipment
POST   /equipment
GET    /equipment/:id
PATCH  /equipment/:id
DELETE /equipment/:id
```

## Certificates

```text
GET  /assets/:id/certificates
POST /assets/:id/certificates
GET  /asset-certificates/:certificateId
PATCH /asset-certificates/:certificateId
POST /asset-certificates/:certificateId/verify
GET  /asset-certificates/expiring
GET  /asset-certificates/expired
```

## Inspection / Maintenance / Calibration

```text
GET  /assets/:id/inspection-schedules
POST /assets/:id/inspection-schedules
POST /asset-inspections
POST /asset-inspections/:id/complete
POST /asset-inspections/:id/create-finding
GET  /assets/:id/maintenance-schedules
POST /asset-maintenance-records
POST /asset-maintenance-records/:id/close
GET  /assets/:id/calibration-schedules
POST /asset-calibrations
POST /asset-calibrations/:id/verify
GET  /asset-calibrations/due
GET  /asset-calibrations/overdue
```

## LOTO / QR / Reports

```text
GET  /assets/:id/loto-points
POST /assets/:id/loto-points
POST /loto-points/:id/verify
GET  /assets/:id/qr
POST /assets/qr/verify
GET  /asset-equipment/dashboard
GET  /asset-equipment/kpi
GET  /asset-equipment/due-list
GET  /asset-equipment/export
```
