# Contractor Management Sequence

Kerjakan sequence berikut secara berurutan:

```text
01 Foundation & Master Data
02 Contractor Register & Profile
03 Prequalification & Approval Workflow
04 Contractor Document Submission & Review
05 Contractor Worker Register
06 Worker Competency, Training & Certificate Validation
07 Contractor Equipment & Asset Register
08 Contractor Permit, Security Access & Gate Pass Integration
09 Contractor Audit, Inspection, Incident & Performance
10 Suspension, Watchlist, Blacklist & Corrective Action
11 Dashboard, KPI, Report & Export
12 QA, Test, Permission & Stabilization
```

## Prompt Continue

```text
Continue Contractor Management Sequence. Kerjakan sequence berikutnya sesuai sequence/00_CONTRACTOR_SEQUENCE.md. Jika sequence selesai, jangan lanjut sequence berikutnya. Berikan keterangan selesai.
```

## Status Akhir

```text
CONTRACTOR MANAGEMENT STABILIZED: GO
```
