# 02 — Contractor Register & Profile

## Tujuan

Membangun contractor register, profile perusahaan, legal identity, contact, scope of work, risk category, dan tenant-safe CRUD.

## Scope

Sequence ini harus menghasilkan database, backend API, frontend UI, permission, audit log, test minimal, dan acceptance criteria.

## Fokus Sequence

```text
contractor register, profile, legal identity, contact, scope of work, risk category, status lifecycle
```

## Database yang Mungkin Dibuat/Diubah

```text
contractor_settings
contractor_types
contractor_categories
contractor_risk_categories
contractors
contractor_profiles
contractor_contacts
contractor_prequalifications
contractor_prequalification_items
contractor_document_requirements
contractor_documents
contractor_document_reviews
contractor_workers
contractor_worker_certificates
contractor_worker_trainings
contractor_worker_competency_checks
contractor_equipment
contractor_equipment_certificates
contractor_equipment_inspections
contractor_permit_eligibility_checks
contractor_security_access_links
contractor_audits
contractor_incident_links
contractor_performance_scores
contractor_status_histories
contractor_suspensions
contractor_watchlists
contractor_blacklists
contractor_links
```

Gunakan hanya tabel yang relevan untuk sequence ini. Jangan duplikasi tabel core yang sudah ada.

## API Pattern

```text
GET /api/v1/contractors
POST /api/v1/contractors
GET /api/v1/contractors/:id
PATCH /api/v1/contractors/:id
POST /api/v1/contractors/:id/approve
POST /api/v1/contractors/:id/suspend
POST /api/v1/contractors/:id/blacklist
GET /api/v1/contractors/:id/documents
GET /api/v1/contractors/:id/workers
GET /api/v1/contractors/:id/equipment
```

Tambahkan endpoint khusus sesuai sequence.

## Frontend Minimal

```text
List page
Create/update form
Detail page
Status badge
Filter/search
Compliance panel jika relevan
Eligibility panel jika relevan
Action panel jika relevan
Workflow tab jika relevan
Attachment tab jika relevan
Comment tab jika relevan
Audit trail tab jika relevan
```

## Permission

Tambahkan permission sesuai kebutuhan sequence dan pastikan backend guard aktif.

## Audit Log

Catat create/update/delete/submit/review/approve/reject/suspend/reactivate/watchlist/blacklist/document review/worker validation/equipment validation/export sesuai sequence.

## Testing Minimal

```text
Happy path
Validation error
Permission denied
Tenant isolation
Audit log created
Status transition
Eligibility validation jika relevan
```

## Acceptance Criteria

- Fitur sequence berjalan end-to-end.
- Tenant-safe.
- Permission backend berjalan.
- UI tidak menampilkan tombol tanpa permission.
- Audit log tercatat.
- Eligibility result diproses backend.
- Test minimal lulus.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI CONTRACTOR SEQUENCE 02: Contractor Register & Profile
```
