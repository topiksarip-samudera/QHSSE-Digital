# 06 — PERMISSION & SECURITY GUIDE

## Permission Groups

```text
contractor.view
contractor.view_all
contractor.create
contractor.update
contractor.delete
contractor.review
contractor.approve
contractor.reject
contractor.suspend
contractor.reactivate
contractor.watchlist
contractor.blacklist
contractor.export
contractor.manage_settings

contractor_document.view
contractor_document.submit
contractor_document.review
contractor_document.approve
contractor_document.reject
contractor_document.waive

contractor_worker.view
contractor_worker.create
contractor_worker.update
contractor_worker.validate_competency
contractor_worker.approve_site_access
contractor_worker.block

contractor_equipment.view
contractor_equipment.create
contractor_equipment.update
contractor_equipment.validate_certificate
contractor_equipment.block

contractor_performance.view
contractor_performance.recalculate
```

## Scope

```text
Global
Company
Site
Project
Department
Contractor Owner
Contractor Contact
Reviewer
Approver
HSE Reviewer
Security Reviewer
Permit Issuer
```

## Security Rules

- Semua query wajib filter company_id.
- Contractor contact hanya dapat melihat contractor miliknya jika external portal diaktifkan.
- User site scope hanya dapat melihat contractor yang aktif di sitenya.
- Document download harus permission-guarded.
- Worker personal data harus minim dan permission-aware.
- Blacklist/suspension wajib approval permission.
- Contractor eligibility result tidak boleh dimanipulasi dari frontend.
- Export contractor data wajib audit log.
