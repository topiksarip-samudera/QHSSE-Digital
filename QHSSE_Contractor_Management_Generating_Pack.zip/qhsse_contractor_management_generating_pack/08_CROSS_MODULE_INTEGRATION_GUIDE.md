# 08 — CROSS-MODULE INTEGRATION GUIDE

## Security Management

```text
- Contractor visitor, gate pass, vehicle access, and badge.
- Security access blocked if contractor suspended or blacklisted.
- Contractor worker site access approval.
```

## Permit to Work

```text
- Contractor must be active/approved before permit activation.
- Contractor worker certificate validation.
- Contractor equipment certificate validation.
- Contractor permit history affects performance.
```

## Training & Competency

```text
- Worker training/certificate validation.
- Training gap affects permit eligibility.
- Expired certificate notification.
```

## Document Control

```text
- Contractor documents, HSE plan, insurance, licenses.
- Contractor acknowledgement of site SOP/policy.
- Document expiry affects compliance.
```

## Audit & Inspection

```text
- Contractor audit and finding.
- Audit score affects performance score.
- Finding can create corrective action.
```

## Incident Management

```text
- Contractor incident history.
- Severe contractor incident can trigger suspension/watchlist.
- Incident count affects performance score.
```

## Risk Management

```text
- Contractor risk category.
- High risk contractor needs additional approval.
- Contractor risk review from repeated incident/finding.
```

## Asset & Equipment

```text
- Contractor equipment register.
- Equipment certificate/inspection/calibration validation.
```

## Legal & Compliance

```text
- Contractor legal document compliance.
- Legal obligations related to contractors can become document requirements.
```
