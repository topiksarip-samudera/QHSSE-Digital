# 00 — PROMPT AWAL CONTRACTOR MANAGEMENT UNTUK AI AGENT

Core Platform sudah stabil. Security Management, Permit to Work, Training & Competency, Document Control, Audit & Inspection, Incident Management, Risk Management, Legal & Compliance, dan Asset & Equipment sudah selesai atau siap integrasi.

Sekarang mulai generate QHSSE Operational Module: **Contractor Management**.

Baca seluruh file dalam folder `qhsse_contractor_management_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_master_data.md`.
3. Gunakan core yang sudah ada:
   - Company / tenant
   - Site / project / department / location
   - Role & permission
   - Module ON/OFF
   - Master data
   - Workflow
   - Action tracking
   - Attachment/evidence
   - Audit log
   - Notification
   - Numbering
   - Dashboard
   - API/webhook
4. Contractor Management tidak boleh hanya menjadi daftar vendor.
5. Harus ada prequalification.
6. Harus ada document submission dan review.
7. Harus ada worker register.
8. Harus ada worker competency dan certificate validation.
9. Harus ada equipment register dan certificate validation.
10. Harus ada integration ke Permit to Work dan Security Access.
11. Harus ada contractor audit, incident history, dan performance score.
12. Harus ada suspension, watchlist, blacklist, dan reactivation workflow.
13. Semua data wajib tenant-safe.
14. Semua API wajib permission-guarded.
15. Semua approval, rejection, suspension, blacklist, document verification, dan export harus audit logged.
16. Setelah sequence selesai, tulis:
   `SELESAI CONTRACTOR SEQUENCE XX: <nama sequence>`
17. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
