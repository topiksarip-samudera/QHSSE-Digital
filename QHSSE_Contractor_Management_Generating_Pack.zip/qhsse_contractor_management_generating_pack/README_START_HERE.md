# START HERE — QHSSE Contractor Management Generating Pack

Tanggal: 2026-06-22

Paket ini dibuat untuk menghasilkan modul **Contractor Management** pada WebApp QHSSE secara sequence, aman, dan terintegrasi.

## Posisi Modul dalam Roadmap

```text
Core Platform
→ Stabilization & QA
→ Incident Management
→ Risk Management / HIRADC / JSA
→ Audit & Inspection
→ Permit to Work
→ Document Control
→ Training & Competency
→ Legal & Compliance Register
→ Environment Management
→ Quality Management
→ Security Management
→ Contractor Management
→ Emergency Response
→ Asset & Equipment
```

## Rekomendasi Split

Modul **Contractor Management** sebaiknya di-split menjadi **12 sequence**.

```text
01 Foundation & Master Data
02 Contractor Register & Profile
03 Prequalification & Approval Workflow
04 Contractor Document Submission & Review
05 Contractor Worker Register
06 Worker Competency, Training & Certificate Validation
07 Contractor Equipment & Asset Register
08 Contractor Permit, Security Access & Gate Pass Integration
09 Contractor Audit, Inspection, Incident & Performance
10 Suspension, Watchlist, Blacklist & Corrective Action
11 Dashboard, KPI, Report & Export
12 QA, Test, Permission & Stabilization
```

## Kenapa 12 Sequence?

Contractor Management bukan hanya daftar vendor. Modul ini harus mengontrol:

```text
Legalitas contractor
Dokumen perusahaan
Prequalification
Worker competency
Training certificate
Equipment certificate
Permit eligibility
Security access
Audit score
Incident history
Performance score
Suspension / blacklist / watchlist
```

Jika digenerate sekaligus, hasilnya biasanya hanya menjadi master data vendor. Dengan 12 sequence, modul akan menjadi contractor control system yang terhubung ke PTW, Security, Training, Audit, Incident, Document, Asset, Legal, dan Risk.

## Cara Pakai

1. Extract ZIP ke project.
2. Baca `00_PROMPT_AWAL_CONTRACTOR_MANAGEMENT.md`.
3. Baca `01_CONTRACTOR_MANAGEMENT_MASTER_BLUEPRINT.md`.
4. Baca `02_CONTRACTOR_MANAGEMENT_GENERATING_RULES.md`.
5. Mulai dari `sequence/01_foundation_master_data.md`.
6. Selesaikan satu sequence.
7. Setelah selesai, AI Agent harus menulis `SELESAI CONTRACTOR SEQUENCE XX`.
8. Jangan lanjut sequence berikutnya sebelum diminta.

## Status Akhir

Setelah sequence 12 selesai:

```text
CONTRACTOR MANAGEMENT STABILIZED: GO
```
