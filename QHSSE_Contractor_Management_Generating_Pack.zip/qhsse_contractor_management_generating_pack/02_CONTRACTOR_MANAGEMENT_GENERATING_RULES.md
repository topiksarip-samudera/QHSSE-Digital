# 02 — CONTRACTOR MANAGEMENT GENERATING RULES

## Aturan Utama

1. Jangan membuat Contractor Management sebagai master vendor biasa.
2. Contractor harus punya status lifecycle.
3. Prequalification harus workflow-driven.
4. Document requirement harus configurable by contractor type/risk category/scope.
5. Document expiry harus punya notification dan compliance status.
6. Worker contractor harus dapat divalidasi training/certificate/medical optional.
7. Equipment contractor harus dapat divalidasi certificate/inspection/calibration.
8. Contractor eligibility harus bisa dipakai oleh PTW dan Security.
9. Performance score harus dihitung dari audit, incident, finding, action, document, certificate, permit, dan compliance.
10. Suspension, watchlist, blacklist harus approval-driven.
11. Semua critical decision wajib audit log.
12. Semua data wajib tenant-safe.
13. Semua API wajib permission-guarded.

## Permission Standard

```text
contractor.view
contractor.view_all
contractor.create
contractor.update
contractor.delete
contractor.submit_prequalification
contractor.review
contractor.approve
contractor.reject
contractor.suspend
contractor.reactivate
contractor.blacklist
contractor.export
contractor.manage_settings

contractor_document.view
contractor_document.submit
contractor_document.review
contractor_document.approve
contractor_document.reject
contractor_document.waive

contractor_worker.view
contractor_worker.create
contractor_worker.update
contractor_worker.validate_competency
contractor_worker.block

contractor_equipment.view
contractor_equipment.create
contractor_equipment.update
contractor_equipment.validate_certificate
contractor_equipment.block

contractor_performance.view
contractor_performance.recalculate
```

## Audit Log Wajib

```text
contractor.created
contractor.updated
contractor.submitted
contractor.approved
contractor.rejected
contractor.suspended
contractor.reactivated
contractor.watchlisted
contractor.blacklisted
document.submitted
document.approved
document.rejected
document.waived
worker.created
worker.updated
worker.blocked
worker.validated
equipment.created
equipment.updated
equipment.blocked
equipment.validated
performance.recalculated
report.exported
settings.changed
```

## Webhook Events

```text
contractor.created
contractor.approved
contractor.suspended
contractor.blacklisted
contractor.document_expiring
contractor.document_expired
contractor.worker_certificate_expiring
contractor.worker_certificate_expired
contractor.equipment_certificate_expired
contractor.performance_low
contractor.eligibility_blocked
```
