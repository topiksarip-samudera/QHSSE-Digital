# Bug Register — Contractor Management

| Bug ID | Date | Sequence | Severity | Title | Steps | Expected | Actual | Status | Fixed In |
|---|---|---|---|---|---|---|---|---|---|
| CON-BUG-001 |  |  | P0/P1/P2/P3 |  |  |  |  | Open/In Progress/Fixed/Closed |  |
