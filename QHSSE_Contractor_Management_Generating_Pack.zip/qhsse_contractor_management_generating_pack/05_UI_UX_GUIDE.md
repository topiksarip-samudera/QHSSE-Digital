# 05 — UI/UX GUIDE CONTRACTOR MANAGEMENT

## Sidebar

```text
Contractor Management
├── Overview
├── Contractor Register
├── Prequalification
├── Document Review
├── Worker Register
├── Worker Certificates
├── Equipment Register
├── Equipment Certificates
├── Permit Eligibility
├── Security Access
├── Contractor Audit
├── Performance
├── Watchlist / Blacklist
├── Reports
└── Settings
```

## Contractor Detail Tabs

```text
Overview
Profile
Prequalification
Documents
Workers
Worker Certificates
Equipment
Equipment Certificates
Permit Eligibility
Security Access
Audits & Inspections
Incidents
Actions
Performance
Status History
Attachments
Comments
Audit Trail
```

## Create Contractor Wizard

```text
Step 1: Company Profile
Step 2: Scope of Work
Step 3: Risk Category
Step 4: Document Requirements
Step 5: Contacts
Step 6: Review & Submit
```

## Komponen Wajib

```text
ContractorStatusBadge
ContractorRiskBadge
DocumentComplianceBadge
WorkerComplianceBadge
EquipmentComplianceBadge
PerformanceScoreCard
PrequalificationChecklist
DocumentReviewPanel
WorkerCertificateTable
EquipmentCertificateTable
EligibilityResultPanel
WatchlistBlacklistPanel
ContractorTimeline
```

## UX Penting

- Status contractor harus jelas.
- Expired/expiring document harus mudah terlihat.
- Worker certificate gap harus mudah difilter.
- Equipment certificate gap harus mudah difilter.
- Permit eligibility harus menunjukkan alasan block/warning.
- Security access harus menunjukkan apakah contractor boleh masuk site.
- Performance score harus transparan dan bisa drill down.
