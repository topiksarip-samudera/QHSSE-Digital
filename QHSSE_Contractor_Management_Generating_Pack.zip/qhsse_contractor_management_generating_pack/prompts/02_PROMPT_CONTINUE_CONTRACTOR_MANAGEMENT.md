# Prompt Continue Contractor Management Sequence

Continue Contractor Management Sequence.

Kerjakan sequence berikutnya sesuai:

```text
sequence/00_CONTRACTOR_SEQUENCE.md
```

Aturan:
- Jangan lompat sequence.
- Jangan lanjut sequence berikutnya setelah selesai.
- Pastikan database, backend, frontend, permission, audit log, dan test selesai.
- Jika sequence selesai, tulis:
  `SELESAI CONTRACTOR SEQUENCE XX: <nama sequence>`
