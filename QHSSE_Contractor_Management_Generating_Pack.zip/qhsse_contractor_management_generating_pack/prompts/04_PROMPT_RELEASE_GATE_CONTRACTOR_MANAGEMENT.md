# Prompt Release Gate Contractor Management

Jalankan release gate Contractor Management.

Cek:
- P0 = 0
- P1 = 0
- Tenant isolation PASS
- Permission backend PASS
- Contractor register PASS
- Prequalification workflow PASS
- Document review PASS
- Worker validation PASS
- Equipment validation PASS
- Permit eligibility PASS
- Security access eligibility PASS
- Performance scoring PASS
- Suspension/blacklist workflow PASS
- Audit log PASS
- Dashboard calculation PASS
- Report export PASS
- Cross-module integration PASS
- Lint/test/build PASS

Jika lulus tulis:

```text
CONTRACTOR MANAGEMENT STABILIZED: GO
```

Jika gagal tulis:

```text
CONTRACTOR MANAGEMENT STABILIZED: NO-GO
```

Sertakan blocking issue.
