# Prompt Start Contractor Management

Core Platform sudah stabil. Security Management, Permit to Work, Training & Competency, Document Control, Audit & Inspection, Incident Management, Risk Management, Legal & Compliance, dan Asset & Equipment sudah selesai atau siap integrasi.

Sekarang generate Contractor Management berdasarkan `qhsse_contractor_management_generating_pack`.

Mulai dari:

```text
sequence/01_foundation_master_data.md
```

Kerjakan sequence pertama saja.

Setelah selesai tulis:

```text
SELESAI CONTRACTOR SEQUENCE 01: Foundation & Master Data
```

Jangan lanjut sequence berikutnya sebelum saya minta continue.
