# Prompt Fix Contractor Management

Review modul Contractor Management yang terakhir dibuat.

Periksa:
- Tenant isolation
- Permission backend
- Contractor register
- Prequalification workflow
- Document review
- Worker validation
- Equipment validation
- Permit eligibility
- Security access eligibility
- Performance scoring
- Watchlist/blacklist workflow
- Dashboard calculation
- Report export
- Cross-module links
- Audit log
- Build/lint/test

Perbaiki semua bug P0/P1. Setelah selesai tulis:

```text
CONTRACTOR MANAGEMENT FIXED
```
