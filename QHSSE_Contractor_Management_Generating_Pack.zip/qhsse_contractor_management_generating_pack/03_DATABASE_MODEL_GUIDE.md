# 03 — DATABASE MODEL GUIDE

## Tabel Minimal

```text
contractor_settings
contractor_types
contractor_categories
contractor_risk_categories
contractors
contractor_profiles
contractor_contacts
contractor_prequalifications
contractor_prequalification_items
contractor_document_requirements
contractor_documents
contractor_document_reviews
contractor_workers
contractor_worker_certificates
contractor_worker_trainings
contractor_worker_competency_checks
contractor_equipment
contractor_equipment_certificates
contractor_equipment_inspections
contractor_permit_eligibility_checks
contractor_security_access_links
contractor_audits
contractor_incident_links
contractor_performance_scores
contractor_status_histories
contractor_suspensions
contractor_watchlists
contractor_blacklists
contractor_links
```

## Field Umum Wajib

Semua tabel tenant-specific wajib punya:

```text
id
company_id
site_id optional
department_id optional
created_by
updated_by
created_at
updated_at
deleted_at optional
status
```

## contractors

```text
id
company_id
contractor_number
company_name
legal_name
contractor_type_id
contractor_category_id
risk_category_id
tax_number optional
business_license_number optional
address
city
country
contact_email
contact_phone
primary_contact_name
contract_start_date optional
contract_end_date optional
scope_of_work
status
prequalification_status
document_compliance_status
worker_compliance_status
equipment_compliance_status
performance_score
workflow_instance_id optional
created_by
updated_by
created_at
updated_at
deleted_at
```

## contractor_documents

```text
id
company_id
contractor_id
requirement_id
document_type
document_name
file_id
document_number optional
issue_date optional
expiry_date optional
submitted_by
submitted_at
reviewed_by optional
reviewed_at optional
review_comment optional
verification_status
status
created_at
updated_at
```

## contractor_workers

```text
id
company_id
contractor_id
worker_number
full_name
identity_number optional
position
role
phone optional
email optional
site_id optional
medical_expiry_date optional
site_access_status
competency_status
certificate_status
training_status
status
created_by
updated_by
created_at
updated_at
deleted_at
```

## contractor_worker_certificates

```text
id
company_id
contractor_worker_id
certificate_type
certificate_name
certificate_number
issued_by
issue_date
expiry_date
file_id optional
verification_status
status
created_at
updated_at
```

## contractor_equipment

```text
id
company_id
contractor_id
equipment_number
equipment_type
equipment_name
serial_number optional
asset_tag optional
manufacturer optional
model optional
certificate_status
inspection_status
calibration_status optional
permit_eligibility_status
status
created_by
updated_by
created_at
updated_at
deleted_at
```

## contractor_performance_scores

```text
id
company_id
contractor_id
period
document_score
training_score
safety_score
quality_score
audit_score
incident_score
action_closure_score
permit_compliance_score
overall_score
rating
calculated_at
created_at
updated_at
```

## Index Wajib

```text
company_id
contractor_number
contractor_id
status
prequalification_status
document_compliance_status
worker_compliance_status
equipment_compliance_status
performance_score
expiry_date
created_at
```
