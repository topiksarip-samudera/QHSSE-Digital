# 01 — MASTER BLUEPRINT CONTRACTOR MANAGEMENT

## Tujuan Modul

Modul **Contractor Management** digunakan untuk mengelola contractor dari registrasi, prequalification, document compliance, worker competency, equipment validation, permit eligibility, security access, audit, incident history, performance score, sampai suspension/blacklist.

Modul ini harus menjadi pusat kontrol contractor dalam WebApp QHSSE.

## Prinsip Desain

1. Contractor Management bukan master vendor biasa.
2. Contractor harus punya status lifecycle.
3. Contractor harus melewati prequalification.
4. Dokumen contractor harus bisa disubmit, direview, diverifikasi, dan dimonitor expiry.
5. Worker contractor harus punya competency/certificate validation.
6. Equipment contractor harus punya certificate/inspection/calibration validation.
7. Contractor harus terhubung ke Permit to Work.
8. Contractor harus terhubung ke Security Management untuk gate pass, visitor, vehicle access, dan badge.
9. Contractor audit, finding, incident, dan action harus memengaruhi performance score.
10. Contractor bermasalah harus bisa masuk watchlist, suspension, atau blacklist.
11. Semua critical decision harus workflow-driven dan audit logged.
12. Semua data wajib tenant-safe.

## Submodul Utama

```text
Contractor Register
Contractor Profile
Prequalification
Document Requirement
Document Submission
Document Review
Contractor Worker Register
Worker Competency
Worker Certificate
Worker Training Validation
Contractor Equipment Register
Equipment Certificate
Permit Eligibility
Security Access
Gate Pass Integration
Contractor Audit
Contractor Inspection
Contractor Incident History
Contractor Performance Score
Suspension
Watchlist
Blacklist
Corrective Action
Dashboard & Reporting
```

## Status Contractor

```text
draft
registered
prequalification_submitted
under_review
revision_required
approved
active
conditionally_approved
suspended
watchlisted
blacklisted
expired
inactive
archived
```

## Status Dokumen Contractor

```text
not_submitted
submitted
under_review
approved
rejected
expired
expiring_soon
waived
```

## Status Worker Contractor

```text
draft
active
inactive
blocked
certificate_expired
training_incomplete
medical_expired
site_access_approved
site_access_suspended
```

## Status Equipment Contractor

```text
draft
active
out_of_service
certificate_expired
inspection_overdue
calibration_overdue
blocked
```

## Output Utama

```text
Contractor Register
Contractor Profile
Prequalification Report
Document Compliance Report
Worker Register
Worker Competency Matrix
Certificate Expiry List
Equipment Register
Equipment Certificate Register
Permit Eligibility Result
Security Access Register
Contractor Audit Report
Contractor Incident History
Performance Scorecard
Watchlist / Blacklist Register
Corrective Action List
Contractor Dashboard
```

## Integrasi Core

```text
Workflow: prequalification approval, document verification, suspension/blacklist
Action Tracking: corrective action from audit/finding/performance issue
Attachment: document submission, evidence
Notification: document expiry, certificate expiry, review due, suspension
Audit Log: critical status changes
Numbering: contractor number, worker number, equipment number, prequalification number
Dashboard: compliance and performance KPIs
API/Webhook: contractor status and eligibility events
```

## Integrasi Modul Lain

```text
Security Management:
- contractor visitor, gate pass, vehicle access, badge
- access blocked if contractor suspended/blacklisted

Permit to Work:
- contractor eligibility before permit activation
- worker competency and equipment certificate validation

Training & Competency:
- worker training/certificate validation
- training gap and expiry

Document Control:
- contractor documents, HSE plan, insurance, licenses
- controlled document acknowledgement

Audit & Inspection:
- contractor audit and finding
- inspection finding affects performance score

Incident Management:
- contractor incident history
- severe incident may trigger suspension/watchlist

Risk Management:
- contractor risk category and risk profile
- high risk contractor requires additional approval

Asset & Equipment:
- contractor equipment and certificate validation

Legal & Compliance:
- legal document compliance and evidence
```
