# 04 — API CONTRACT GUIDE

Gunakan prefix:

```text
/api/v1
```

## Contractor Core

```text
GET    /contractors
POST   /contractors
GET    /contractors/:id
PATCH  /contractors/:id
DELETE /contractors/:id
POST   /contractors/:id/submit-prequalification
POST   /contractors/:id/review
POST   /contractors/:id/approve
POST   /contractors/:id/reject
POST   /contractors/:id/suspend
POST   /contractors/:id/reactivate
POST   /contractors/:id/watchlist
POST   /contractors/:id/blacklist
```

## Documents

```text
GET  /contractors/:id/document-requirements
POST /contractors/:id/document-requirements
GET  /contractors/:id/documents
POST /contractors/:id/documents
GET  /contractor-documents/:documentId
PATCH /contractor-documents/:documentId
POST /contractor-documents/:documentId/review
POST /contractor-documents/:documentId/approve
POST /contractor-documents/:documentId/reject
POST /contractor-documents/:documentId/waive
```

## Workers

```text
GET    /contractors/:id/workers
POST   /contractors/:id/workers
GET    /contractor-workers/:workerId
PATCH  /contractor-workers/:workerId
DELETE /contractor-workers/:workerId
GET    /contractor-workers/:workerId/certificates
POST   /contractor-workers/:workerId/certificates
POST   /contractor-workers/:workerId/validate-competency
POST   /contractor-workers/:workerId/block
POST   /contractor-workers/:workerId/approve-site-access
```

## Equipment

```text
GET    /contractors/:id/equipment
POST   /contractors/:id/equipment
GET    /contractor-equipment/:equipmentId
PATCH  /contractor-equipment/:equipmentId
DELETE /contractor-equipment/:equipmentId
GET    /contractor-equipment/:equipmentId/certificates
POST   /contractor-equipment/:equipmentId/certificates
POST   /contractor-equipment/:equipmentId/validate-certificate
POST   /contractor-equipment/:equipmentId/block
```

## Eligibility

```text
POST /contractors/:id/check-permit-eligibility
POST /contractor-workers/:workerId/check-permit-eligibility
POST /contractor-equipment/:equipmentId/check-permit-eligibility
POST /contractors/:id/check-security-access-eligibility
```

## Audit, Incident, Performance

```text
GET  /contractors/:id/audits
GET  /contractors/:id/incidents
GET  /contractors/:id/findings
GET  /contractors/:id/actions
GET  /contractors/:id/performance
POST /contractors/:id/performance/recalculate
```

## Dashboard & Reports

```text
GET /contractor-management/dashboard
GET /contractor-management/kpi
GET /contractor-management/expiring-documents
GET /contractor-management/expiring-certificates
GET /contractor-management/low-performance
GET /contractors/export
GET /contractors/:id/report
```

## Settings

```text
GET   /contractor-management/settings
PATCH /contractor-management/settings
GET   /contractor-management/master-data
```
