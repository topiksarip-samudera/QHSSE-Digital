# Contractor Permission Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PERM-001 | User without contractor.view opens register | 403 / hidden UI |
| PERM-002 | User without contractor.create creates contractor | 403 |
| PERM-003 | User without contractor.approve approves contractor | 403 |
| PERM-004 | User without document.approve approves document | 403 |
| PERM-005 | User without contractor.suspend suspends contractor | 403 |
| PERM-006 | Site A user accesses Site B contractor | 403/404 |
| PERM-007 | External contractor accesses unrelated contractor | 403/404 |
| PERM-008 | Export contractor report | Audit log created |
