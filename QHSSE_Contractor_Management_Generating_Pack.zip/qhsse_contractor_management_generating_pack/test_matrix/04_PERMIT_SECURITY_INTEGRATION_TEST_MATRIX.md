# Permit & Security Integration Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PSI-001 | Active contractor permit check | Eligible |
| PSI-002 | Suspended contractor permit check | Blocked |
| PSI-003 | Blacklisted contractor security access | Blocked |
| PSI-004 | Worker cert expired for PTW | Block/warning based config |
| PSI-005 | Equipment cert expired for PTW | Block/warning based config |
| PSI-006 | Contractor approved for gate pass | Allowed |
| PSI-007 | Vehicle access for inactive contractor | Blocked |
| PSI-008 | Badge request for unapproved worker | Blocked |
