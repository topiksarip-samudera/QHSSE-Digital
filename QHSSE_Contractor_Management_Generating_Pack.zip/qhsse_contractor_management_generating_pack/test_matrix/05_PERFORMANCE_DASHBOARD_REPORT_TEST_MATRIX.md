# Performance, Dashboard & Report Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PDR-001 | Performance score calculation | Accurate |
| PDR-002 | Contractor with incident | Score affected |
| PDR-003 | Contractor with overdue action | Score affected |
| PDR-004 | Document compliance KPI | Accurate |
| PDR-005 | Worker certificate expiry KPI | Accurate |
| PDR-006 | Equipment certificate expiry KPI | Accurate |
| PDR-007 | Export contractor register | Scoped data only |
| PDR-008 | Company A dashboard | No Company B data |
