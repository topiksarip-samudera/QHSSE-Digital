# Document, Worker & Equipment Validation Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| DWE-001 | Required document missing | Document compliance incomplete |
| DWE-002 | Contractor document expired | Compliance blocked/warning |
| DWE-003 | Worker certificate expired | Worker not eligible |
| DWE-004 | Worker training missing | Competency gap |
| DWE-005 | Equipment certificate expired | Equipment not eligible |
| DWE-006 | Equipment inspection overdue | Equipment warning/block |
| DWE-007 | All requirements valid | Contractor eligible |
| DWE-008 | Waived document | Compliance accepted with audit log |
