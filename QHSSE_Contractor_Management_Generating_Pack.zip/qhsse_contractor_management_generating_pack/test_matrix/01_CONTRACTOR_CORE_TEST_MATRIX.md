# Contractor Core Test Matrix

| ID | Area | Scenario | Expected |
|---|---|---|---|
| CON-001 | Contractor | Create contractor | Success |
| CON-002 | Contractor | Submit prequalification | Workflow started |
| CON-003 | Contractor | Approve contractor | Status active |
| CON-004 | Contractor | Reject contractor | Status rejected/revision required |
| CON-005 | Document | Submit required document | Status submitted |
| CON-006 | Document | Approve document | Compliance updated |
| CON-007 | Worker | Create worker | Success |
| CON-008 | Equipment | Create equipment | Success |
