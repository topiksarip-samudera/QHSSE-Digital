# 06 — PERMISSION & SECURITY GUIDE

## Rules

- Semua query wajib filter `company_id`.
- Scope wajib mengikuti site/project/department/location user.
- Widget disembunyikan jika permission tidak ada.
- Drill-down harus memanggil permission source module.
- Custom report tidak boleh bypass permission.
- Export wajib audit log.
- Scheduled report recipient wajib divalidasi.
- Report sharing lintas tenant dilarang.
- Data sensitif harus masking sesuai permission.
- Row limit dan export limit wajib dikonfigurasi.

## Roles

```text
Executive Viewer
QHSSE Manager
Site HSE
Department Head
Auditor
Module Owner
Report Designer
Report Scheduler
Tenant Admin
```
