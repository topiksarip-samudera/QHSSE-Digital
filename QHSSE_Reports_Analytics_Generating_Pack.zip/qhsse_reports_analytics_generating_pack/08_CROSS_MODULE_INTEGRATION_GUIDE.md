# 08 — CROSS-MODULE INTEGRATION GUIDE

Reports & Analytics mengambil data dari:

```text
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
```

## Mapping Ringkas

```text
Incident → frequency, severity, RCA, CAPA
Risk → risk level, residual risk, control effectiveness
Permit → active permit, high-risk work, extension, closure
Audit → finding, score, action closure
Document → acknowledgement, obsolete, revision
Training → completion, competency gap, certificate expiry
Legal → compliance score, obligation due, evidence
Environment → exceedance, waste, emission, monitoring
Quality → NCR, complaint, defect, COPQ
Security → incident, patrol, access, visitor
Contractor → compliance, worker, equipment, performance
Emergency → drill, readiness, emergency equipment
Asset → certificate, inspection, maintenance, calibration
```
