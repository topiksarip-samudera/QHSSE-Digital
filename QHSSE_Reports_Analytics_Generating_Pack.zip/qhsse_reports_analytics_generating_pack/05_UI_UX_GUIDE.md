# 05 — UI/UX GUIDE

## Sidebar

```text
Reports & Analytics
├── Executive Dashboard
├── QHSSE Performance
├── Incident Analytics
├── Risk Analytics
├── Permit Analytics
├── Audit & CAPA Analytics
├── Compliance Analytics
├── Training Analytics
├── Contractor Analytics
├── Environment Analytics
├── Quality Analytics
├── Security Analytics
├── Emergency Analytics
├── Asset Analytics
├── Report Builder
├── Scheduled Reports
├── Export History
└── Settings
```

## Components

```text
MetricCard
TrendChart
HeatmapWidget
DonutChart
GaugeWidget
LeaderboardTable
DueListTable
FilterBar
DateRangePicker
ScopeSelector
SavedViewSelector
DrilldownDrawer
ExportButton
ReportBuilderCanvas
ScheduleReportDialog
```

## Report Builder Flow

```text
1 Select dataset
2 Select fields
3 Add filters
4 Add grouping/sorting
5 Choose chart/table
6 Preview
7 Save / Publish / Export / Schedule
```
