# 04 Export Schedule Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| T-001 | Export PDF | PASS |
| T-002 | Export Excel | PASS |
| T-003 | Export CSV | PASS |
| T-004 | Scoped export | PASS |
| T-005 | Create scheduled report | PASS |
| T-006 | Run now | PASS |
| T-007 | Invalid recipient rejected | PASS |
| T-008 | Huge export queued | PASS |
