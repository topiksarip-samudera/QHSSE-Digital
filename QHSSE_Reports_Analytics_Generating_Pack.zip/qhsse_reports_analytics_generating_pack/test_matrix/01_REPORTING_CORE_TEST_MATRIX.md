# 01 Reporting Core Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| T-001 | Create metric definition | PASS |
| T-002 | Create KPI threshold | PASS |
| T-003 | Register data source | PASS |
| T-004 | Create dashboard widget | PASS |
| T-005 | Apply date range | PASS |
| T-006 | Open drilldown | PASS |
| T-007 | Tenant isolation | PASS |
| T-008 | Export audit log | PASS |
