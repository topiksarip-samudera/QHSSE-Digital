# 03 Report Builder Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| T-001 | Select dataset | PASS |
| T-002 | Select fields | PASS |
| T-003 | Apply filter | PASS |
| T-004 | Group field | PASS |
| T-005 | Save report | PASS |
| T-006 | Publish report | PASS |
| T-007 | Dataset without permission | PASS |
| T-008 | Raw SQL attempt rejected | PASS |
