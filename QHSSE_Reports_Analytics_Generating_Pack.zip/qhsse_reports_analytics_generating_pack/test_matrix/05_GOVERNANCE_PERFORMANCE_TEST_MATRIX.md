# 05 Governance Performance Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| T-001 | Row-level access | PASS |
| T-002 | Data masking | PASS |
| T-003 | Cache refresh | PASS |
| T-004 | Aggregation accuracy | PASS |
| T-005 | Query limit | PASS |
| T-006 | KPI threshold alert | PASS |
| T-007 | Metric audit log | PASS |
| T-008 | Dashboard performance | PASS |
