# 01 Prompt Start Reports Analytics

Mulai generate Reports & Analytics dari sequence/01_foundation_reporting_data_model.md. Kerjakan sequence pertama saja. Setelah selesai tulis: SELESAI REPORTS ANALYTICS SEQUENCE 01: Foundation & Reporting Data Model.
