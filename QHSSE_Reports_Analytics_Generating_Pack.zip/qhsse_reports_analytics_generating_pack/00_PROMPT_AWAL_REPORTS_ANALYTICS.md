# 00 — PROMPT AWAL REPORTS & ANALYTICS

Core Platform sudah stabil. Semua QHSSE Operational Modules sudah selesai atau siap integrasi:

```text
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
```

Sekarang generate **Reports & Analytics** berdasarkan folder `qhsse_reports_analytics_generating_pack`.

Aturan wajib:
1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_reporting_data_model.md`.
3. Reports & Analytics tidak boleh hanya dashboard statis.
4. Harus ada metric catalog, KPI definition, data source registry, dashboard framework, widget engine, executive dashboard, analytics per modul, report builder, scheduled report, export PDF/Excel/CSV, data governance, row-level security, cache/materialized view, dan QA.
5. Semua report, export, drill-down, scheduled distribution, dan setting change wajib audit logged.
6. Semua data wajib tenant-safe, site/project/department scoped, dan permission-guarded.
7. Setelah selesai tulis:
`SELESAI REPORTS ANALYTICS SEQUENCE 01: Foundation & Reporting Data Model`

Jangan lanjut sequence berikutnya sebelum saya minta continue.
