# 04 Incident, Risk & Permit Analytics

## Tujuan
Generate sequence ini secara end-to-end: database, backend API, frontend UI, permission, audit log, test minimal, dan acceptance criteria.

## Fokus
```text
incident trend, TRIR/LTIFR, risk heatmap, residual risk, permit analytics
```

## Database Relevan
```text
reporting_settings
reporting_data_sources
reporting_metric_catalog
reporting_kpi_definitions
dashboard_definitions
dashboard_widgets
analytics_metric_snapshots
analytics_aggregations
custom_reports
scheduled_reports
report_exports
report_distribution_logs
```

## API Pattern
```text
GET /api/v1/reporting/metrics
GET /api/v1/reporting/kpis
GET /api/v1/dashboards
GET /api/v1/dashboards/executive-qhsse
GET /api/v1/analytics/<module>
GET /api/v1/report-builder/datasets
POST /api/v1/report-builder/preview
POST /api/v1/reports/export
GET /api/v1/scheduled-reports
```

## Frontend Minimal
```text
Dashboard page
Analytics page
Filter/date range
KPI card
Chart/table widget
Drilldown drawer
Report builder panel jika relevan
Export button jika relevan
Schedule panel jika relevan
```

## Testing Minimal
```text
Happy path
Validation error
Permission denied
Tenant isolation
Scope filtering
KPI formula accuracy
Export audit log jika relevan
Performance check jika relevan
```

## Acceptance Criteria
- Tenant-safe.
- Permission backend berjalan.
- UI hide widget tanpa permission.
- KPI formula punya definisi.
- Drill-down tidak bypass permission.
- Audit log tercatat.
- Tidak lanjut sequence berikutnya.

## Status Akhir
```text
SELESAI REPORTS ANALYTICS SEQUENCE 04: Incident, Risk & Permit Analytics
```
