# 01 — MASTER BLUEPRINT REPORTS & ANALYTICS

## Tujuan

Reports & Analytics menjadi pusat informasi QHSSE untuk management, HSE, auditor, site/project, contractor reviewer, dan tenant SaaS.

## Submodul

```text
Metric Catalog
KPI Definition
Data Source Registry
Dashboard Framework
Widget Engine
Executive Dashboard
Operational Analytics
Report Builder
Custom Report Designer
Scheduled Report
Export PDF / Excel / CSV
Report Distribution
Data Governance
Access Control
Cache / Materialized View
Performance Optimization
```

## Dashboard

```text
Executive QHSSE Dashboard
QHSSE Performance Dashboard
Incident Dashboard
Risk Dashboard
Permit Dashboard
Audit & CAPA Dashboard
Compliance Dashboard
Training Dashboard
Contractor Dashboard
Environment Dashboard
Quality Dashboard
Security Dashboard
Emergency Dashboard
Asset Dashboard
```

## KPI Utama

```text
Total Incident
TRIR
LTIFR
Severity Rate
Near Miss Rate
Open CAPA
Overdue CAPA
Risk Heatmap
High Risk Open
Residual Risk Trend
Active Permit
Expired Permit
Audit Score
Finding Closure Rate
Compliance Score
Legal Obligation Due
Training Completion
Competency Gap
Certificate Expiry
Contractor Performance Score
Environmental Exceedance
Waste Generated
Emission Trend
NCR Count
Complaint Count
Cost of Poor Quality
Security Incident
Emergency Readiness Score
Drill Completion
Asset Readiness
Inspection Overdue
Calibration Due
```

## Prinsip

- Semua KPI harus punya formula dan source module.
- Semua dashboard harus filterable dan drillable.
- Semua drill-down harus kembali ke record sumber.
- Semua report harus permission-aware.
- Semua query harus tenant-safe.
- Semua export harus audit logged.
- Semua analytics berat memakai cache/materialized view.
