# 03 — REPORTING DATA MODEL GUIDE

## Tabel Minimal

```text
reporting_settings
reporting_data_sources
reporting_metric_catalog
reporting_metric_formulas
reporting_kpi_definitions
reporting_kpi_thresholds
dashboard_definitions
dashboard_widgets
dashboard_saved_views
dashboard_user_preferences
analytics_cache_jobs
analytics_metric_snapshots
analytics_aggregations
report_templates
custom_reports
custom_report_fields
custom_report_filters
custom_report_charts
scheduled_reports
scheduled_report_recipients
report_exports
report_distribution_logs
report_access_logs
reporting_audit_logs
```

## Field Wajib Tenant-Specific

```text
id
company_id
site_id optional
project_id optional
department_id optional
created_by
updated_by
created_at
updated_at
deleted_at optional
status
```

## Entitas Kunci

`reporting_metric_catalog`:
```text
metric_key, metric_name, module_key, unit, aggregation_type, formula_expression, source_id, date_field, scope_field, permission_key, is_enabled
```

`dashboard_widgets`:
```text
dashboard_id, widget_key, title, widget_type, metric_id, chart_type, query_config_json, filter_config_json, drilldown_config_json, permission_key
```

`custom_reports`:
```text
report_name, dataset_key, visibility, filter_config_json, field_config_json, chart_config_json, sort_config_json, permission_key
```

`scheduled_reports`:
```text
schedule_name, frequency, cron_expression, timezone, recipient_config_json, export_format, last_run_at, next_run_at, status
```
