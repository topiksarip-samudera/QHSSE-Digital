# 04 — API CONTRACT GUIDE

Gunakan prefix `/api/v1`.

## Metric & KPI

```text
GET    /reporting/data-sources
POST   /reporting/data-sources
GET    /reporting/metrics
POST   /reporting/metrics
GET    /reporting/metrics/:id
PATCH  /reporting/metrics/:id
POST   /reporting/metrics/:id/refresh
GET    /reporting/kpis
POST   /reporting/kpis
PATCH  /reporting/kpis/:id
```

## Dashboard & Analytics

```text
GET    /dashboards
POST   /dashboards
GET    /dashboards/:id
PATCH  /dashboards/:id
GET    /dashboards/:id/widgets
POST   /dashboards/:id/widgets
GET    /dashboards/executive-qhsse
GET    /dashboards/qhsse-performance
GET    /analytics/incident
GET    /analytics/risk
GET    /analytics/permit
GET    /analytics/audit
GET    /analytics/capa
GET    /analytics/compliance
GET    /analytics/training
GET    /analytics/contractor
GET    /analytics/environment
GET    /analytics/quality
GET    /analytics/security
GET    /analytics/emergency
GET    /analytics/asset
GET    /analytics/drilldown
```

## Report Builder, Export, Schedule

```text
GET    /report-builder/datasets
GET    /report-builder/datasets/:key/fields
POST   /report-builder/preview
GET    /custom-reports
POST   /custom-reports
PATCH  /custom-reports/:id
POST   /custom-reports/:id/publish
POST   /custom-reports/:id/export
POST   /reports/export
GET    /reports/exports
GET    /scheduled-reports
POST   /scheduled-reports
PATCH  /scheduled-reports/:id
POST   /scheduled-reports/:id/run-now
GET    /report-distribution-logs
```
