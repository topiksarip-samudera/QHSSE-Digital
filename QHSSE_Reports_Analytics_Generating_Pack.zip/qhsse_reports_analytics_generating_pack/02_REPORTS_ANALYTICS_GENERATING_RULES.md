# 02 — GENERATING RULES

## Aturan Wajib

1. Jangan buat dashboard statis.
2. Buat metric catalog sebelum dashboard.
3. Buat data source registry untuk semua modul.
4. Setiap KPI wajib punya formula, unit, source, period, dan threshold.
5. Setiap widget wajib punya permission key.
6. Setiap dashboard wajib punya filter date range, company, site, project, department, module, status.
7. Setiap analytics wajib punya drill-down.
8. Report builder tidak boleh menerima raw SQL dari user.
9. Export wajib lewat queue/job untuk data besar.
10. Scheduled report wajib punya audit log dan distribution log.
11. Terapkan row-level access control.
12. Optimalkan dengan cache, snapshot, aggregation table, materialized view.

## Permissions

```text
reports.view
reports.view_all
reports.create
reports.update
reports.delete
reports.export
reports.schedule
reports.manage_settings
analytics.view
analytics.view_executive
analytics.view_incident
analytics.view_risk
analytics.view_permit
analytics.view_audit
analytics.view_compliance
analytics.view_training
analytics.view_contractor
analytics.view_environment
analytics.view_quality
analytics.view_security
analytics.view_emergency
analytics.view_asset
dashboard.view
dashboard.create_custom
dashboard.save_view
dashboard.share
report_builder.view
report_builder.create
report_builder.update
report_builder.delete
report_builder.publish
metric.manage
```

## Audit Log

```text
dashboard.viewed
dashboard.saved_view_created
analytics.drilldown_opened
metric.created
metric.updated
report.created
report.updated
report.exported
report.scheduled
report.distributed
report_builder.dataset_accessed
settings.changed
```
