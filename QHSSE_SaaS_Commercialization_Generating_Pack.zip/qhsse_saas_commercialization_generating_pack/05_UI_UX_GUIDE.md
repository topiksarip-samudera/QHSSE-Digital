# 05 — UI/UX GUIDE SAAS COMMERCIALIZATION

## SaaS Admin Sidebar

```text
SaaS Admin
├── Overview
├── Tenants
├── Onboarding
├── Provisioning Jobs
├── Plans & Pricing
├── Packages
├── Entitlements
├── Subscriptions
├── Invoices
├── Payments
├── Usage & Quota
├── Licenses & Seats
├── White Label
├── Custom Domains
├── Support Tickets
├── Announcements
├── Revenue Analytics
└── Commercial Settings
```

## Tenant Billing Sidebar

```text
Billing
├── Current Plan
├── Usage
├── Quota
├── Invoices
├── Payment Method
├── Upgrade / Downgrade
├── White Label
└── Custom Domain
```

## Komponen Wajib

```text
TenantStatusBadge
SubscriptionStatusBadge
InvoiceStatusBadge
PaymentStatusBadge
PlanCard
PackageMatrix
EntitlementTable
QuotaUsageBar
SeatUsageCard
TrialCountdownBanner
BillingSummaryCard
InvoiceTable
PaymentTimeline
WhiteLabelPreview
DomainVerificationPanel
RevenueMetricCard
```
