# 04 Usage Quota License Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| SAAS-001 | Record usage | PASS |
| SAAS-002 | Check quota | PASS |
| SAAS-003 | Quota warning | PASS |
| SAAS-004 | Quota block | PASS |
| SAAS-005 | Seat allocation | PASS |
| SAAS-006 | Seat limit exceeded | PASS |
| SAAS-007 | Device limit | PASS |
| SAAS-008 | AI token limit | PASS |
