# 03 Payment Webhook Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| SAAS-001 | Create checkout | PASS |
| SAAS-002 | Payment pending | PASS |
| SAAS-003 | Payment paid webhook | PASS |
| SAAS-004 | Duplicate webhook idempotent | PASS |
| SAAS-005 | Payment failed webhook | PASS |
| SAAS-006 | Refund event | PASS |
| SAAS-007 | Invalid signature rejected | PASS |
| SAAS-008 | Reconciliation | PASS |
