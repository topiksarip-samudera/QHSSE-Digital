# 02 Trial Billing Invoice Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| SAAS-001 | Start trial | PASS |
| SAAS-002 | Trial expired | PASS |
| SAAS-003 | Upgrade plan | PASS |
| SAAS-004 | Downgrade plan | PASS |
| SAAS-005 | Create invoice | PASS |
| SAAS-006 | Issue invoice | PASS |
| SAAS-007 | Invoice PDF | PASS |
| SAAS-008 | Tax calculation | PASS |
