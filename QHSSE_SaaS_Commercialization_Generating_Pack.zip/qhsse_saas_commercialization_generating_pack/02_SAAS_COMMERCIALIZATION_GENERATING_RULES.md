# 02 — SAAS COMMERCIALIZATION GENERATING RULES

## Aturan Utama

1. Jangan membuat SaaS Commercialization hanya sebagai pricing page.
2. Plan dan package harus versioned.
3. Entitlement harus dicek backend.
4. Module ON/OFF harus mengikuti subscription.
5. Quota enforcement harus dilakukan di backend, bukan hanya UI.
6. Payment webhook harus idempotent.
7. Payment status tidak boleh bisa diubah bebas dari frontend.
8. Invoice harus memiliki numbering dan audit trail.
9. Trial expired harus memicu reminder dan restriction.
10. Grace period harus configurable.
11. Suspension harus memblokir fitur sesuai rule.
12. White label harus scoped per tenant.
13. Custom domain harus verifikasi DNS/ownership.
14. SaaS admin support access harus terkontrol dan audit-logged.
15. Semua billing/plan/payment/entitlement change wajib audit logged.

## Permission Standard

```text
saas.view
saas.manage_settings
saas.manage_tenant
saas.manage_plan
saas.manage_package
saas.manage_entitlement
saas.manage_billing
saas.manage_payment
saas.manage_quota
saas.manage_license
saas.manage_whitelabel
saas.manage_domain
saas.manage_support
saas.view_revenue
saas.export_report

tenant.billing.view
tenant.billing.update
tenant.subscription.view
tenant.subscription.change
tenant.invoice.view
tenant.invoice.pay
tenant.usage.view
```

## Audit Log Wajib

```text
saas.plan.created
saas.plan.updated
saas.package.updated
saas.entitlement.changed
tenant.created
tenant.provisioned
tenant.subscription.created
tenant.subscription.changed
tenant.trial.started
tenant.trial.expired
tenant.suspended
tenant.reactivated
invoice.created
invoice.issued
payment.webhook_received
payment.status_changed
quota.exceeded
license.seat_exceeded
domain.verified
white_label.updated
support.ticket_created
commercial.report_exported
```
