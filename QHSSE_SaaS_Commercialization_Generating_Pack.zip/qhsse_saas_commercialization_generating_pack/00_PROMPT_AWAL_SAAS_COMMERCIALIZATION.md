# 00 — PROMPT AWAL SAAS COMMERCIALIZATION UNTUK AI AGENT

Core Platform, seluruh QHSSE Operational Modules, Reports & Analytics, AI Assistant, dan Mobile/PWA Field Optimization sudah selesai atau siap integrasi.

Platform yang akan dikomersialisasikan:

```text
Core Platform
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
Mobile/PWA Field Optimization
```

Sekarang generate tahap **SaaS Commercialization** berdasarkan folder `qhsse_saas_commercialization_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_saas_commercial_settings.md`.
3. SaaS Commercialization tidak boleh hanya pricing page.
4. Harus ada tenant onboarding dan provisioning.
5. Harus ada subscription plan dan package management.
6. Harus ada module package, feature toggle, dan entitlement.
7. Harus ada trial/freemium/upgrade/downgrade/cancel/grace period.
8. Harus ada billing account, invoice, tax config, dan invoice PDF.
9. Harus ada payment gateway abstraction dan webhook handling.
10. Harus ada usage metering, quota, overuse, seat, user limit, device limit, API limit, AI token limit, storage limit.
11. Harus ada white label dan custom domain.
12. Harus ada SaaS admin console dan customer management.
13. Harus ada support ticket, announcement, dan customer communication.
14. Harus ada commercial dashboard dan revenue analytics.
15. Semua data wajib tenant-safe, permission-guarded, audit-logged.
16. Billing/payment webhook harus idempotent dan aman.
17. Setelah sequence selesai, tulis:
   `SELESAI SAAS COMMERCIALIZATION SEQUENCE XX: <nama sequence>`
18. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
