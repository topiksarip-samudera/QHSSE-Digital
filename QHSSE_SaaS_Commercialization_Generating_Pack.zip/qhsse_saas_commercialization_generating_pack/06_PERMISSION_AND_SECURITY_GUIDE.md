# 06 — PERMISSION & SECURITY GUIDE

## Security Rules

- Semua data tenant harus isolated.
- SaaS admin tidak boleh bypass tanpa audit log.
- Support impersonation harus disabled by default atau memakai approval/session reason.
- Payment webhook harus verify signature.
- Webhook harus idempotent.
- Invoice total harus dihitung backend.
- Payment status tidak boleh dimanipulasi dari frontend.
- Entitlement check harus di backend.
- Quota enforcement harus di backend.
- Custom domain harus diverifikasi DNS ownership.
- White label asset harus tenant-scoped.
- Billing and commercial export harus audit logged.

## Sensitive Data

```text
payment_token
gateway_secret
billing_tax_id
billing_address
customer_email
payment_payload
invoice_pdf
domain_verification_token
```
