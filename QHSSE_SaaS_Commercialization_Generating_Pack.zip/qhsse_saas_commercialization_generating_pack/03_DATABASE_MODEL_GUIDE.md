# 03 — DATABASE MODEL GUIDE

## Tabel Minimal

```text
saas_commercial_settings
saas_currencies
saas_tax_configs
saas_tenant_accounts
saas_tenant_onboarding_steps
saas_tenant_provisioning_jobs
saas_subscription_plans
saas_plan_versions
saas_packages
saas_package_modules
saas_feature_entitlements
saas_subscriptions
saas_subscription_changes
saas_trial_configs
saas_billing_accounts
saas_invoices
saas_invoice_items
saas_payment_gateways
saas_payment_methods
saas_payments
saas_payment_webhook_events
saas_usage_meters
saas_usage_records
saas_quota_limits
saas_quota_events
saas_licenses
saas_seat_allocations
saas_white_label_settings
saas_custom_domains
saas_admin_customer_notes
saas_support_tickets
saas_announcements
saas_revenue_snapshots
saas_commercial_audit_logs
```

## Field Umum

Semua tabel tenant-specific wajib punya:

```text
id
company_id optional
tenant_account_id optional
created_by
updated_by
created_at
updated_at
deleted_at optional
status
```

## saas_subscription_plans

```text
id
plan_key
plan_name
description
pricing_model
billing_cycle
base_price
currency
is_public
is_active
created_at
updated_at
```

## saas_feature_entitlements

```text
id
plan_id
package_id optional
feature_key
module_key optional
limit_type
limit_value
is_enabled
created_at
updated_at
```

## saas_subscriptions

```text
id
tenant_account_id
plan_id
plan_version_id
billing_account_id
status
current_period_start
current_period_end
trial_start optional
trial_end optional
cancel_at_period_end
grace_period_until optional
created_at
updated_at
```

## saas_invoices

```text
id
tenant_account_id
invoice_number
subscription_id
currency
subtotal
tax_amount
discount_amount
total_amount
due_date
issued_at
paid_at optional
status
pdf_file_id optional
created_at
updated_at
```

## saas_payments

```text
id
tenant_account_id
invoice_id
gateway_key
gateway_payment_id
amount
currency
status
paid_at optional
failed_reason optional
raw_payload_json
created_at
updated_at
```

## saas_usage_records

```text
id
tenant_account_id
company_id
meter_key
module_key optional
feature_key optional
quantity
unit
period_start
period_end
recorded_at
metadata_json
created_at
```

## saas_custom_domains

```text
id
tenant_account_id
domain
verification_token
dns_status
ssl_status
verified_at optional
is_primary
status
created_at
updated_at
```
