# 03 Subscription Plan & Package Management

## Tujuan

Subscription plan, pricing tier, billing cycle, package, add-on, plan versioning, dan plan publish/unpublish.

## Fokus

```text
plan, pricing tier, billing cycle, package, add-on, plan versioning, publish/unpublish
```

## Database Relevan

```text
saas_commercial_settings
saas_tenant_accounts
saas_tenant_provisioning_jobs
saas_subscription_plans
saas_plan_versions
saas_packages
saas_package_modules
saas_feature_entitlements
saas_subscriptions
saas_subscription_changes
saas_billing_accounts
saas_invoices
saas_invoice_items
saas_payment_gateways
saas_payment_methods
saas_payments
saas_payment_webhook_events
saas_usage_meters
saas_usage_records
saas_quota_limits
saas_quota_events
saas_licenses
saas_seat_allocations
saas_white_label_settings
saas_custom_domains
saas_support_tickets
saas_announcements
saas_revenue_snapshots
saas_commercial_audit_logs
```

## API Pattern

```text
GET /api/v1/saas/tenants
POST /api/v1/saas/tenants/onboard
GET /api/v1/saas/plans
GET /api/v1/saas/packages
GET /api/v1/saas/entitlements
GET /api/v1/saas/subscriptions
GET /api/v1/saas/invoices
POST /api/v1/saas/payments/webhook/:gateway
GET /api/v1/saas/usage
GET /api/v1/saas/quota
GET /api/v1/saas/commercial-dashboard
```

Tambahkan endpoint khusus sesuai sequence.

## Frontend Minimal

```text
List page
Detail page
Create/update form
Status badge
Timeline
Audit trail
Settings panel jika relevan
Dashboard card jika relevan
```

## Testing Minimal

```text
Happy path
Validation error
Permission denied
Tenant isolation
Audit log created
Backend entitlement check jika relevan
Billing/payment idempotency jika relevan
Quota enforcement jika relevan
```

## Acceptance Criteria

- Tenant-safe.
- Permission backend berjalan.
- Commercial audit log tercatat.
- Backend enforcement berjalan.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI SAAS COMMERCIALIZATION SEQUENCE 03: Subscription Plan & Package Management
```
