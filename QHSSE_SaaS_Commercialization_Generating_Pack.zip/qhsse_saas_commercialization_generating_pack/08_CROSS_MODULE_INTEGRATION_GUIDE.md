# 08 — CROSS-MODULE INTEGRATION GUIDE

## Platform yang Dikomersialisasikan

```text
Core Platform
Incident Management
Risk Management / HIRADC / JSA
Audit & Inspection
Permit to Work
Document Control
Training & Competency
Legal & Compliance Register
Environment Management
Quality Management
Security Management
Contractor Management
Emergency Response
Asset & Equipment
Reports & Analytics
AI Assistant
Mobile/PWA Field Optimization
```

## Integrasi Penting

```text
Core Platform → tenant, user, role, permission, module ON/OFF
Reports & Analytics → commercial dashboard, tenant usage, revenue analytics
AI Assistant → token usage, AI quota, AI billing, AI feature package
Mobile/PWA → mobile access package, device limit, offline feature entitlement
All QHSSE Modules → module package by subscription plan
Notification → invoice reminder, trial ending, payment failed
Audit Log → billing change, plan change, payment event, tenant setting change
Storage → storage quota and overuse control
API Gateway → API quota and rate limit per tenant
```
