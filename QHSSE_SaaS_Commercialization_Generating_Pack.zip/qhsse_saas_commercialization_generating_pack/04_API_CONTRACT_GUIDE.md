# 04 — API CONTRACT GUIDE

Gunakan prefix `/api/v1`.

## Tenant Onboarding & Provisioning

```text
POST   /saas/tenants/onboard
GET    /saas/tenants
GET    /saas/tenants/:id
PATCH  /saas/tenants/:id
POST   /saas/tenants/:id/provision
POST   /saas/tenants/:id/suspend
POST   /saas/tenants/:id/reactivate
GET    /saas/tenants/:id/health
```

## Plan, Package, Entitlement

```text
GET    /saas/plans
POST   /saas/plans
PATCH  /saas/plans/:id
POST   /saas/plans/:id/publish
GET    /saas/packages
POST   /saas/packages
PATCH  /saas/packages/:id
GET    /saas/entitlements
POST   /saas/entitlements
PATCH  /saas/entitlements/:id
GET    /saas/tenants/:id/entitlements
```

## Subscription, Trial, Billing

```text
GET    /saas/subscriptions
POST   /saas/subscriptions
PATCH  /saas/subscriptions/:id
POST   /saas/subscriptions/:id/upgrade
POST   /saas/subscriptions/:id/downgrade
POST   /saas/subscriptions/:id/cancel
POST   /saas/trials/start
GET    /saas/billing-accounts
POST   /saas/billing-accounts
GET    /saas/invoices
POST   /saas/invoices
GET    /saas/invoices/:id
POST   /saas/invoices/:id/issue
GET    /saas/invoices/:id/pdf
```

## Payment

```text
GET    /saas/payment-gateways
POST   /saas/payment-gateways
PATCH  /saas/payment-gateways/:id
POST   /saas/payments/checkout
GET    /saas/payments
GET    /saas/payments/:id
POST   /saas/payments/webhook/:gateway
POST   /saas/payments/:id/reconcile
```

## Usage, Quota, License

```text
GET    /saas/usage
POST   /saas/usage/record
GET    /saas/quota
POST   /saas/quota/check
PATCH  /saas/quota/:id
GET    /saas/licenses
POST   /saas/licenses
GET    /saas/seats
POST   /saas/seats/allocate
POST   /saas/seats/release
```

## White Label, Domain, Support, Dashboard

```text
GET    /saas/white-label
PATCH  /saas/white-label
GET    /saas/custom-domains
POST   /saas/custom-domains
POST   /saas/custom-domains/:id/verify
GET    /saas/support-tickets
POST   /saas/support-tickets
PATCH  /saas/support-tickets/:id
GET    /saas/announcements
POST   /saas/announcements
GET    /saas/commercial-dashboard
GET    /saas/revenue-analytics
GET    /saas/audit-logs
```
