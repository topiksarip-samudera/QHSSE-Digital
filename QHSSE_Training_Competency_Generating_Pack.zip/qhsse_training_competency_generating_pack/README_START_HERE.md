# START HERE — QHSSE Training & Competency Generating Pack

Tanggal: 2026-06-22

Paket ini dibuat untuk menghasilkan modul **Training & Competency** pada WebApp QHSSE secara sequence, aman, dan tidak menjadi sekadar jadwal training biasa.

## Posisi Modul dalam Roadmap

```text
Core Platform
→ Stabilization & QA
→ Incident Management
→ Risk Management / HIRADC / JSA
→ Audit & Inspection
→ Permit to Work
→ Document Control
→ Training & Competency
→ Legal & Compliance
→ Environment
→ Quality
→ Security
→ Contractor
→ Emergency
→ Asset & Equipment
```

## Rekomendasi Split

Modul **Training & Competency** sebaiknya di-split menjadi **12 sequence**.

```text
01 Foundation & Master Data
02 Training Matrix Core
03 Competency Matrix Core
04 Training Need Analysis
05 Training Plan & Schedule
06 Training Session, Attendance & Evidence
07 Induction & Toolbox Meeting
08 Certificate Register & Expiry Management
09 Competency Assessment & Gap Analysis
10 Integration with Document, Permit, Contractor & Risk
11 Dashboard, Report & Export
12 QA, Test, Permission & Stabilization
```

## Kenapa 12 Sequence?

Training & Competency bukan hanya jadwal training. Modul ini harus menjadi **competency control system** yang mengontrol:

```text
Required training by role
Required training by position
Required training by permit type
Required training by risk control
Certificate expiry
Competency gap
Contractor worker competency
Training compliance
Document acknowledgement
Permit blocking/warning
Training evidence
Training effectiveness
```

Jika digenerate sekaligus, biasanya hasilnya hanya menjadi training schedule biasa. Dengan 12 sequence, sistem akan lengkap dan siap diintegrasikan dengan Permit to Work, Contractor, Document Control, Risk, Incident, Audit, dan Legal Compliance.

## Cara Pakai

1. Extract ZIP ke project.
2. Baca `00_PROMPT_AWAL_TRAINING_COMPETENCY.md`.
3. Baca `01_TRAINING_COMPETENCY_MASTER_BLUEPRINT.md`.
4. Baca `02_TRAINING_COMPETENCY_GENERATING_RULES.md`.
5. Mulai dari `sequence/01_foundation_master_data.md`.
6. Selesaikan satu sequence.
7. Setelah selesai, AI Agent harus menulis `SELESAI TRAINING COMPETENCY SEQUENCE XX`.
8. Jangan lanjut sequence berikutnya sebelum diminta.

## Status Akhir

Setelah sequence 12 selesai:

```text
TRAINING COMPETENCY STABILIZED: GO
```
