# 03 — DATABASE MODEL GUIDE

## Tabel Minimal

```text
training_types
training_categories
training_settings
training_matrices
training_matrix_requirements
competency_matrices
competency_items
competency_levels
training_needs
training_plans
training_schedules
training_sessions
training_participants
training_attendances
training_materials
training_assessments
training_assessment_questions
training_assessment_answers
training_evaluations
certificates
certificate_types
certificate_requirements
certificate_renewals
inductions
toolbox_meetings
toolbox_attendances
competency_assessments
competency_gap_records
training_integrations
training_reports
```

## Field Umum Wajib

Semua tabel tenant-specific wajib punya:

```text
id
company_id
site_id optional
department_id optional
created_by
updated_by
created_at
updated_at
deleted_at optional
status
```

## training_matrices

```text
id
company_id
name
description
matrix_scope
site_id optional
department_id optional
role_id optional
position_id optional
permit_type_id optional
risk_level optional
is_active
created_by
updated_by
created_at
updated_at
```

## training_matrix_requirements

```text
id
company_id
training_matrix_id
training_type_id
is_mandatory
validity_months optional
renewal_required
required_for_permit
required_for_role
required_for_contractor
validation_mode
created_at
updated_at
```

`validation_mode`:

```text
block
warning
info
```

## training_sessions

```text
id
company_id
training_number
training_type_id
title
description
trainer_id optional
external_trainer_name optional
site_id
location
start_datetime
end_datetime
max_participants optional
material_document_id optional
status
workflow_instance_id optional
created_by
updated_by
created_at
updated_at
```

## training_participants

```text
id
company_id
training_session_id
user_id optional
worker_id optional
contractor_worker_id optional
name_snapshot
company_snapshot
role_snapshot
attendance_status
assessment_status
certificate_status
created_at
updated_at
```

## training_attendances

```text
id
company_id
training_session_id
participant_id
attendance_status
check_in_time optional
check_out_time optional
attendance_evidence_id optional
confirmed_by
confirmed_at
remarks
created_at
updated_at
```

## certificates

```text
id
company_id
certificate_number
certificate_type_id
holder_type
user_id optional
worker_id optional
contractor_worker_id optional
training_session_id optional
issued_date
expiry_date optional
issued_by
file_id optional
status
renewed_from_certificate_id optional
created_at
updated_at
```

## competency_assessments

```text
id
company_id
assessed_user_id optional
assessed_worker_id optional
contractor_worker_id optional
competency_item_id
assessor_id
assessment_date
result_status
competency_level_id optional
score optional
remarks
evidence_id optional
next_assessment_date optional
created_at
updated_at
```

## Index Wajib

```text
company_id
site_id
department_id
training_number
training_type_id
status
start_datetime
end_datetime
certificate_number
expiry_date
holder_type
user_id
contractor_worker_id
```
