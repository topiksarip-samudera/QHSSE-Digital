# 03 — Competency Matrix Core

## Tujuan

Membangun competency matrix, competency item, level, assessor, required competency, dan competency status.

## Scope

Sequence ini harus menghasilkan database, backend API, frontend UI, permission, audit log, test minimal, dan acceptance criteria.


## Fitur Wajib

```text
Competency matrix CRUD
Competency item
Competency level
Required competency by role/position
Assessor assignment
Competency status
Minimum level requirement
```


## Database yang Mungkin Dibuat/Diubah

```text
training_types
training_categories
training_settings
training_matrices
training_matrix_requirements
competency_matrices
competency_items
competency_levels
training_needs
training_plans
training_schedules
training_sessions
training_participants
training_attendances
training_materials
training_assessments
training_evaluations
certificates
certificate_types
certificate_requirements
inductions
toolbox_meetings
toolbox_attendances
competency_assessments
competency_gap_records
training_integrations
training_reports
```

Gunakan hanya tabel yang relevan untuk sequence ini. Jangan duplikasi tabel core yang sudah ada.

## API Pattern

```text
GET /api/v1/training-sessions
POST /api/v1/training-sessions
GET /api/v1/training-sessions/:id
PATCH /api/v1/training-sessions/:id
GET /api/v1/certificates
POST /api/v1/certificates
GET /api/v1/competency-assessments
POST /api/v1/competency-assessments
```

Tambahkan endpoint khusus sesuai sequence.

## Frontend Minimal

```text
List page
Create/update form
Detail page
Status badge
Filter/search
Calendar/table jika relevan
Evidence upload jika relevan
Comment tab jika relevan
Audit trail tab jika relevan
```

## Permission

Tambahkan permission sesuai kebutuhan sequence dan pastikan backend guard aktif.

## Audit Log

Catat create/update/delete/schedule/conduct/attendance/certificate issue/renew/revoke/assessment/export sesuai sequence.

## Testing Minimal

```text
Happy path
Validation error
Permission denied
Tenant isolation
Audit log created
Status transition
Integration test jika relevan
```

## Acceptance Criteria

- Fitur sequence berjalan end-to-end.
- Tenant-safe.
- Permission backend berjalan.
- UI tidak menampilkan tombol tanpa permission.
- Audit log tercatat.
- Test minimal lulus.
- Tidak lanjut sequence berikutnya.

## Status Akhir

```text
SELESAI TRAINING COMPETENCY SEQUENCE 03: Competency Matrix Core
```
