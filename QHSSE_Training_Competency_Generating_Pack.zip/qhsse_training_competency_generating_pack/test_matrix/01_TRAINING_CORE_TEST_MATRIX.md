# Training Core Test Matrix

| ID | Area | Scenario | Expected |
|---|---|---|---|
| TRN-001 | Training Type | Create training type | Success |
| TRN-002 | Training Matrix | Create role requirement | Success |
| TRN-003 | Schedule | Create training schedule | Success |
| TRN-004 | Participants | Add participants | Success |
| TRN-005 | Attendance | Confirm attendance | Status updated |
| TRN-006 | Evidence | Upload attendance evidence | File secured |
| TRN-007 | Session | Close training session | Status closed |
| TRN-008 | Audit Log | Attendance confirmed | Audit log created |
