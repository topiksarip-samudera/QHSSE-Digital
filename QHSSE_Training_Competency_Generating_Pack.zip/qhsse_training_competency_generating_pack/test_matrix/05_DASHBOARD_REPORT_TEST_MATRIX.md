# Dashboard & Report Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| DR-001 | Training compliance dashboard | Accurate |
| DR-002 | Certificate expiring count | Accurate |
| DR-003 | Certificate expired count | Accurate |
| DR-004 | Competency gap count | Accurate |
| DR-005 | Training attendance rate | Accurate |
| DR-006 | Contractor compliance report | Accurate |
| DR-007 | Export training matrix | Scoped data only |
| DR-008 | Export certificate register | Scoped data only |
