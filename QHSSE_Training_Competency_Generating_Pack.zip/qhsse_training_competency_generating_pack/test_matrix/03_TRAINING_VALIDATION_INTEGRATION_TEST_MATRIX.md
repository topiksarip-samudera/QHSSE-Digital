# Training Validation & Integration Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| INT-001 | Permit validates worker with valid certificate | Pass |
| INT-002 | Permit validates expired certificate | Block/warn based config |
| INT-003 | Contractor worker certificate expired | Block/warn based config |
| INT-004 | Document revision published | Training need or acknowledgement triggered |
| INT-005 | Incident RCA creates training need | Training need created |
| INT-006 | Audit finding creates training need | Training need created |
| INT-007 | Risk control requires training | Gap analysis detects need |
| INT-008 | Legal mandatory training | Requirement appears in matrix |
