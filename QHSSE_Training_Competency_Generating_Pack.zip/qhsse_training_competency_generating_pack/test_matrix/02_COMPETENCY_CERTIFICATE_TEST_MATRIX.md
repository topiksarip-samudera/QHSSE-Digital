# Competency & Certificate Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| CC-001 | Create competency matrix | Success |
| CC-002 | Assess competency | Result saved |
| CC-003 | Competency below requirement | Gap created |
| CC-004 | Issue certificate | Certificate active |
| CC-005 | Certificate expiry date reached | Status expired/notification |
| CC-006 | Renew certificate | New expiry active |
| CC-007 | Revoke certificate | Cannot validate as active |
| CC-008 | Download certificate without permission | 403 |
