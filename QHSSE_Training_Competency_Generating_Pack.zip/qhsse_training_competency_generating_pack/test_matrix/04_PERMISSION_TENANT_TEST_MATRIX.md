# Permission & Tenant Test Matrix

| ID | Scenario | Expected |
|---|---|---|
| PERM-001 | User without training.view opens list | 403 / hidden UI |
| PERM-002 | User without training.create creates session | 403 |
| PERM-003 | User without certificate.issue issues certificate | 403 |
| PERM-004 | User without competency.assess assesses competency | 403 |
| PERM-005 | Site A user opens Site B training | 403/404 |
| PERM-006 | Contractor opens unrelated worker certificate | 403/404 |
| PERM-007 | Export without permission | 403 |
| PERM-008 | Company A dashboard | No Company B data |
