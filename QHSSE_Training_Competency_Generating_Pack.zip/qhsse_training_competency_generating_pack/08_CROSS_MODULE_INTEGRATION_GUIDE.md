# 08 — CROSS-MODULE INTEGRATION GUIDE

## Document Control

```text
- Training material can link to SOP/WI/Policy.
- New document revision can trigger re-acknowledgement or retraining.
- Document acknowledgement can feed training compliance.
```

## Permit to Work

```text
- Permit validates worker certificate and competency.
- Expired certificate can block or warn permit approval.
- Permit type can define required training.
```

## Contractor Management

```text
- Contractor worker training and certificates are validated.
- Contractor compliance score can use training compliance.
- Expired contractor worker certificate creates warning/block.
```

## Risk Management

```text
- Risk control can require training.
- High-risk activity can require specific competency.
- Risk review can create training need.
```

## Incident Management

```text
- Incident RCA can create training need.
- Lessons learned can become toolbox/training material.
- Repeat incident can trigger mandatory retraining.
```

## Audit & Inspection

```text
- Audit finding can create training action.
- Training evidence supports audit finding close-out.
- Inspection can verify training compliance.
```

## Legal & Compliance

```text
- Legal obligations can define mandatory training.
- Compliance evidence can include attendance/certificates.
```
