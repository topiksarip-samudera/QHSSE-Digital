# 04 — API CONTRACT GUIDE

Gunakan prefix:

```text
/api/v1
```

## Training Types & Settings

```text
GET    /training-types
POST   /training-types
GET    /training-types/:id
PATCH  /training-types/:id
DELETE /training-types/:id

GET    /training-settings
PATCH  /training-settings
```

## Training Matrix

```text
GET    /training-matrices
POST   /training-matrices
GET    /training-matrices/:id
PATCH  /training-matrices/:id
DELETE /training-matrices/:id
GET    /training-matrices/:id/requirements
POST   /training-matrices/:id/requirements
PATCH  /training-matrix-requirements/:id
DELETE /training-matrix-requirements/:id
POST   /training-matrices/evaluate
```

## Competency Matrix

```text
GET    /competency-matrices
POST   /competency-matrices
GET    /competency-matrices/:id
PATCH  /competency-matrices/:id
GET    /competency-items
POST   /competency-items
GET    /competency-assessments
POST   /competency-assessments
POST   /competency-assessments/:id/approve
GET    /competency-gaps
```

## Training Need

```text
GET    /training-needs
POST   /training-needs
GET    /training-needs/:id
PATCH  /training-needs/:id
POST   /training-needs/:id/plan
POST   /training-needs/:id/waive
POST   /training-needs/generate-from-gap
```

## Training Plan, Schedule & Session

```text
GET    /training-plans
POST   /training-plans
GET    /training-schedules
POST   /training-schedules
GET    /training-sessions
POST   /training-sessions
GET    /training-sessions/:id
PATCH  /training-sessions/:id
POST   /training-sessions/:id/invite
POST   /training-sessions/:id/start
POST   /training-sessions/:id/complete
POST   /training-sessions/:id/close
```

## Attendance & Evidence

```text
GET    /training-sessions/:id/participants
POST   /training-sessions/:id/participants
DELETE /training-sessions/:id/participants/:participantId
GET    /training-sessions/:id/attendance
POST   /training-sessions/:id/attendance
POST   /training-sessions/:id/attendance/confirm
POST   /training-sessions/:id/upload-evidence
```

## Certificate

```text
GET    /certificates
POST   /certificates
GET    /certificates/:id
PATCH  /certificates/:id
POST   /certificates/:id/renew
POST   /certificates/:id/revoke
GET    /certificates/expiring
GET    /certificates/expired
GET    /certificates/:id/download
```

## Induction & Toolbox

```text
GET    /inductions
POST   /inductions
GET    /toolbox-meetings
POST   /toolbox-meetings
GET    /toolbox-meetings/:id
POST   /toolbox-meetings/:id/attendance
POST   /toolbox-meetings/:id/close
```

## Validation & Integration

```text
POST /training-competency/validate-worker
POST /training-competency/validate-permit-workers
POST /training-competency/validate-contractor-worker
POST /training-competency/generate-gap-analysis
```

## Dashboard & Report

```text
GET /training-competency/dashboard
GET /training-competency/kpi
GET /training-competency/compliance
GET /training-competency/gap-report
GET /training-competency/export
```
