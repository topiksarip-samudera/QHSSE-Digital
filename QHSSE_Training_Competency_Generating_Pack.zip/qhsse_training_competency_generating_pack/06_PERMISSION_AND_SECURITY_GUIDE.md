# 06 — PERMISSION & SECURITY GUIDE

## Permission Groups

### Training

```text
training.view
training.view_all
training.create
training.update
training.delete
training.schedule
training.conduct
training.close
training.export
training.manage_settings
```

### Attendance

```text
training_attendance.view
training_attendance.manage
training_attendance.confirm
```

### Certificate

```text
certificate.view
certificate.view_all
certificate.create
certificate.issue
certificate.update
certificate.renew
certificate.revoke
certificate.download
certificate.export
```

### Competency

```text
competency.view
competency.view_all
competency.manage
competency.assess
competency.approve
competency.export
```

### Matrix

```text
training_matrix.view
training_matrix.manage
competency_matrix.view
competency_matrix.manage
```

## Scope

```text
Global
Company
Site
Project
Department
Own
Assigned
Trainer
Assessor
Participant
Contractor
```

## Security Rules

- Semua query wajib filter company_id.
- User hanya bisa melihat training sesuai scope.
- Participant hanya bisa melihat training/certificate miliknya jika diberikan akses.
- Contractor hanya bisa melihat worker/certificate contractor-nya.
- Certificate file download harus permission-guarded.
- Competency assessment hanya boleh dibuat oleh assessor berwenang.
- Certificate revoke harus butuh permission khusus.
- Export report wajib audit log.
- Validation endpoint untuk permit hanya boleh mengembalikan data yang diperlukan, bukan data sensitif penuh.
