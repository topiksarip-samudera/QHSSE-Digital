# 02 — TRAINING & COMPETENCY GENERATING RULES

## Aturan Utama

1. Jangan membuat Training & Competency sebagai calendar CRUD biasa.
2. Training matrix dan competency matrix harus configurable.
3. Required training harus bisa berdasarkan role, position, department, site, permit type, risk, asset, contractor, dan legal obligation.
4. Certificate expiry harus punya notification dan validation logic.
5. Permit integration harus bisa block/warning sesuai setting.
6. Contractor worker competency harus supported.
7. Training material harus bisa link ke Document Control.
8. Attendance harus punya evidence dan audit log.
9. Assessment/quiz optional harus expandable.
10. Dashboard angka harus dihitung dari data nyata.
11. Semua data wajib tenant-safe.
12. Semua API wajib permission-guarded.

## Status Training Need

```text
open
planned
scheduled
in_progress
completed
cancelled
waived
```

## Status Training Session

```text
draft
scheduled
invited
in_progress
conducted
attendance_confirmed
assessment_completed
certificate_issued
closed
cancelled
```

## Status Certificate

```text
draft
issued
active
expiring_soon
expired
renewed
revoked
archived
```

## Permission Standard

```text
training.view
training.view_all
training.create
training.update
training.delete
training.schedule
training.conduct
training.attendance.manage
training.assessment.manage
training.certificate.issue
training.certificate.revoke
training.export
training.manage_settings

competency.view
competency.manage
competency.assess
competency.approve

training_matrix.view
training_matrix.manage
certificate.view
certificate.manage
```

## Audit Log Wajib

```text
training.created
training.scheduled
training.participant_added
training.attendance_confirmed
training.assessment_submitted
training.certificate_issued
training.certificate_renewed
training.certificate_revoked
training.need_created
competency.assessed
competency.status_changed
matrix.updated
report.exported
settings.changed
```

## Webhook Events

```text
training.need_created
training.scheduled
training.reminder_due
training.completed
certificate.issued
certificate.expiring
certificate.expired
competency.gap_detected
competency.updated
permit.training_validation_failed
```
