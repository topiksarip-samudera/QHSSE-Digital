# 00 — PROMPT AWAL TRAINING & COMPETENCY UNTUK AI AGENT

Core Platform sudah stabil. Incident Management, Risk Management / HIRADC / JSA, Audit & Inspection, Permit to Work, dan Document Control sudah selesai atau siap integrasi.

Sekarang mulai generate QHSSE Operational Module: **Training & Competency**.

Baca seluruh file dalam folder `qhsse_training_competency_generating_pack`.

Aturan wajib:

1. Jangan generate semua sequence sekaligus.
2. Mulai dari `sequence/01_foundation_master_data.md`.
3. Gunakan core yang sudah ada:
   - Company / tenant
   - Site / project / department / location
   - Role & permission
   - Module ON/OFF
   - Master data
   - Workflow
   - Attachment/evidence
   - Audit log
   - Notification
   - Numbering
   - Schedule/calendar engine
   - Dashboard
   - Report export
   - API/webhook
4. Training & Competency tidak boleh hanya menjadi jadwal training.
5. Harus ada training matrix.
6. Harus ada competency matrix.
7. Harus ada training need analysis.
8. Harus ada certificate register dan expiry management.
9. Harus ada competency assessment dan gap analysis.
10. Harus terintegrasi dengan Document Control, Permit to Work, Contractor, Risk, Incident, Audit, dan Legal.
11. Semua data wajib tenant-safe.
12. Semua API wajib permission-guarded.
13. Semua attendance, certificate issue, certificate expiry, competency result, dan export penting wajib audit logged.
14. Setelah sequence selesai, tulis:
   `SELESAI TRAINING COMPETENCY SEQUENCE XX: <nama sequence>`
15. Jangan lanjut sequence berikutnya sebelum user meminta continue.

Mulai dari sequence pertama saja.
