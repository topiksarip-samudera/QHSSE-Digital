# 05 — UI/UX GUIDE TRAINING & COMPETENCY

## Sidebar

```text
Training & Competency
├── Overview
├── Training Matrix
├── Competency Matrix
├── Training Needs
├── Training Plan
├── Training Schedule
├── Training Sessions
├── Attendance
├── Induction
├── Toolbox Meeting
├── Certificates
├── Competency Assessment
├── Gap Analysis
├── Reports
└── Settings
```

## Halaman Utama

```text
Training Dashboard
Training Matrix List
Training Matrix Detail
Competency Matrix List
Competency Matrix Detail
Training Need Register
Training Plan
Training Calendar
Training Session Detail
Attendance Page
Induction Register
Toolbox Meeting Register
Certificate Register
Expiring Certificate Page
Competency Assessment Page
Gap Analysis Page
Report Export
Settings
```

## Training Session Detail Tabs

```text
Overview
Participants
Attendance
Material
Assessment
Certificate
Evidence
Evaluation
Comments
Audit Trail
```

## Certificate Detail Tabs

```text
Overview
Holder
Training Source
File
Renewal History
Validation Usage
Audit Trail
```

## Komponen Wajib

```text
TrainingStatusBadge
CertificateStatusBadge
CompetencyStatusBadge
TrainingMatrixTable
CompetencyMatrixTable
TrainingCalendar
AttendanceTable
CertificateExpiryBadge
GapAnalysisPanel
WorkerValidationPanel
TrainingComplianceCard
TrainingEvidenceUpload
```

## UX Penting

- Training calendar harus mudah difilter site/department/training type.
- Attendance harus cepat dipakai saat training.
- Certificate expiry harus terlihat jelas.
- Gap analysis harus menjelaskan requirement yang belum terpenuhi.
- Permit validation result harus jelas: pass/warning/block.
- Contractor worker harus bisa terlihat berbeda dari internal employee.
