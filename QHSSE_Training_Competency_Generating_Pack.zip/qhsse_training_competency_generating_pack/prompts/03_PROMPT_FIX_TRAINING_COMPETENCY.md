# Prompt Fix Training & Competency

Review modul Training & Competency yang terakhir dibuat.

Periksa:
- Tenant isolation
- Permission backend
- Training matrix
- Competency matrix
- Training need generation
- Attendance
- Evidence upload
- Certificate expiry
- Gap analysis
- Permit validation
- Contractor validation
- Document integration
- Audit log
- Notification
- Dashboard calculation
- Report export
- Build/lint/test

Perbaiki semua bug P0/P1. Setelah selesai tulis:

```text
TRAINING COMPETENCY FIXED
```
