# Prompt Start Training & Competency

Core Platform sudah stabil. Incident Management, Risk Management, Audit & Inspection, Permit to Work, dan Document Control sudah selesai atau siap integrasi.

Sekarang generate Training & Competency berdasarkan `qhsse_training_competency_generating_pack`.

Mulai dari:

```text
sequence/01_foundation_master_data.md
```

Kerjakan sequence pertama saja.

Setelah selesai tulis:

```text
SELESAI TRAINING COMPETENCY SEQUENCE 01: Foundation & Master Data
```

Jangan lanjut sequence berikutnya sebelum saya minta continue.
