# Prompt Release Gate Training & Competency

Jalankan release gate Training & Competency.

Cek:
- P0 = 0
- P1 = 0
- Tenant isolation PASS
- Permission backend PASS
- Training matrix PASS
- Competency matrix PASS
- Training need generation PASS
- Attendance PASS
- Certificate expiry PASS
- Gap analysis PASS
- Permit validation PASS
- Contractor validation PASS
- Document integration PASS
- Audit log PASS
- Dashboard calculation PASS
- Report export PASS
- Lint/test/build PASS

Jika lulus tulis:

```text
TRAINING COMPETENCY STABILIZED: GO
```

Jika gagal tulis:

```text
TRAINING COMPETENCY STABILIZED: NO-GO
```

Sertakan blocking issue.
