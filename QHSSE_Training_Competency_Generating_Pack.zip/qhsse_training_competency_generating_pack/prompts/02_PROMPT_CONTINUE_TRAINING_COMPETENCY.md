# Prompt Continue Training & Competency Sequence

Continue Training & Competency Sequence.

Kerjakan sequence berikutnya sesuai:

```text
sequence/00_TRAINING_COMPETENCY_SEQUENCE.md
```

Aturan:
- Jangan lompat sequence.
- Jangan lanjut sequence berikutnya setelah selesai.
- Pastikan database, backend, frontend, permission, audit log, dan test selesai.
- Jika sequence selesai, tulis:
  `SELESAI TRAINING COMPETENCY SEQUENCE XX: <nama sequence>`
