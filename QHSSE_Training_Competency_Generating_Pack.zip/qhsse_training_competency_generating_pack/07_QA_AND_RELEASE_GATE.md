# 07 — QA AND RELEASE GATE

## QA Scope

```text
Tenant Isolation
Permission & Scope
Training Matrix
Competency Matrix
Training Need Analysis
Training Schedule
Attendance
Evidence Upload
Induction
Toolbox Meeting
Certificate Register
Certificate Expiry
Competency Assessment
Gap Analysis
Document Integration
Permit Validation
Contractor Worker Validation
Dashboard Calculation
Report Export
Audit Log
Notification
Regression Test
```

## Release Gate

Training & Competency hanya boleh dinyatakan selesai jika:

```text
P0 = 0
P1 = 0
Tenant isolation PASS
Permission backend PASS
Training matrix PASS
Competency matrix PASS
Training need generation PASS
Attendance PASS
Certificate expiry PASS
Gap analysis PASS
Permit validation PASS
Contractor validation PASS
Document integration PASS
Audit log PASS
Dashboard calculation PASS
Report export PASS
Lint/test/build PASS
```

## Status Akhir

Jika lulus:

```text
TRAINING COMPETENCY STABILIZED: GO
```

Jika gagal:

```text
TRAINING COMPETENCY STABILIZED: NO-GO
```
