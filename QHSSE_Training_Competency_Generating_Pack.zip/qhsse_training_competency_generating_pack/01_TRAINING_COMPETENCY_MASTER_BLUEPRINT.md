# 01 — MASTER BLUEPRINT TRAINING & COMPETENCY

## Tujuan Modul

Modul **Training & Competency** digunakan untuk memastikan pekerja, karyawan, dan contractor worker memiliki training, kompetensi, sertifikat, induction, toolbox meeting, dan assessment yang sesuai dengan risiko pekerjaan, role, permit type, dokumen, legal requirement, dan persyaratan perusahaan.

Modul ini harus menjadi **competency control system**, bukan hanya daftar jadwal training.

## Prinsip Desain

1. Training matrix harus configurable per role, position, department, site, permit type, risk, dan legal requirement.
2. Competency matrix harus bisa mengukur skill/competency level.
3. Training need harus bisa muncul dari gap analysis, incident, audit finding, risk control, document revision, dan legal requirement.
4. Certificate expiry harus bisa memicu notification dan blocking/warning di Permit to Work.
5. Contractor worker harus bisa divalidasi kompetensinya.
6. Training material harus bisa link ke Document Control.
7. Attendance dan certificate harus punya evidence.
8. Assessment/quiz optional harus bisa dipakai untuk mengukur pemahaman.
9. Semua data harus tenant-safe.
10. Semua perubahan critical harus audit logged.

## Submodul Utama

```text
Training Matrix
Competency Matrix
Training Need Analysis
Training Plan
Training Schedule
Training Session
Attendance
Evidence
Induction
Toolbox Meeting
Certificate Register
Certificate Expiry
Competency Assessment
Quiz / Test optional
Training Evaluation
Training Material
Training Compliance Dashboard
Gap Analysis
Training Report
```

## Jenis Training

```text
General HSE Induction
Site Induction
Project Induction
Job Specific Training
Working at Height
Confined Space Entry
Hot Work
LOTO
First Aid
Fire Fighting
Defensive Driving
Lifting & Rigging
Scaffolding
Chemical Handling
Environmental Awareness
Waste Management
Quality Awareness
Security Awareness
Emergency Response
ISO 9001 Awareness
ISO 14001 Awareness
ISO 45001 Awareness
SMK3 Awareness
Permit to Work Training
Risk Assessment / HIRADC / JSA
Incident Investigation
Audit Training
```

## Lifecycle Training

```text
Training Need Identified
→ Training Planned
→ Training Scheduled
→ Participants Assigned
→ Conducted
→ Attendance Confirmed
→ Assessment optional
→ Evaluation optional
→ Certificate Issued optional
→ Competency Updated
→ Closed
```

## Certificate Lifecycle

```text
Draft
→ Issued
→ Active
→ Expiring Soon
→ Expired
→ Renewed
→ Revoked
→ Archived
```

## Competency Status

```text
Not Required
Required
Not Started
In Progress
Competent
Competent with Supervision
Not Yet Competent
Expired
Suspended
```

## Output Utama

```text
Training Matrix
Competency Matrix
Training Need Register
Training Plan
Training Schedule
Attendance Report
Induction Record
Toolbox Meeting Record
Certificate Register
Expiring Certificate List
Expired Certificate List
Competency Gap Report
Training Compliance Report
Training Effectiveness Report
Permit Blocking/Warn Validation
Contractor Competency Report
```

## Integrasi Core

```text
Schedule: training calendar
Workflow: training approval/certificate approval if needed
Attachment: attendance sheet, certificate, material, evidence
Notification: schedule, invitation, reminder, expiry, overdue
Audit Log: attendance, certificate, assessment, export
Numbering: training number, certificate number
Dashboard: KPI and compliance
API/Webhook: integration
```

## Integrasi Modul Lain

```text
Document Control:
- Training material link to SOP/WI/Policy.
- New document revision can trigger acknowledgement or retraining.

Permit to Work:
- Permit validates worker certificate/competency.
- Expired certificate can block or warn permit approval.

Contractor Management:
- Contractor worker training and certificate validation.
- Contractor compliance score uses training data.

Risk Management:
- Training can be risk control.
- High risk activity can require specific competency.

Incident Management:
- Incident RCA can create training need.
- Lessons learned can become training material.

Audit & Inspection:
- Audit finding can create training action.
- Training evidence supports audit.

Legal & Compliance:
- Mandatory training can be mapped to legal obligations.
```
